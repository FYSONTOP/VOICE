﻿namespace StupidTemplate
{
    internal class PluginInfo
    {
        public const string GUID = "FYS.WALKSIM";
        public const string Name = "FYS DISABLED SIM";
        public const string Description = "MADE FOR FUN";
        public const string Version = "1.0.0";
    }
}
