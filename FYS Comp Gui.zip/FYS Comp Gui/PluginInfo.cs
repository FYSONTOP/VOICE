﻿namespace StupidTemplate
{
    internal class PluginInfo
    {
        public const string GUID = "FYS.GUIMENU";
        public const string Name = "FYS GUI MENU";
        public const string Description = "MADE FOR COMP GTAG";
        public const string Version = "1.0.1";
    }
}
