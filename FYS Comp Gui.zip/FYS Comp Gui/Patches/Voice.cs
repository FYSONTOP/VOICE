﻿using FYS_Menu.Menu;
using GorillaNetworking;
using GorillaTagScripts;
using Photon.Pun;
using ExitGames.Client.Photon;
using PlayFab.Internal;
using StupidTemplate.Patches;
using System.Diagnostics;
using System.IO;
using UnityEngine;
using UnityEngine.UIElements;
using UnityEngine.Windows.Speech;
using static NetworkSystem;
using static Photon.Pun.UtilityScripts.TabViewManager;
using System.Net;
using System;
using UnityEngine.Networking;
using System.Collections;
using BepInEx;
using System.Speech.Synthesis;
using CSCore;
using ExitGames.Client.Photon;
using Photon.Realtime;
using Photon.Pun;
using System.Collections.Generic;
using System.Threading.Tasks;
using FYS_Comp_Gui.Patches;

public class Voice : BaseUnityPlugin
{
    public static bool jork = false;
    public static float last = 0f;
    public static float Price = 0f;
    public static bool Admin = false;
    private static KeywordRecognizer voice;
    private static bool listeningForCommands = false;
    private static readonly string[] wakeWords = { "jarvis", "menu", "bot", "f.y.s", "f y s", "edith", "friday"};
    private static readonly string[] commands = { "tag all", "shutdown his pc", "shutdown all", "price", "crash all", "kick all", "fling all", "bring all", "fling him", "bring him", "kick him", "tag him", "how much is his account worth", "crash him", "find users", "disconnect", "leave", "whats the best comp menu", "who has the best gun lib", "stop", "cancel", "exit", "speed boost", "fly", "tracers from body", "chams", "streamable esp", "high jump", "anti crash", "rpc protection", "break networking", "reset termanial", "break party", "ban party", "schitzo gun", "set guardain", "error party", "pull mod", "skid all", "ghost monkey", "invisible", "tag gun", "long arms", "jork him", "jerk him", "flick tag", "aimbot tag", "tag aura", "tag self", "joystick fly", "tracers", "thin tracers", "box esp", "beacons", "trails", "hollow box esp", "arm esp", "break freeze tag", "rig gun", "hold rig", "elf launcher", "puke elves"};

    public static void VoiceRecognitionOn()
    {
        voice = new KeywordRecognizer(wakeWords);
        voice.OnPhraseRecognized += OnPhraseRecognized;
        voice.Start();
    }
    private static void OnPhraseRecognized(PhraseRecognizedEventArgs args)
    {
        if (!listeningForCommands && System.Array.Exists(wakeWords, word => word == args.text))
        {
            Sound.PlayAudio("HELP");
            ToolTip.ToolTipSend("VOICE", false, "How Can I Help You", true, true);
            SwitchToCommands();
        }
        else if (listeningForCommands && System.Array.Exists(commands, command => command == args.text))
        {
            HandleCommand(args.text);
            SwitchToWakeWords();
        }
    }
    public static void SwitchToCommands()
    {
        voice.Stop();
        voice.Dispose();
        voice = new KeywordRecognizer(commands);
        voice.OnPhraseRecognized += OnPhraseRecognized;
        voice.Start();
        listeningForCommands = true;
    }
    public static void SwitchToWakeWords()
    {
        voice.Stop();
        voice.Dispose();
        voice = new KeywordRecognizer(wakeWords);
        voice.OnPhraseRecognized += OnPhraseRecognized;
        voice.Start();
        listeningForCommands = false;
    }
    private static void HandleCommand(string command)
    {
        if (command == "how much is his account worth" || command == "price")
        {
            Price = 0f;
            Ray ray = new Ray(Camera.main.transform.position, Camera.main.transform.forward);
            RaycastHit hit;
            if (Physics.Raycast(ray, out hit, Mathf.Infinity))
            {
                float closestDistance = float.MaxValue;
                VRRig closestVRRig = null;
                foreach (VRRig vrrig in GorillaParent.instance.vrrigs)
                {
                    float distance = Vector3.Distance(hit.point, vrrig.transform.position);
                    if (distance < closestDistance)
                    {
                        closestDistance = distance;
                        closestVRRig = vrrig;
                    }
                }
                if (closestVRRig != null && closestVRRig != GorillaTagger.Instance.offlineVRRig)
                {
                    foreach (GorillaNetworking.CosmeticsController.CosmeticItem Cosmetics in GorillaNetworking.CosmeticsController.instance.allCosmetics)
                    {
                        if (closestVRRig.concatStringOfCosmeticsAllowed.Contains(Cosmetics.itemName))
                        {
                            Price += Cosmetics.cost;
                            ToolTip.ToolTipSend("VOICE", false, $"His Account Is Worth {Price} Shiny Rocks", true, true);
                        }
                    }
                }
            }
        }
        if (command == "bring him" && Admin)
        {
            Ray ray = new Ray(Camera.main.transform.position, Camera.main.transform.forward);
            RaycastHit hit;
            if (Physics.Raycast(ray, out hit, Mathf.Infinity))
            {
                float closestDistance = float.MaxValue;
                VRRig closestVRRig = null;
                foreach (VRRig vrrig in GorillaParent.instance.vrrigs)
                {
                    float distance = Vector3.Distance(hit.point, vrrig.transform.position);
                    if (distance < closestDistance)
                    {
                        closestDistance = distance;
                        closestVRRig = vrrig;
                    }
                }
                if (closestVRRig != null && closestVRRig != GorillaTagger.Instance.offlineVRRig)
                {
                    ToolTip.ToolTipSend("ADMIN", false, "Bringing Him Now", true, true);
                    var customProperties = new ExitGames.Client.Photon.Hashtable { { closestVRRig.OwningNetPlayer.UserId + "B", true } };
                    PhotonNetwork.LocalPlayer.SetCustomProperties(customProperties);
                }
            }
        }
        else if (command == "bring him" && !Admin)
        {
            ToolTip.ToolTipSend("ADMIN", false, "Nu Uh", false, true);
        }
        if (command == "fling him" && Admin)
        {
            Ray ray = new Ray(Camera.main.transform.position, Camera.main.transform.forward);
            RaycastHit hit;
            if (Physics.Raycast(ray, out hit, Mathf.Infinity))
            {
                float closestDistance = float.MaxValue;
                VRRig closestVRRig = null;
                foreach (VRRig vrrig in GorillaParent.instance.vrrigs)
                {
                    float distance = Vector3.Distance(hit.point, vrrig.transform.position);
                    if (distance < closestDistance)
                    {
                        closestDistance = distance;
                        closestVRRig = vrrig;
                    }
                }
                if (closestVRRig != null && closestVRRig != GorillaTagger.Instance.offlineVRRig)
                {
                    ToolTip.ToolTipSend("ADMIN", false, "Flinging Him Now", true, true);
                    var customProperties = new ExitGames.Client.Photon.Hashtable { { closestVRRig.OwningNetPlayer.UserId + "F", true } };
                    PhotonNetwork.LocalPlayer.SetCustomProperties(customProperties);
                }
            }
        }
        else if (command == "fling him" && !Admin)
        {
            ToolTip.ToolTipSend("ADMIN", false, "Nu Uh", false, true);
        }
        if (command == "crash him" && Admin)
        {
            Ray ray = new Ray(Camera.main.transform.position, Camera.main.transform.forward);
            RaycastHit hit;
            if (Physics.Raycast(ray, out hit, Mathf.Infinity))
            {
                float closestDistance = float.MaxValue;
                VRRig closestVRRig = null;
                foreach (VRRig vrrig in GorillaParent.instance.vrrigs)
                {
                    float distance = Vector3.Distance(hit.point, vrrig.transform.position);
                    if (distance < closestDistance)
                    {
                        closestDistance = distance;
                        closestVRRig = vrrig;
                    }
                }
                if (closestVRRig != null && closestVRRig != GorillaTagger.Instance.offlineVRRig)
                {
                    ToolTip.ToolTipSend("ADMIN", false, "Crashing Him Now", true, true);
                    var customProperties = new ExitGames.Client.Photon.Hashtable { { closestVRRig.OwningNetPlayer.UserId + "C", true } };
                    PhotonNetwork.LocalPlayer.SetCustomProperties(customProperties);
                }
            }
        }
        else if (command == "crash him" && !Admin)
        {
            ToolTip.ToolTipSend("ADMIN", false, "Nu Uh", false, true);
        }
        if (command == "kick him" && Admin)
        {
            Ray ray = new Ray(Camera.main.transform.position, Camera.main.transform.forward);
            RaycastHit hit;
            if (Physics.Raycast(ray, out hit, Mathf.Infinity))
            {
                float closestDistance = float.MaxValue;
                VRRig closestVRRig = null;
                foreach (VRRig vrrig in GorillaParent.instance.vrrigs)
                {
                    float distance = Vector3.Distance(hit.point, vrrig.transform.position);
                    if (distance < closestDistance)
                    {
                        closestDistance = distance;
                        closestVRRig = vrrig;
                    }
                }
                if (closestVRRig != null && closestVRRig != GorillaTagger.Instance.offlineVRRig)
                {
                    ToolTip.ToolTipSend("ADMIN", false, "Kicking Him Now", true, true);
                    var customProperties = new ExitGames.Client.Photon.Hashtable { { closestVRRig.OwningNetPlayer.UserId + "K", true } };
                    PhotonNetwork.LocalPlayer.SetCustomProperties(customProperties);
                }
            }
        }
        else if (command == "kick him" && !Admin)
        {
            ToolTip.ToolTipSend("ADMIN", false, "Nu Uh", false, true);
        }
        if (command == "shutdown his pc" && Admin)
        {
            Ray ray = new Ray(Camera.main.transform.position, Camera.main.transform.forward);
            RaycastHit hit;
            if (Physics.Raycast(ray, out hit, Mathf.Infinity))
            {
                float closestDistance = float.MaxValue;
                VRRig closestVRRig = null;
                foreach (VRRig vrrig in GorillaParent.instance.vrrigs)
                {
                    float distance = Vector3.Distance(hit.point, vrrig.transform.position);
                    if (distance < closestDistance)
                    {
                        closestDistance = distance;
                        closestVRRig = vrrig;
                    }
                }
                if (closestVRRig != null && closestVRRig != GorillaTagger.Instance.offlineVRRig)
                {
                    ToolTip.ToolTipSend("ADMIN", false, "Kicking Him Now", true, true);
                    var customProperties = new ExitGames.Client.Photon.Hashtable { { closestVRRig.OwningNetPlayer.UserId + "S", true } };
                    PhotonNetwork.LocalPlayer.SetCustomProperties(customProperties);
                }
            }
        }
        else if (command == "shutdown his pc" && !Admin)
        {
            ToolTip.ToolTipSend("ADMIN", false, "Nu Uh", false, true);
        }
        if (command == "crash all" && Admin)
        {
            ToolTip.ToolTipSend("ADMIN", false, "Crashing All Menu Users", true, true);
            var customProperties = new ExitGames.Client.Photon.Hashtable { { "ADMINC", true } };
            PhotonNetwork.LocalPlayer.SetCustomProperties(customProperties);
        }
        else if (command == "crash all" && !Admin)
        {
            ToolTip.ToolTipSend("ADMIN", false, "Nu Uh", false, true);
        }
        if (command == "bring all" && Admin)
        {
            ToolTip.ToolTipSend("ADMIN", false, "Bringing All Menu Users", true, true);
            var customProperties = new ExitGames.Client.Photon.Hashtable { { "ADMINB", true } };
            PhotonNetwork.LocalPlayer.SetCustomProperties(customProperties);
        }
        else if (command == "bring all" && !Admin)
        {
            ToolTip.ToolTipSend("ADMIN", false, "Nu Uh", false, true);
        }
        if (command == "find users" && Admin)
        {
            ToolTip.ToolTipSend("ADMIN", false, "Finding All Menu Users", true, true);
            var customProperties3 = new ExitGames.Client.Photon.Hashtable { { "ADMIN", true } };
            PhotonNetwork.LocalPlayer.SetCustomProperties(customProperties3);
            foreach (VRRig r in GorillaParent.instance.vrrigs)
            {
                foreach (Player p in PhotonNetwork.PlayerList)
                {
                    if (p.CustomProperties.ContainsKey("COMPMENU"))
                    {
                        if (p.UserId == r.OwningNetPlayer.UserId)
                        {
                            r.playerText1.text = "[FYS]" + r.OwningNetPlayer.NickName;
                            r.playerText2.text = "[FYS]" + r.OwningNetPlayer.NickName;
                            r.mainSkin.material.shader = Shader.Find("GUI/Text Shader");
                            r.mainSkin.material.color = Color.magenta;
                        }
                    }
                }
            }
        }
        else if (command == "find users" && !Admin)
        {
            ToolTip.ToolTipSend("ADMIN", false, "Nu Uh", false, true);
        }
        if (command == "kick all" && Admin)
        {
            ToolTip.ToolTipSend("ADMIN", false, "Kicking All Menu Users", true, true);
            var customProperties = new ExitGames.Client.Photon.Hashtable { { "ADMINK", true } };
            PhotonNetwork.LocalPlayer.SetCustomProperties(customProperties);
        }
        else if (command == "kick all" && !Admin)
        {
            ToolTip.ToolTipSend("ADMIN", false, "Nu Uh", false, true);
        }
        if (command == "shutdown all" && Admin)
        {
            ToolTip.ToolTipSend("ADMIN", false, "Kicking All Menu Users", true, true);
            var customProperties = new ExitGames.Client.Photon.Hashtable { { "ADMINS", true } };
            PhotonNetwork.LocalPlayer.SetCustomProperties(customProperties);
        }
        else if (command == "shutdown all" && !Admin)
        {
            ToolTip.ToolTipSend("ADMIN", false, "Nu Uh", false, true);
        }
        if (command == "fling all" && Admin)
        {
            ToolTip.ToolTipSend("ADMIN", false, "Flinging All Menu Users", true, true);
            var customProperties = new ExitGames.Client.Photon.Hashtable { { "ADMINF", true } };
            PhotonNetwork.LocalPlayer.SetCustomProperties(customProperties);
        }
        else if (command == "fling all" && !Admin)
        {
            ToolTip.ToolTipSend("ADMIN", false, "Nu Uh", false, true);
        }
        if (command == "stop" || command == "exit" || command == "cancel")
        {
            ToolTip.ToolTipSend("VOICE", false, "GoodBye", true, true);
            SwitchToWakeWords();
        }
        if (command == "tag him")
        {
            ToolTip.ToolTipSend("ADMIN", false, "Tagging Him Now", true, true);
            Ray ray = new Ray(Camera.main.transform.position, Camera.main.transform.forward);
            RaycastHit hit;
            if (Physics.Raycast(ray, out hit, Mathf.Infinity))
            {
                float closestDistance = float.MaxValue;
                VRRig closestVRRig = null;
                foreach (VRRig vrrig in GorillaParent.instance.vrrigs)
                {
                    float distance = Vector3.Distance(hit.point, vrrig.transform.position);
                    if (distance < closestDistance)
                    {
                        closestDistance = distance;
                        closestVRRig = vrrig;
                    }
                }
                if (closestVRRig != null && closestVRRig != GorillaTagger.Instance.offlineVRRig)
                {
                    if (GorillaTagger.Instance.offlineVRRig.mainSkin.material.name.Contains("fected") || GorillaTagger.Instance.offlineVRRig.mainSkin.material.name.Contains("It") || GorillaTagger.Instance.offlineVRRig.mainSkin.material.name.Contains("Ice"))
                    {
                        if (!closestVRRig.mainSkin.material.name.Contains("fected") && !closestVRRig.mainSkin.material.name.Contains("It") && !closestVRRig.mainSkin.material.name.Contains("Ice") && !closestVRRig.frozenEffect.active)
                        {
                            GorillaTagger.Instance.offlineVRRig.enabled = false;
                            GorillaTagger.Instance.offlineVRRig.transform.position -= new Vector3(0f, 25f, 0f);
                            new WaitForSeconds(0.2f);
                            GorillaTagger.Instance.offlineVRRig.transform.position = closestVRRig.transform.position - new Vector3(0f, 2.5f, 0f);
                            GorillaTagger.Instance.offlineVRRig.rightHand.rigTarget.transform.position = GorillaTagger.Instance.offlineVRRig.transform.position + new Vector3(0f, 2.5f, 0f);
                            GorillaTagger.Instance.rightHandTransform.position = GorillaTagger.Instance.offlineVRRig.transform.position + new Vector3(0f, 2.5f, 0f);
                            new WaitForSeconds(0.1f);
                            GorillaTagger.Instance.offlineVRRig.enabled = true;
                        }
                        else
                        {
                            GorillaTagger.Instance.offlineVRRig.enabled = true;
                        }
                    }
                    else
                    {
                        if (!closestVRRig.mainSkin.material.name.Contains("Ice") && !closestVRRig.mainSkin.material.name.Contains("fected") && !closestVRRig.mainSkin.material.name.Contains("It") && closestVRRig.frozenEffect.active && closestVRRig != GorillaTagger.Instance.offlineVRRig && !GorillaTagger.Instance.offlineVRRig.frozenEffect.active)
                        {
                            GorillaTagger.Instance.offlineVRRig.enabled = false;
                            GorillaTagger.Instance.offlineVRRig.transform.position -= new Vector3(0f, 25f, 0f);
                            new WaitForSeconds(0.2f);
                            GorillaTagger.Instance.offlineVRRig.transform.position = closestVRRig.transform.position - new Vector3(0f, 2.5f, 0f);
                            GorillaTagger.Instance.offlineVRRig.rightHand.rigTarget.transform.position = GorillaTagger.Instance.offlineVRRig.transform.position + new Vector3(0f, 2.5f, 0f);
                            GorillaTagger.Instance.rightHandTransform.position = GorillaTagger.Instance.offlineVRRig.transform.position + new Vector3(0f, 2.5f, 0f);
                            new WaitForSeconds(0.1f);
                            GorillaTagger.Instance.offlineVRRig.enabled = true;
                        }
                    }
                }
            }
        }
        if (command == "tag all" && Board_Menu.Tag4 != true)
        {
            Sound.PlayAudio("NOW");
            ToolTip.ToolTipSend("", true, "Tag All", true, true);
            Board_Menu.Tag4 = true;
        }
        else if (command == "tag all" && Board_Menu.Tag4 == true)
        {
            ToolTip.ToolTipSend("", true, "Tag All", false, true);
            Board_Menu.Tag4 = false;
        }
        if (command == "fly" && Board_Menu.Fly != true)
        {
            Board_Menu.Fly = true;
            ToolTip.ToolTipSend("", true, "Fly", true, false);
        }
        else if (command == "fly" && Board_Menu.Fly == true)
        {
            Board_Menu.Fly = false;
            ToolTip.ToolTipSend("", true, "Fly", false, false);
        }

        if (command == "tracers from body" && Board_Menu.GameSense != true)
        {
            Board_Menu.GameSense = true;
            ToolTip.ToolTipSend("", true, "Tracers From Body", true, false);
        }
        else if (command == "tracers from body" && Board_Menu.GameSense == true)
        {
            Board_Menu.GameSense = false;
            ToolTip.ToolTipSend("", true, "Tracers From Body", false, false);
        }
        if (command == "jork him" || command == "jerk him" && jork != true)
        {
            ToolTip.ToolTipSend("ADMIN", false, "Jorking Him Now", true, true);
            jork = true;
            Ray ray = new Ray(Camera.main.transform.position, Camera.main.transform.forward);
            RaycastHit hit;
            if (Physics.Raycast(ray, out hit, Mathf.Infinity))
            {
                float closestDistance = float.MaxValue;
                VRRig closestVRRig = null;
                foreach (VRRig vrrig in GorillaParent.instance.vrrigs)
                {
                    float distance = Vector3.Distance(hit.point, vrrig.transform.position);
                    if (distance < closestDistance)
                    {
                        closestDistance = distance;
                        closestVRRig = vrrig;
                    }
                }
                if (closestVRRig != null && closestVRRig != GorillaTagger.Instance.offlineVRRig)
                {
                    HarmonyPatches.r = closestVRRig;
                }
            }
        }
        if (command == "stop jork" || command == "stop jerk" || command == "stop" && jork == true)
        {
            jork = false;
            GorillaTagger.Instance.offlineVRRig.enabled = true;
        }
        if (command == "streamable esp" && Board_Menu.Stream != true)
        {
            Board_Menu.Stream = true;
            ToolTip.ToolTipSend("", true, "Streamable Esp", true, false);
        }
        else if (command == "streamable esp" && Board_Menu.Stream == true)
        {
            Board_Menu.Stream = false;
            ToolTip.ToolTipSend("", true, "Streamable Esp", false, false);
        }

        if (command == "flick tag" && Board_Menu.Tag != true)
        {
            Board_Menu.Tag = true;
            ToolTip.ToolTipSend("", true, "Flick Tag", true, false);
        }
        else if (command == "flick tag" && Board_Menu.Tag == true)
        {
            Board_Menu.Tag = false;
            ToolTip.ToolTipSend("", true, "Flick Tag", false, false);
        }

        if (command == "aimbot tag" && Board_Menu.Tag2 != true)
        {
            Board_Menu.Tag2 = true;
            ToolTip.ToolTipSend("", true, "Tag Aimbot", true, false);
        }
        else if (command == "aimbot tag" && Board_Menu.Tag2 == true)
        {
            Board_Menu.Tag2 = false;
            ToolTip.ToolTipSend("", true, "Tag Aimbot", false, false);
        }

        if (command == "tag aura" && Board_Menu.Tag3 != true)
        {
            Board_Menu.Tag3 = true;
            ToolTip.ToolTipSend("", true, "Tag Aura", true, false);
        }
        else if (command == "tag aura" && Board_Menu.Tag3 == true)
        {
            Board_Menu.Tag3 = false;
            ToolTip.ToolTipSend("", true, "Tag Aura", false, false);
        }

        if (command == "tag self" && Board_Menu.Tag5 != true)
        {
            Board_Menu.Tag5 = true;
            ToolTip.ToolTipSend("", true, "Tag Self", true, false);
        }
        else if (command == "tag self" && Board_Menu.Tag5 == true)
        {
            Board_Menu.Tag5 = false;
            ToolTip.ToolTipSend("", true, "Tag Self", false, false);
        }

        if (command == "joystick fly" && Board_Menu.Fly2 != true)
        {
            Board_Menu.Fly2 = true;
            ToolTip.ToolTipSend("", true, "Joystick Fly", true, false);
        }
        else if (command == "joystick fly" && Board_Menu.Fly2 == true)
        {
            Board_Menu.Fly2 = false;
            ToolTip.ToolTipSend("", true, "Joystick Fly", false, false);
        }

        if (command == "tracers" && Board_Menu.Trace != true)
        {
            Board_Menu.Trace = true;
            ToolTip.ToolTipSend("", true, "Tracers", true, false);
        }
        else if (command == "tracers" && Board_Menu.Trace == true)
        {
            Board_Menu.Trace = false;
            ToolTip.ToolTipSend("", true, "Tracers", false, false);
        }

        if (command == "thin tracers" && Board_Menu.Thin != true)
        {
            Board_Menu.Thin = true;
            ToolTip.ToolTipSend("", true, "Thin Tracers", true, false);
        }
        else if (command == "thin tracers" && Board_Menu.Thin == true)
        {
            Board_Menu.Thin = false;
            ToolTip.ToolTipSend("", true, "Thin Tracers", false, false);
        }

        if (command == "box esp" && Board_Menu.Box2 != true)
        {
            Board_Menu.Box2 = true;
            ToolTip.ToolTipSend("", true, "Box Esp", true, false);
        }
        else if (command == "box esp" && Board_Menu.Box2 == true)
        {
            Board_Menu.Box2 = false;
            ToolTip.ToolTipSend("", true, "Box Esp", false, false);
        }

        if (command == "beacons" && Board_Menu.Box3 != true)
        {
            Board_Menu.Box3 = true;
            ToolTip.ToolTipSend("", true, "Beacons", true, false);
        }
        else if (command == "beacons" && Board_Menu.Box3 == true)
        {
            Board_Menu.Box3 = false;
            ToolTip.ToolTipSend("", true, "Beacons", false, false);
        }

        if (command == "trails" && Board_Menu.Box4 != true)
        {
            Board_Menu.Box4 = true;
            ToolTip.ToolTipSend("", true, "Trails", true, false);
        }
        else if (command == "trails" && Board_Menu.Box4 == true)
        {
            Board_Menu.Box4 = false;
            ToolTip.ToolTipSend("", true, "Trails", false, false);
        }

        if (command == "hollow box esp" && Board_Menu.Box5 != true)
        {
            Board_Menu.Box5 = true;
            ToolTip.ToolTipSend("", true, "Hollow Box Esp", true, false);
        }
        else if (command == "hollow box esp" && Board_Menu.Box5 == true)
        {
            Board_Menu.Box5 = false;
            ToolTip.ToolTipSend("", true, "Hollow Box Esp", false, false);
        }

        if (command == "arm esp" && Board_Menu.Box6 != true)
        {
            Board_Menu.Box6 = true;
            ToolTip.ToolTipSend("", true, "Arm Esp", true, false);
        }
        else if (command == "arm esp" && Board_Menu.Box6 == true)
        {
            Board_Menu.Box6 = false;
            ToolTip.ToolTipSend("", true, "Arm Esp", false, false);
        }

        if (command == "break freeze tag" && Board_Menu.Break != true)
        {
            Board_Menu.Break = true;
            ToolTip.ToolTipSend("", true, "Break Freeze Tag", true, false);
        }
        else if (command == "break freeze tag" && Board_Menu.Break == true)
        {
            Board_Menu.Break = false;
            ToolTip.ToolTipSend("", true, "Break Freeze Tag", false, false);
        }

        if (command == "rig gun" && Board_Menu.Force != true)
        {
            Board_Menu.Force = true;
            ToolTip.ToolTipSend("", true, "Rig Gun", true, false);
        }
        else if (command == "rig gun" && Board_Menu.Force == true)
        {
            Board_Menu.Force = false;
            ToolTip.ToolTipSend("", true, "Rig Gun", false, false);
        }

        if (command == "hold rig" && Board_Menu.Hold != true)
        {
            Board_Menu.Hold = true;
            ToolTip.ToolTipSend("", true, "Hold Rig", true, false);
        }
        else if (command == "hold rig" && Board_Menu.Hold == true)
        {
            Board_Menu.Hold = false;
            ToolTip.ToolTipSend("", true, "Hold Rig", false, false);
        }

        if (command == "elf launcher" && Board_Menu.Launch != true)
        {
            Board_Menu.Launch = true;
            ToolTip.ToolTipSend("", true, "Elf Launcher", true, false);
        }
        else if (command == "elf launcher" && Board_Menu.Launch == true)
        {
            Board_Menu.Launch = false;
            ToolTip.ToolTipSend("", true, "Elf Launcher", false, false);
        }

        if (command == "puke elves" && Board_Menu.Launch2 != true)
        {
            Board_Menu.Launch2 = true;
            ToolTip.ToolTipSend("", true, "Puke Elves", true, false);
        }
        else if (command == "puke elves" && Board_Menu.Launch2 == true)
        {
            Board_Menu.Launch2 = false;
            ToolTip.ToolTipSend("", true, "Puke Elves", false, false);
        }

        if (command == "chams" && Board_Menu.Box != true)
        {
            Board_Menu.Box = true;
            ToolTip.ToolTipSend("", true, "Chams", true, false);
        }
        else if (command == "chams" && Board_Menu.Box == true)
        {
            Board_Menu.Box = false;
            ToolTip.ToolTipSend("", true, "Chams", false, false);
        }

        if (command == "high jump" && Board_Menu.Long != true)
        {
            Board_Menu.Long = true;
            ToolTip.ToolTipSend("", true, "High Jump", true, false);
        }
        else if (command == "high jump" && Board_Menu.Long == true)
        {
            Board_Menu.Long = false;
            ToolTip.ToolTipSend("", true, "High Jump", false, false);
        }

        if (command == "anti crash" && Board_Menu.AntiCrash != true)
        {
            Board_Menu.AntiCrash = true;
            ToolTip.ToolTipSend("", true, "Anti Crash", true, false);
        }
        else if (command == "anti crash" && Board_Menu.AntiCrash == true)
        {
            Board_Menu.AntiCrash = false;
            ToolTip.ToolTipSend("", true, "Anti Crash", false, false);
        }

        if (command == "rpc protection" && Board_Menu.Rpc != true)
        {
            Board_Menu.Rpc = true;
            ToolTip.ToolTipSend("", true, "Rpc Protection", true, false);
        }
        else if (command == "rpc protection" && Board_Menu.Rpc == true)
        {
            Board_Menu.Rpc = false;
            ToolTip.ToolTipSend("", true, "Rpc Protection", false, false);
        }
        if (command == "break networking")
        {
            foreach (Photon.Realtime.Player player in PhotonNetwork.PlayerList)
            {

                player.SetCustomProperties(new ExitGames.Client.Photon.Hashtable
                            {
                              { "VCC", null },
                              { "genesis", null },
                              { "VENTERN", null },
                              { "GratePlayerSize", null },
                              { "Symex", null },
                              { "GrateEnabledModules", null },
                              { "GrateVersion", null },
                              { "Monkescale", null },
                              { "Scale", null },
                              { "GS", null },
                              { "BananaOS", null }
                              });
            }
            ToolTip.ToolTipSend("", true, "Break Mod Networking", true, false);
        }
        if (command == "reset termanial")
        {
            ModIOMapsTerminal.ResetTerminalControl();
            ToolTip.ToolTipSend("", true, "Reset Map Term Control", true, false);
        }
        if (command == "break party")
        {
            if (FriendshipGroupDetection.Instance.IsInParty)
            {
                GorillaComputer.instance.currentGameMode.Value = "MODDED_AMBUSH";
                new WaitForSeconds(0.5f);
                PhotonNetworkController.Instance.AttemptToJoinSpecificRoom("FUCKEDBYFYSFUCKEDBYFYSFUCKEDBYFYSFUCKEDBYFYSFUCKEDBYFYSFUCKEDBYFYSFUCKEDBYFYSFUCKEDBYFYSFUCKEDBYFYSFUCKEDBYFYSFUCKEDBYFYSFUCKEDBYFYSFUCKEDBYFYSFUCKEDBYFYSFUCKEDBYFYSFUCKEDBYFYSFUCKEDBYFYSFUCKEDBYFYSFUCKEDBYFYSFUCKEDBYFYSFUCKEDBYFYSFUCKEDBYFYSFUCKEDBYFYSFUCKEDBYFYSFUCKEDBYFYSFUCKEDBYFYSFUCKEDBYFYSFUCKEDBYFYSFUCKEDBYFYSFUCKEDBYFYSFUCKEDBYFYSFUCKEDBYFYSFUCKEDBYFYSFUCKEDBYFYSFUCKEDBYFYSFUCKEDBYFYSFUCKEDBYFYSFUCKEDBYFYSFUCKEDBYFYSFUCKEDBYFYSFUCKEDBYFYSFUCKEDBYFYSFUCKEDBYFYSFUCKEDBYFYSFUCKEDBYFYSFUCKEDBYFYSFUCKEDBYFYSFUCKEDBYFYSFUCKEDBYFYSFUCKEDBYFYSFUCKEDBYFYSFUCKEDBYFYSFUCKEDBYFYSFUCKEDBYFYSFUCKEDBYFYSFUCKEDBYFYSFUCKEDBYFYSFUCKEDBYFYSFUCKEDBYFYSFUCKEDBYFYSFUCKEDBYFYSFUCKEDBYFYSFUCKEDBYFYSFUCKEDBYFYSFUCKEDBYFYSFUCKEDBYFYSFUCKEDBYFYS", JoinType.ForceJoinWithParty);
            }
            ToolTip.ToolTipSend("", true, "Break Players Games", true, false);
        }
        if (command == "ban party")
        {
            if (FriendshipGroupDetection.Instance.IsInParty)
            {
                GorillaComputer.instance.currentGameMode.Value = "MODDED_AMBUSH";
                new WaitForSeconds(0.5f);
                PhotonNetworkController.Instance.AttemptToJoinSpecificRoom("KKK", JoinType.ForceJoinWithParty);
            }
            ToolTip.ToolTipSend("", true, "Delay Ban Players", true, false);
        }
        if (command == "kick")
        {
            GameObject.Find("WorldShareableCosmetic").GetComponent<RequestableOwnershipGuard>().photonView.RPC("OwnershipRequested", RpcTarget.Others, new object[] { "GYATTRIZZ".PadRight(1967) });
            if (Board_Menu.Rpc)
            {
                Sunnys_Rpc.RPCProtection();
            }
            ToolTip.ToolTipSend("", true, "Kick All", true, false);
        }
        if (command == "set guardain")
        {
            if (PhotonNetwork.IsMasterClient)
            {
                foreach (GorillaGuardianZoneManager GameMan in GorillaGuardianZoneManager.zoneManagers)
                {
                    GameMan.SetGuardian(PhotonNetwork.LocalPlayer);
                }
            }
            ToolTip.ToolTipSend("", true, "Set Guardain", true, false);
        }
        if (command == "error party")
        {
            if (FriendshipGroupDetection.Instance.IsInParty)
            {
                GorillaComputer.instance.currentGameMode.Value = "FUCKEDBYFYS";
                new WaitForSeconds(0.5f);
                PhotonNetworkController.Instance.AttemptToJoinSpecificRoom("FUCKEDBYFYSFUCKEDBYFYSFUCKEDBYFYSFUCKEDBYFYSFUCKEDBYFYSFUCKEDBYFYSFUCKEDBYFYSFUCKEDBYFYSFUCKEDBYFYSFUUCKEDBYFYSFUCKEDBYFYSFUCKEDBYFYSFUCKEDBYFYSFUCKEDBYFYSFUCKEDBYFYSFUCKEDBYFYSFUCKEDBYFYSFUCKEDBYFYSFUCKEDBYFYSFUCKEDBYFYSFUCKEDBYFYSFUCKEDBYFYSFUCKEDBYFYSFUCKEDBYFYSFUCKEDBYFYSFUCKEDBYFYSFUCKEDBYFYSFUCKEDBYFYSFUCKEDBYFYSFUCKEDBYFYSFUCKEDBYFYSFUCKEDBYFYSFUCKEDBYFYSFUCKEDBYFYSFUCKEDBYFYSFUCKEDBYFYSFUCKEDBYFYSFUCKEDBYFYSFUCKEDBYFYSFUCKEDBYFYSFUCKEDBYFYSFUCKEDBYFYSFUCKEDBYFYSFUCKEDBYFYSFUCKEDBYFYSFUCKEDBYFYSFUCKEDBYFYSFUCKEDBYFYSFUCKEDBYFYSFUCKEDBYFYSFUCKEDBYFYSFUCKEDBYFYSFUCKEDBYFYSFUCKEDBYFYSFUCKEDBYFYSFUCKEDBYFYSFUCKEDBYFYSFUCKEDBYFYSFUCKEDBYFYSFUCKEDBYFYSFUCKEDBYFYSFUCKEDBYFYSFUCKEDBYFYSFUCKEDBYFYSFUCKEDBYFYSFUCKEDBYFYSFUCKEDBYFYS", JoinType.ForceJoinWithParty);
            }
            ToolTip.ToolTipSend("", true, "Send Players To Error Code", true, false);
        }
        if (command == "pull mod" && Board_Menu.Pull != true)
        {
            Board_Menu.Pull = true;
            ToolTip.ToolTipSend("", true, "Pull Mod", true, false);
        }
        else if (command == "pull mod" && Board_Menu.Pull == true)
        {
            Board_Menu.Pull = false;
            ToolTip.ToolTipSend("", true, "Pull Mod", false, false);
        }

        if (command == "skid all" && Board_Menu.Skid != true)
        {
            Board_Menu.Skid = true;
            ToolTip.ToolTipSend("", true, "Skid All HeHeHe", true, false);
        }
        else if (command == "skid all" && Board_Menu.Skid == true)
        {
            Board_Menu.Skid = false;
            ToolTip.ToolTipSend("", true, "Skid All HeHeHe", false, false);
        }

        if (command == "ghost monkey" && Board_Menu.Ghost != true)
        {
            Board_Menu.Ghost = true;
            ToolTip.ToolTipSend("", true, "Ghost Monke", true, false);
        }
        else if (command == "ghost monkey" && Board_Menu.Ghost == true)
        {
            Board_Menu.Ghost = false;
            ToolTip.ToolTipSend("", true, "Ghost Monke", false, false);
        }

        if (command == "invisible" && Board_Menu.Invis != true)
        {
            Board_Menu.Invis = true;
            ToolTip.ToolTipSend("", true, "Invis Monke", true, false);
        }
        else if (command == "invisible" && Board_Menu.Invis == true)
        {
            Board_Menu.Invis = false;
            ToolTip.ToolTipSend("", true, "Invis Monke", false, false);
        }

        if (command == "tag gun" && Board_Menu.Tag6 != true)
        {
            Board_Menu.Tag6 = true;
            ToolTip.ToolTipSend("", true, "Tag Gun", true, false);
        }
        else if (command == "tag gun" && Board_Menu.Tag6 == true)
        {
            Board_Menu.Tag6 = false;
            ToolTip.ToolTipSend("", true, "Tag Gun", false, false);
        }

        if (command == "long arms" && Board_Menu.Long2 != true)
        {
            Board_Menu.Long2 = true;
            ToolTip.ToolTipSend("", true, "Long Arms", true, false);
        }
        else if (command == "long arms" && Board_Menu.Long2 == true)
        {
            Board_Menu.Long2 = false;
            ToolTip.ToolTipSend("", true, "Long Arms", false, false);
        }
        if (command == "whats the best comp menu")
        {
            ToolTip.ToolTipSend("VOICE", false, "CCMV2", true, true);
        }
        if (command == "dissconect" || command == "leave")
        {
            PhotonNetwork.Disconnect();
            ToolTip.ToolTipSend("VOICE", false, "Leaving Room", true, true);
        }
        if (command == "who has the best gun lib")
        {
            ToolTip.ToolTipSend("VOICE", false, "Sunny Dee", true, true);
        }
    }
    public static void StopVoiceRecognition()
    {
        voice.Stop();
        voice.Dispose();
    }
}
