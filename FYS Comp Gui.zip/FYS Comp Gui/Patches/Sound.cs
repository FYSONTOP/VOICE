﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Text;
using UnityEngine.Networking;
using UnityEngine;

namespace FYS_Comp_Gui.Patches
{
    internal class Sound
    {
        public static string Subdirectory = "";
        public static bool LoopAudio = false;
        public static bool AudioIsPlaying = false;
        public static float RecoverTime = -1f;
        public static float Length = 2;

        public static string soundFileToPlay = "name of the file you want to play (you can probably figure out how to make it use buttons on ur menu) for example skibiditoilet10hours";
        public static AudioClip LoadSoundFromFile(string file)
        {
            string rootPath = @"C:\Program Files (x86)\Steam\steamapps\common\Gorilla Tag\FYSMenu";
            string filePath = Path.Combine(rootPath, Subdirectory, file);

            if (!File.Exists(filePath))
            {
                Debug.LogError("Sound file not found: " + filePath);
                return null;
            }
            using (var www = UnityWebRequestMultimedia.GetAudioClip("file://" + filePath, AudioType.WAV))
            {
                www.SendWebRequest();
                while (!www.isDone) { }

                if (www.result != UnityWebRequest.Result.Success)
                {
                    Debug.LogError($"Failed to load audio file: {www.error}");
                    return null;
                }

                return DownloadHandlerAudioClip.GetContent(www);
            }
        }
        public static void PlayAudio(string file)
        {
            AudioClip sound = LoadSoundFromFile(file);
            Length = sound.length;
            if (sound == null)
            {
                return;
            }
            if (sound.frequency != 48000)
            {
                sound = ResampleAudioClip(sound, 48000);
            }

            var recorder = GorillaTagger.Instance.myRecorder;

            recorder.SourceType = Photon.Voice.Unity.Recorder.InputSourceType.AudioClip;
            recorder.AudioClip = sound;
            recorder.LoopAudioClip = false;
            recorder.RestartRecording(true);
            recorder.DebugEchoMode = true;
            GorillaTagger.Instance.StartCoroutine(ResetRecorderAfterAudioPlay());
        }
        private static IEnumerator ResetRecorderAfterAudioPlay()
        {
            yield return new WaitForSeconds(Length);

            ResetMic();
        }
        public static void ResetMic()
        {
            GorillaTagger.Instance.myRecorder.SourceType = Photon.Voice.Unity.Recorder.InputSourceType.Microphone;
            GorillaTagger.Instance.myRecorder.AudioClip = null;
            GorillaTagger.Instance.myRecorder.RestartRecording(true);
            GorillaTagger.Instance.myRecorder.DebugEchoMode = false;
            AudioIsPlaying = false;
            RecoverTime = -1f;
        }

        public static AudioClip ResampleAudioClip(AudioClip clip, int newSampleRate)
        {
            float[] originalData = new float[clip.samples * clip.channels];
            clip.GetData(originalData, 0);
            int newSamplesCount = Mathf.RoundToInt((float)newSampleRate / clip.frequency * clip.samples);
            float[] newData = new float[newSamplesCount * clip.channels];
            for (int i = 0; i < newSamplesCount; i++)
            {
                float t = (float)i / newSamplesCount;
                int originalIndex = Mathf.RoundToInt(t * clip.samples);
                originalIndex = Mathf.Clamp(originalIndex, 0, clip.samples - 1);
                for (int c = 0; c < clip.channels; c++)
                {
                    newData[i * clip.channels + c] = originalData[originalIndex * clip.channels + c];
                }
            }
            AudioClip newClip = AudioClip.Create(clip.name, newSamplesCount, clip.channels, newSampleRate, false);
            newClip.SetData(newData, 0);
            return newClip;
        }
        public static void LoadSounds()
        {
            string soundFolder = "FYSMenu/Sounds" + Subdirectory;
            if (!Directory.Exists(soundFolder))
            {
                Directory.CreateDirectory(soundFolder);
                Debug.Log("Sound folder created: " + soundFolder);
            }

            List<string> soundFiles = new List<string>();
            string[] files = Directory.GetFiles(soundFolder);
            foreach (string file in files)
            {
                string fileName = Path.GetFileName(file);
                string soundName = RemoveFileExtension(fileName).Replace("_", " ");
                soundFiles.Add(soundName);
                Debug.Log("Found sound file: " + soundName);
            }
        }
        public static string RemoveFileExtension(string fileName)
        {
            return Path.GetFileNameWithoutExtension(fileName);
        }
    }
}
