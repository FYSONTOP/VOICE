﻿using GorillaTagScripts;
using Photon.Pun;
using System;
using System.Collections.Generic;
using UnityEngine;
using GorillaNetworking;
using HarmonyLib;

[HarmonyPatch(typeof(PhotonView), "Rpc")]
public class AntiKick : MonoBehaviour
{
    private PhotonView netView;
    private List<IOwnershipRequestCallback> callbacksList = new List<IOwnershipRequestCallback>();
    void Awake()
    {
        netView = GetComponent<PhotonView>();
    }
    [PunRPC]
    public void OwnershipRequested(string nonce, PhotonMessageInfo info)
    {
        if (info.Sender == null)
        {
            Debug.LogWarning("Ownership request sender is null. Ignoring request.");
            return;
        }
        if (info.Sender == PhotonNetwork.LocalPlayer)
        {
            Debug.Log("Ownership request from local player ignored.");
            return;
        }
        if (string.IsNullOrEmpty(nonce) || nonce.Length > 256)
        {
            Debug.LogWarning($"Invalid nonce length from {info.Sender.NickName}. Possible exploit attempt.");
            return;
        }
        bool isRequestValid = true;
        foreach (var callback in callbacksList)
        {
            if (!callback.OnOwnershipRequest(info.Sender))
            {
                isRequestValid = false;
                break;
            }
        }
        if (!isRequestValid)
        {
            Debug.LogWarning($"Ownership request denied for {info.Sender.NickName}.");
            netView.RPC("OwnershipRequestDenied", info.Sender, nonce);
            return;
        }

        Debug.Log($"Ownership request from {info.Sender.NickName} validated.");
    }
    public void RegisterCallback(IOwnershipRequestCallback callback)
    {
        if (!callbacksList.Contains(callback))
        {
            callbacksList.Add(callback);
        }
    }
    public void UnregisterCallback(IOwnershipRequestCallback callback)
    {
        if (callbacksList.Contains(callback))
        {
            callbacksList.Remove(callback);
        }
    }
}
public interface IOwnershipRequestCallback
{
    bool OnOwnershipRequest(Photon.Realtime.Player sender);
}