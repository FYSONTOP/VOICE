﻿using GorillaTagScripts;
using Photon.Pun;
using System;
using System.Collections.Generic;
using System.Text;
using TMPro;
using UnityEngine.InputSystem;
using UnityEngine;
using GorillaLocomotion;
using Photon.Realtime;
using ExitGames.Client.Photon;
using System.Linq;
using StupidTemplate;
using Utilla;
using GorillaNetworking;
using OculusSampleFramework;
using GorillaGameModes;
using StupidTemplate.Patches;
using FYS_Comp_Gui.Patches;
using static UnityEngine.RectTransform;
using sunnydees_cool_mod;
using UnityEngine.UIElements;
using System.Reflection;
using HarmonyLib;

namespace FYS_Menu.Menu
{
    internal class Board_Menu
    {
        public static bool Wait = true;
        public static bool Launch = false;
        public static bool Launch2 = false;
        public static bool Launch3 = false;
        public static bool Launch4 = false;
        public static bool Fly = false;
        public static bool Box = false;
        public static bool GameSense = false;
        public static bool Start = true;
        public static bool ModsAll = false;
        public static bool Spam = false;
        public static bool Spam2 = false;
        public static bool Pull = false;
        public static bool Tag = false;
        public static bool Skid = false;
        public static bool Trace = false;
        public static bool Stream = false;
        public static bool Tag2 = false;
        public static bool Tag3 = false;
        public static bool Tag4 = false;
        public static bool Box2 = false;
        public static bool Box3 = false;
        public static bool Box4 = false;
        public static bool Thin = false;
        public static bool Lag = false;
        public static bool Stare = true;
        public static bool Break = false;
        public static bool Freeze = false;
        public static bool Fly2 = false;
        public static bool Pred = false;
        public static bool Long = false;
        public static bool Long2 = false;
        public static bool Wall = false;
        public static bool Game = false;
        public static bool Hide = false;
        public static bool Effect = false;
        public static bool Key = false;
        public static bool Ghost = false;
        public static bool Invis = false;
        public static bool thingy = false;
        public static bool Force = false;
        public static bool Fist = false;
        public static bool Hold = false;
        public static bool Tag5 = false;
        public static bool Tag6 = false;
        public static bool Box5 = false;
        public static bool Box6 = false;
        public static bool Rpc = true;
        public static bool AntiCrash = false;
        private static float Prev = 0f;
        private static float fps = 0;
        private static float Prev2 = 0f;
        private static float Prev3 = 0f;
        private static int Mod = 0;
        private static int Vel = 0;
        private static int EspColour = 0;
        private static float last = 0f;
        private static float last2 = 0f;
        private static float last3 = 0f;
        private static float inputDelay = 0.2f;
        private static float Size = 0f;
        private static int Cat = 0;
        private static float Fps = 0f;
        private static float Pull3 = 40f;
        private static float Vel2 = 1.05f;
        private static float Speed = 15f;
        private static int Length = 1;
        private static int Pull2 = 0;
        private static float Length2 = 1.1f;
        public static float Distance = 0f;
        private static string Colour = "Purple";
        private static string Arm = "Short";
        private static string Pull4 = "Weak";
        private static string Cat2 = "Main";
        private static string Vel3 = "Legit";
        private static string Name = "";
        public static VRRig GetClosestVRRig()
        {
            float num = float.MaxValue;
            VRRig outRig = null;
            foreach (VRRig vrrig in GorillaParent.instance.vrrigs)
            {
                if (Vector3.Distance(GorillaTagger.Instance.bodyCollider.transform.position, vrrig.transform.position) < num)
                {
                    num = Vector3.Distance(GorillaTagger.Instance.bodyCollider.transform.position, vrrig.transform.position);
                    if (vrrig != GorillaTagger.Instance.offlineVRRig)
                    {
                        outRig = vrrig;
                    }
                }
            }
            return outRig;
        }
        private static NetworkView GetNetworkViewFromVRRig(VRRig p)
        {
            return (NetworkView)Traverse.Create(p).Field("netView").GetValue();
        }
        private static VRRig Edge = null;
        private static VRRig Edge2 = null;
        public static void SeeRig()
        {
            if (Edge == null)
            {
                Edge = UnityEngine.Object.Instantiate<VRRig>(GorillaTagger.Instance.offlineVRRig, GorillaTagger.Instance.transform.position, GorillaTagger.Instance.transform.rotation);
                Edge.enabled = false;
                Edge.transform.position = Vector3.zero;
            }
            if (!GorillaTagger.Instance.offlineVRRig.enabled)
            {
                Edge.enabled = true;
                Edge.rightHandTransform.position = GorillaTagger.Instance.rightHandTransform.position;
                Edge.leftHandTransform.position = GorillaTagger.Instance.leftHandTransform.position;
                Edge.rightHandTransform.rotation = GorillaTagger.Instance.rightHandTransform.rotation;
                Edge.leftHandTransform.rotation = GorillaTagger.Instance.leftHandTransform.rotation;
                Edge.transform.position = GorillaTagger.Instance.transform.position;
                Edge.transform.rotation = GorillaTagger.Instance.transform.rotation;
            }
            else
            {
                Edge.enabled = false;
                Edge.transform.position = Vector3.zero;
            }
            if (EspColour == 0)
            {
                Edge.mainSkin.material.color = Color.magenta - new Color(0f, 0f, 0f, 0.5f);
            }
            if (EspColour == 1)
            {
                Edge.mainSkin.material.color = Color.green - new Color(0f, 0f, 0f, 0.5f);
            }
            if (EspColour == 2)
            {
                Edge.mainSkin.material.color = Color.grey - new Color(0f, 0f, 0f, 0.5f);
            }
            if (EspColour == 3)
            {
                Edge.mainSkin.material.color = Color.blue - new Color(0f, 0f, 0f, 0.5f);
            }
            if (EspColour == 4)
            {
                Edge.mainSkin.material.color = Color.black - new Color(0f, 0f, 0f, 0.5f);
            }
            if (EspColour == 5)
            {
                Edge.mainSkin.material.color = Color.yellow - new Color(0f, 0f, 0f, 0.5f);
            }
            if (EspColour == 6)
            {
                Edge.mainSkin.material.color = Color.red - new Color(0f, 0f, 0f, 0.5f);
            }
            Edge.mainSkin.material.shader = Shader.Find("GUI/Text Shader");
        }
        public static void FlyEffect()
        {
            GameObject BallRain = GameObject.CreatePrimitive(PrimitiveType.Sphere);
            BallRain.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
            BallRain.GetComponent<Renderer>().material.color = Color.magenta;
            GameObject.Destroy(BallRain.GetComponent<Rigidbody>());
            GameObject.Destroy(BallRain.GetComponent<SphereCollider>());
            BallRain.transform.localScale = new Vector3(0.1f, 0.1f, 0.1f);
            BallRain.transform.position = GorillaTagger.Instance.offlineVRRig.transform.position + new Vector3(UnityEngine.Random.Range(-2f, 2f), UnityEngine.Random.Range(-2f, 2f), UnityEngine.Random.Range(-2f, 2f));
            UnityEngine.Object.Destroy(BallRain, 2f);
        }
        public static void Menu()
        {
            SeeRig();
            if (Time.time - last > 1f)
            {
                if (ControllerInputPoller.instance.leftControllerSecondaryButton && ControllerInputPoller.instance.rightControllerSecondaryButton && !Hide)
                {
                    last = Time.time;
                    Hide = true;
                }
                else if (ControllerInputPoller.instance.leftControllerSecondaryButton && ControllerInputPoller.instance.rightControllerSecondaryButton && Hide)
                {
                    last = Time.time;
                    Hide = false;
                    Key = false;
                }
                if (ControllerInputPoller.instance.leftControllerPrimaryButton && ControllerInputPoller.instance.rightControllerPrimaryButton && !Key)
                {
                    last = Time.time;
                    Key = true;
                    Hide = true;
                }
                else if (ControllerInputPoller.instance.leftControllerPrimaryButton && ControllerInputPoller.instance.rightControllerPrimaryButton && Key)
                {
                    last = Time.time;
                    Key = false;
                    Hide = false;
                }
            }
            if (Key)
            {
                Key_Board.Start();
            }
            //TEXT SHIT
            GameObject text = new GameObject("Gui");
            TextMeshPro tmp = text.AddComponent<TextMeshPro>();
            tmp.fontSize = 0.35f;
            tmp.alignment = TextAlignmentOptions.Center;
            text.transform.position = Camera.main.transform.position + Camera.main.transform.forward * 1 - Camera.main.transform.right * 0.4f;
            text.transform.SetParent(Camera.main.transform);
            text.transform.LookAt(Camera.main.transform);
            text.transform.Rotate(0, 180, 0);
            text.layer = 19;
            GameObject text4 = new GameObject("Time");
            TextMeshPro tmp4 = text4.AddComponent<TextMeshPro>();
            tmp4.fontSize = 0.35f;
            tmp4.alignment = TextAlignmentOptions.Center;
            text4.transform.position = Camera.main.transform.position + Camera.main.transform.forward * 1 - Camera.main.transform.right * 0.4f - Camera.main.transform.up * 0.3f;
            text4.transform.SetParent(Camera.main.transform);
            text4.transform.LookAt(Camera.main.transform);
            text4.transform.Rotate(0, 180, 0);
            text4.layer = 19;
            tmp4.text = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");
            TMP_Text cocText = text.GetComponent<TMP_Text>();
            GameObject text2 = new GameObject("Title");
            TextMeshPro tmp2 = text2.AddComponent<TextMeshPro>();
            tmp2.fontSize = 0.35f;
            text2.layer = 19;
            tmp2.alignment = TextAlignmentOptions.Center;
            text2.transform.position = text.transform.position + new Vector3(0f, 0.25f, 0f);
            text2.transform.SetParent(text.transform);
            text2.transform.rotation = text.transform.rotation;
            TMP_Text cocTitle = text2.GetComponent<TMP_Text>();
            cocTitle.text = $"FYS Gui Menu: {Cat2}\nPing:{PhotonNetwork.GetPing()}                 Region:{PhotonNetwork.CloudRegion}\nFPS:{Fps}";
            GameObject text3 = new GameObject("Enabled");
            TextMeshPro tmp3 = text3.AddComponent<TextMeshPro>();
            tmp3.fontSize = 0.35f;
            tmp3.alignment = TextAlignmentOptions.Center;
            text3.transform.position = Camera.main.transform.position + Camera.main.transform.forward * 1 + Camera.main.transform.right * 0.4f;
            text3.transform.SetParent(Camera.main.transform);
            text3.transform.LookAt(Camera.main.transform);
            text3.layer = 19;
            text3.transform.Rotate(0, 180, 0);
            tmp3.text = "Enabled Mods:\n";
            if (Long)
            {
                tmp3.text += "High Jump\n";
            }
            if (Long2)
            {
                tmp3.text += "Long Arms\n";
            }
            if (Fly)
            {
                tmp3.text += "Fly\n";
            }
            if (Fly2)
            {
                tmp3.text += "Joystick Fly\n";
            }
            if (Thin)
            {
                tmp3.text += "Thin Tracers\n";
            }
            if (Box)
            {
                tmp3.text += "Chams\n";
            }
            if (Box2)
            {
                tmp3.text += "Box Esp\n";
            }
            if (Trace)
            {
                tmp3.text += "Tracers\n";
            }
            if (Lag)
            {
                tmp3.text += "Lag Rig NW\n";
            }
            if (Tag4)
            {
                tmp3.text += "Tag All\n";
            }
            if (Tag)
            {
                tmp3.text += "Flick Tag\n";
            }
            if (Tag2)
            {
                tmp3.text += "Tag Aimbot\n";
            }
            if (Tag3)
            {
                tmp3.text += "Tag Aura\n";
            }
            if (Box3)
            {
                tmp3.text += "Beacons\n";
            }
            if (Stream)
            {
                tmp3.text += "Streamable Esp\n";
            }
            if (Skid)
            {
                tmp3.text += "Skid All\n";
            }
            if (Pred)
            {
                tmp3.text += "Preds NW\n";
            }
            if (Box4)
            {
                tmp3.text += "Trails\n";
            }
            if (Break)
            {
                tmp3.text += "Break Freeze Tag\n";
            }
            if (Pull)
            {
                tmp3.text += "Pull Mod\n";
            }
            if (Ghost)
            {
                tmp3.text += "Ghost Monke\n";
            }
            if (Invis)
            {
                tmp3.text += "Invis Monke\n";
            }
            if (Force)
            {
                tmp3.text += "Rig Gun\n";
            }
            if (Hold)
            {
                tmp3.text += "Hold Rig\n";
            }
            if (Tag5)
            {
                tmp3.text += "Tag Self\n";
            }
            if (Tag6)
            {
                tmp3.text += "Tag Gun\n";
            }
            if (Box5)
            {
                tmp3.text += "Hollow Box Esp\n";
            }
            if (Box6)
            {
                tmp3.text += "Arm Esp\n";
            }
            if (AntiCrash)
            {
                tmp3.text += "Anti Crash\n";
            }
            if (Rpc)
            {
                tmp3.text += "Rpc Protection\n";
            }
            if (GameSense)
            {
                tmp3.text += "Tracers From Body\n";
            }
            if (Launch)
            {
                tmp3.text += "Elf Launcher\n";
            }
            if (Launch3)
            {
                tmp3.text += "Kick All\n";
            }
            if (Launch2)
            {
                tmp3.text += "Puke Elves\n";
            }
            if (Launch4)
            {
                tmp3.text += "Kick Gun\n";
            }
            UnityEngine.Object.Destroy(text4, Time.deltaTime);
            UnityEngine.Object.Destroy(text3, Time.deltaTime);
            UnityEngine.Object.Destroy(text2, Time.deltaTime);
            UnityEngine.Object.Destroy(text, Time.deltaTime);
            string Steam = "";
            string Special = "";
            string Mods = "";
            if (Mod < 0)
            {
                Mod = 6;
            }
            if (Mod > 6)
            {
                Mod = 0;
            }
            if (EspColour > 6)
            {
                EspColour = 0;
            }
            if (Length > 5)
            {
                Length = 1;
            }
            if (Pull2 > 3)
            {
                Pull2 = 0;
            }
            if (Vel > 4)
            {
                Vel = 0;
            }
            if (Pull2 == 0)
            {
                Pull3 = 40f;
                Pull4 = "Weak";
            }
            if (Pull2 == 1)
            {
                Pull3 = 30f;
                Pull4 = "Normal";
            }
            if (Pull2 == 2)
            {
                Pull3 = 20f;
                Pull4 = "Strong";
            }
            if (Pull2 == 3)
            {
                Pull3 = 10f;
                Pull4 = "Extra Strong";
            }
            if (Length == 1)
            {
                Arm = "Short";
                Length2 = 1.1f;
            }
            if (Length == 2)
            {
                Arm = "Semi Short";
                Length2 = 1.2f;
            }
            if (Length == 3)
            {
                Arm = "Medium";
                Length2 = 1.3f;
            }
            if (Length == 4)
            {
                Arm = "Long";
                Length2 = 1.4f;
            }
            if (Length == 5)
            {
                Arm = "Ghost Troll";
                Length2 = 1.5f;
            }
            if (EspColour == 0)
            {
                Colour = "Purple";
            }
            if (EspColour == 1)
            {
                Colour = "Green";
            }
            if (EspColour == 2)
            {
                Colour = "Grey";
            }
            if (EspColour == 3)
            {
                Colour = "Blue";
            }
            if (EspColour == 4)
            {
                Colour = "Black";
            }
            if (EspColour == 5)
            {
                Colour = "Yellow";
            }
            if (EspColour == 6)
            {
                Colour = "Red";
            }
            if (Cat == 0)
            {
                Cat2 = "Main";
            }
            if (Cat == 1)
            {
                Cat2 = "Movement";
            }
            if (Cat == 2)
            {
                Cat2 = "Visual";
            }
            if (Cat == 3)
            {
                Cat2 = "Spoof";
            }
            if (Cat == 4)
            {
                Cat2 = "Advant";
            }
            if (Cat == 5)
            {
                Cat2 = "Misc";
            }
            if (Cat == 6)
            {
                Cat2 = "Settings";
            }
            if (Cat == 7)
            {
                Cat2 = "Op";
            }
            if (EspColour == 0)
            {
                cocText.color = Color.white;
                cocTitle.color = Color.magenta;
                tmp3.color = Color.magenta;
            }
            if (EspColour == 1)
            {
                cocText.color = Color.white;
                cocTitle.color = Color.green;
                tmp3.color = Color.green;
            }
            if (EspColour == 2)
            {
                cocText.color = Color.white;
                cocTitle.color = Color.grey;
                tmp3.color = Color.grey;
            }
            if (EspColour == 3)
            {
                cocText.color = Color.white;
                cocTitle.color = Color.blue;
                tmp3.color = Color.blue;
            }
            if (EspColour == 4)
            {
                cocText.color = Color.white;
                cocTitle.color = Color.black;
                tmp3.color = Color.black;
            }
            if (EspColour == 5)
            {
                cocText.color = Color.white;
                cocTitle.color = Color.yellow;
                tmp3.color = Color.yellow;
            }
            if (EspColour == 6)
            {
                cocText.color = Color.white;
                cocTitle.color = Color.red;
                tmp3.color = Color.red;
            }
            foreach (VRRig vrrig in GorillaParent.instance.vrrigs)
            {
                if (vrrig.concatStringOfCosmeticsAllowed.Contains("FIRST LOGIN") && !Steam.Contains(vrrig.OwningNetPlayer.NickName))
                {
                    Steam += vrrig.OwningNetPlayer.NickName + "  " + "ID: " + vrrig.OwningNetPlayer.UserId + "\n";
                }
                if (vrrig.concatStringOfCosmeticsAllowed.Contains("LBAGS") && !Steam.Contains(vrrig.OwningNetPlayer.NickName))
                {
                    Special += vrrig.OwningNetPlayer.NickName + "  " + "ID: " + vrrig.OwningNetPlayer.UserId + " Cosmetics" + "ILLUSTRATOR\n";
                }
                if (vrrig.concatStringOfCosmeticsAllowed.Contains("LBAAD") && !Steam.Contains(vrrig.OwningNetPlayer.NickName))
                {
                    Special += vrrig.OwningNetPlayer.NickName + "  " + "ID: " + vrrig.OwningNetPlayer.UserId + " Cosmetics" + "ADMIN\n";
                }
                if (vrrig.concatStringOfCosmeticsAllowed.Contains("LBAAK") && !Steam.Contains(vrrig.OwningNetPlayer.NickName))
                {
                    Special += vrrig.OwningNetPlayer.NickName + "  " + "ID: " + vrrig.OwningNetPlayer.UserId + " Cosmetics" + "STICK\n";
                }
                if (vrrig.concatStringOfCosmeticsAllowed.Contains("LBADE") && !Steam.Contains(vrrig.OwningNetPlayer.NickName))
                {
                    Special += vrrig.OwningNetPlayer.NickName + "  " + "ID: " + vrrig.OwningNetPlayer.UserId + " Cosmetics" + "FINGER PAINTER\n";
                }
                if (vrrig.concatStringOfCosmeticsAllowed.Contains("LBACP") && !Steam.Contains(vrrig.OwningNetPlayer.NickName))
                {
                    Special += vrrig.OwningNetPlayer.NickName + "  " + "ID: " + vrrig.OwningNetPlayer.UserId + " Cosmetics" + "UNRELEASED SWEATER\n";
                }
            }
            foreach (Photon.Realtime.Player plr in PhotonNetwork.PlayerList)
            {
                if (plr.CustomProperties.ContainsKey("genesis") && !Mods.Contains(plr.NickName))
                {
                    Mods += plr.NickName + "  " + "ID: " + plr.UserId + "  " + "Mods: " + "Genesis Menu\n";
                }
                if (plr.CustomProperties.ContainsKey("FYS") && !Mods.Contains(plr.NickName))
                {
                    Mods += plr.NickName + "  " + "ID: " + plr.UserId + "  " + "Mods: " + "FYS Menu\n";
                }
                if (plr.CustomProperties.ContainsKey("VCC") && !Mods.Contains(plr.NickName))
                {
                    Mods += plr.NickName + "  " + "ID: " + plr.UserId + "  " + "Mods: " + "VCC\n";
                }
                if (plr.CustomProperties.ContainsKey("void_menu_pos") && !Mods.Contains(plr.NickName))
                {
                    Mods += plr.NickName + "  " + "ID: " + plr.UserId + "  " + "Mods: " + "Void Menu\n";
                }
                if (plr.CustomProperties.ContainsKey("SDMENU") && !Mods.Contains(plr.NickName))
                {
                    Mods += plr.NickName + "  " + "ID: " + plr.UserId + "  " + "Mods: " + "SdMenu\n";
                }
                if (plr.CustomProperties.ContainsKey("SpacelolUser") && !Mods.Contains(plr.NickName))
                {
                    Mods += plr.NickName + "  " + "ID: " + plr.UserId + "  " + "Mods: " + "Space.lol\n";
                }
                if (plr.CustomProperties.ContainsKey("FYSOwn") && !Mods.Contains(plr.NickName))
                {
                    Mods += plr.NickName + "  " + "ID: " + plr.UserId + "  " + "Mods: " + "Owner Of This Menu Lol\n";
                }
                if (plr.CustomProperties.ContainsKey("colossal") && !Mods.Contains(plr.NickName))
                {
                    Mods += plr.NickName + "  " + "ID: " + plr.UserId + "  " + "Mods: " + "CCMV2\n";
                }
            }
            TMP_Text MotdText = GameObject.Find("motdtext").GetComponent<TMP_Text>();
            TMP_Text MotdTitle = GameObject.Find("motd (1)").GetComponent<TMP_Text>();
            MotdText.text = "Steam Users\n" + Steam + "\n\nMod Users\n" + Mods + "\n\nSpecial Cosmetics\n" + Special;
            MotdText.color = Color.red;
            MotdTitle.text = "Mod Check Shit";
            MotdTitle.color = Color.red;
            last2 = Time.time;
            if (Time.time - last > 30f || Hide)
            {
                Mod = 7;
                Cat = 0;
            }
            // ENABLE MODS
            if (Fly)
            {
                if (ControllerInputPoller.instance.rightControllerSecondaryButton)
                {
                    GorillaLocomotion.Player.Instance.transform.position += GorillaLocomotion.Player.Instance.headCollider.transform.forward * Time.deltaTime * 25;
                    GorillaLocomotion.Player.Instance.GetComponent<Rigidbody>().velocity = Vector3.zero;
                }
                GorillaLocomotion.Player.Instance.bodyCollider.attachedRigidbody.AddForce(Vector3.up * (Time.deltaTime * (9.81f / Time.deltaTime)), ForceMode.Acceleration);
                GorillaLocomotion.Player.Instance.transform.position += GorillaTagger.Instance.headCollider.transform.forward * Time.deltaTime * 0;
                GorillaLocomotion.Player.Instance.GetComponent<Rigidbody>().velocity = Vector3.zero;
                if (Effect)
                {
                    FlyEffect();
                }
            }
            if (Fly2)
            {
                if (ControllerInputPoller.instance.rightControllerPrimary2DAxis.y > 0.5f)
                {
                    GorillaLocomotion.Player.Instance.transform.position += GorillaLocomotion.Player.Instance.headCollider.transform.forward * Time.deltaTime * Speed;
                    GorillaLocomotion.Player.Instance.GetComponent<Rigidbody>().velocity = Vector3.zero;
                }
                if (ControllerInputPoller.instance.rightControllerPrimary2DAxis.y < -0.5f)
                {
                    GorillaLocomotion.Player.Instance.transform.position -= GorillaLocomotion.Player.Instance.headCollider.transform.forward * Time.deltaTime * Speed;
                    GorillaLocomotion.Player.Instance.GetComponent<Rigidbody>().velocity = Vector3.zero;
                }
                if (ControllerInputPoller.instance.rightControllerPrimary2DAxis.x < -0.5f)
                {
                    GorillaLocomotion.Player.Instance.transform.position -= GorillaLocomotion.Player.Instance.headCollider.transform.right * Time.deltaTime * Speed;
                    GorillaLocomotion.Player.Instance.GetComponent<Rigidbody>().velocity = Vector3.zero;
                }
                if (ControllerInputPoller.instance.rightControllerPrimary2DAxis.x > 0.5f)
                {
                    GorillaLocomotion.Player.Instance.transform.position += GorillaLocomotion.Player.Instance.headCollider.transform.right * Time.deltaTime * Speed;
                    GorillaLocomotion.Player.Instance.GetComponent<Rigidbody>().velocity = Vector3.zero;
                }
                if (ControllerInputPoller.instance.rightControllerIndexFloat > 0.5f)
                {
                    GorillaLocomotion.Player.Instance.transform.position += GorillaLocomotion.Player.Instance.transform.up * Time.deltaTime * Speed;
                    GorillaLocomotion.Player.Instance.GetComponent<Rigidbody>().velocity = Vector3.zero;
                }
                if (ControllerInputPoller.instance.leftControllerIndexFloat > 0.5f)
                {
                    GorillaLocomotion.Player.Instance.transform.position -= GorillaLocomotion.Player.Instance.transform.up * Time.deltaTime * Speed;
                    GorillaLocomotion.Player.Instance.GetComponent<Rigidbody>().velocity = Vector3.zero;
                }
                if (ControllerInputPoller.instance.leftControllerSecondaryButton)
                {
                    Speed = 50f;
                }
                else
                {
                    Speed = 15f;
                }
                GorillaLocomotion.Player.Instance.bodyCollider.attachedRigidbody.AddForce(Vector3.up * (Time.deltaTime * (9.81f / Time.deltaTime)), ForceMode.Acceleration);
                GorillaLocomotion.Player.Instance.transform.position += GorillaTagger.Instance.headCollider.transform.forward * Time.deltaTime * 0;
                GorillaLocomotion.Player.Instance.GetComponent<Rigidbody>().velocity = Vector3.zero;
                if (Effect)
                {
                    FlyEffect();
                }
            }
            if (Lag)
            {
                GorillaTagger.Instance.offlineVRRig.lerpValueBody = 1;
                GorillaTagger.Instance.offlineVRRig.lerpValueFingers = 1;
            }
            if (Force)
            {
                GunLib.UpdateGun(false);

                if (GunLib.GunShowen && GunLib.GunTrigger)
                {
                    Vector3 spawnPosition = GunLib.GunPos();
                    GorillaTagger.Instance.offlineVRRig.enabled = false;
                    GorillaTagger.Instance.offlineVRRig.transform.position = spawnPosition + new Vector3(0f, 1f, 0f);
                }
                else
                {
                    GorillaTagger.Instance.offlineVRRig.enabled = true;
                }
            }
            if (Hold)
            {
                if (ControllerInputPoller.instance.rightGrab)
                {
                    GorillaTagger.Instance.offlineVRRig.enabled = false;
                    GorillaTagger.Instance.offlineVRRig.transform.position = GorillaTagger.Instance.rightHandTransform.position;
                    GorillaTagger.Instance.offlineVRRig.transform.rotation = GorillaTagger.Instance.rightHandTransform.rotation;
                }
            }
            if (Tag5)
            {
                foreach (VRRig vrrig in GorillaParent.instance.vrrigs)
                {
                    if (!GorillaTagger.Instance.offlineVRRig.mainSkin.material.name.Contains("fected") && !GorillaTagger.Instance.offlineVRRig.mainSkin.material.name.Contains("It") && !GorillaTagger.Instance.offlineVRRig.mainSkin.material.name.Contains("Ice"))
                    {
                        if (vrrig.mainSkin.material.name.Contains("fected") || vrrig.mainSkin.material.name.Contains("It") || vrrig.mainSkin.material.name.Contains("Ice"))
                        {
                            GorillaTagger.Instance.offlineVRRig.enabled = false;
                            GorillaTagger.Instance.offlineVRRig.transform.position -= new Vector3(0f, 25f, 0f);
                            new WaitForSeconds(0.2f);
                            GorillaTagger.Instance.offlineVRRig.transform.position = vrrig.rightHandTransform.position;
                            new WaitForSeconds(0.1f);
                            GorillaTagger.Instance.offlineVRRig.enabled = true;
                        }
                        else
                        {
                            GorillaTagger.Instance.offlineVRRig.enabled = true;
                        }
                    }
                    else
                    {
                        GorillaTagger.Instance.offlineVRRig.enabled = true;
                    }
                }
            }
            if (AntiCrash)
            {
                //ANTI CRASH
                fps = 1f / Time.deltaTime;
                Application.targetFrameRate = -1;
                PhotonNetworkController.Instance.disableAFKKick = true;
                if (fps <= 10)
                {
                    new WaitForSeconds(2f);
                    if (fps <= 10)
                    {
                        BuilderTable.instance.ClearTable();
                        ToolTip.ToolTipSend("", true, "Anti Block Spam", true, true);
                    }
                }
                if (fps < 6)
                {
                    if (GameObject.Find("GlobalObjectPools") != null)
                    {
                        new WaitForSeconds(2f);
                        if (fps <= 6)
                        {
                            GameObject.Find("GlobalObjectPools").SetActive(false);
                            ToolTip.ToolTipSend("", true, "Anti Effect Spam", true, true);
                        }
                    }
                }
            }
            if (Tag6)
            {
                GunLib.UpdateGun(true);

                if (GunLib.GunShowen && GunLib.GunTrigger && Time.time - last3 > 0.5f)
                {
                    last3 = Time.time;
                    VRRig aimedRig = GunLib.RigAimedAt();
                    if (GorillaTagger.Instance.offlineVRRig.mainSkin.material.name.Contains("fected") || GorillaTagger.Instance.offlineVRRig.mainSkin.material.name.Contains("Ice"))
                    {
                        if (!aimedRig.mainSkin.material.name.Contains("fected") && !aimedRig.mainSkin.material.name.Contains("it") && !aimedRig.mainSkin.material.name.Contains("Ice"))
                        {
                            GorillaTagger.Instance.offlineVRRig.enabled = false;
                            GorillaTagger.Instance.offlineVRRig.transform.position -= new Vector3(0f, 25f, 0f);
                            new WaitForSeconds(0.2f);
                            for (int i = 0; i < 5; i++)
                            {
                                GorillaTagger.Instance.offlineVRRig.transform.position = aimedRig.transform.position - new Vector3(0f, 2.5f, 0f);
                                GorillaTagger.Instance.offlineVRRig.rightHand.rigTarget.transform.position = aimedRig.transform.position;
                                GorillaTagger.Instance.rightHandTransform.position = aimedRig.transform.position;
                                new WaitForSeconds(0.1f);
                                GorillaTagger.Instance.offlineVRRig.enabled = true;
                            }
                        }
                        else
                        {
                            GorillaTagger.Instance.offlineVRRig.enabled = true;
                        }
                    }
                    else
                    {
                        if (!aimedRig.mainSkin.material.name.Contains("Ice") && !aimedRig.mainSkin.material.name.Contains("fected") && !aimedRig.mainSkin.material.name.Contains("It") && aimedRig.frozenEffect.active)
                        {
                            if (Vector3.Distance(Camera.main.transform.position, aimedRig.transform.position) <= 3.5f && Time.time - last > 0.5f)
                            {
                                last = Time.time;
                                GorillaTagger.Instance.offlineVRRig.enabled = false;
                                GorillaTagger.Instance.offlineVRRig.transform.position -= new Vector3(0f, 25f, 0f);
                                new WaitForSeconds(0.2f);
                                for (int i = 0; i < 5; i++)
                                {
                                    GorillaTagger.Instance.offlineVRRig.transform.position = aimedRig.transform.position - new Vector3(0f, 2.5f, 0f);
                                    GorillaTagger.Instance.offlineVRRig.rightHand.rigTarget.transform.position = aimedRig.transform.position;
                                    GorillaTagger.Instance.rightHandTransform.position = aimedRig.transform.position;
                                    new WaitForSeconds(0.1f);
                                    GorillaTagger.Instance.offlineVRRig.enabled = true;
                                }
                            }
                        }
                    }
                }
                else
                {
                    GorillaTagger.Instance.offlineVRRig.enabled = true;
                }
            }
            if (Box)
            {
                foreach (VRRig vrrig in GorillaParent.instance.vrrigs)
                {
                    if (vrrig != GorillaTagger.Instance.offlineVRRig)
                    {
                        SkinnedMeshRenderer skinnedMeshRenderer = vrrig.mainSkin;
                        if (vrrig.mainSkin.material.name.Contains("fected") || vrrig.mainSkin.material.name.Contains("It") || vrrig.mainSkin.material.name.Contains("Ice"))
                        {
                            skinnedMeshRenderer.material.color = Color.red - new Color(0f, 0f, 0f, 0.5f); ;
                        }
                        else
                        {
                            if (EspColour == 0)
                            {
                                skinnedMeshRenderer.material.color = Color.magenta - new Color(0f, 0f, 0f, 0.5f);
                            }
                            if (EspColour == 1)
                            {
                                skinnedMeshRenderer.material.color = Color.green - new Color(0f, 0f, 0f, 0.5f); ;
                            }
                            if (EspColour == 2)
                            {
                                skinnedMeshRenderer.material.color = Color.grey - new Color(0f, 0f, 0f, 0.5f); ;
                            }
                            if (EspColour == 3)
                            {
                                skinnedMeshRenderer.material.color = Color.blue - new Color(0f, 0f, 0f, 0.5f); ;
                            }
                            if (EspColour == 4)
                            {
                                skinnedMeshRenderer.material.color = Color.black - new Color(0f, 0f, 0f, 0.5f); ;
                            }
                            if (EspColour == 5)
                            {
                                skinnedMeshRenderer.material.color = Color.yellow - new Color(0f, 0f, 0f, 0.5f); ;
                            }
                            if (EspColour == 6)
                            {
                                skinnedMeshRenderer.material.color = Color.red - new Color(0f, 0f, 0f, 0.5f); ;
                            }
                        }
                        skinnedMeshRenderer.material.shader = Shader.Find("GUI/Text Shader");
                        if (Stream)
                        {
                            skinnedMeshRenderer.gameObject.layer = 19;
                        }
                        else
                        {
                            skinnedMeshRenderer.gameObject.layer = 2;
                        }
                    }
                }
            }
            if (Ghost)
            {
                if (Time.time - last > inputDelay && ControllerInputPoller.instance.rightControllerIndexFloat > 0.5f)
                {
                    last = Time.time;
                    if (!thingy)
                    {
                        GorillaTagger.Instance.offlineVRRig.enabled = false;
                        thingy = true;
                    }
                    else
                    {
                        GorillaTagger.Instance.offlineVRRig.enabled = true;
                        thingy = false;
                    }
                }
            }
            if (Invis)
            {
                if (Time.time - last > inputDelay && ControllerInputPoller.instance.rightControllerIndexFloat > 0.5f)
                {
                    last = Time.time;
                    if (!thingy)
                    {
                        GorillaTagger.Instance.offlineVRRig.enabled = false;
                        GorillaTagger.Instance.offlineVRRig.transform.position = Vector3.zero;
                        thingy = true;
                    }
                    else
                    {
                        GorillaTagger.Instance.offlineVRRig.enabled = true;
                        thingy = false;
                    }
                }
            }
            if (Tag4)
            {
                foreach (VRRig vrrig in GorillaParent.instance.vrrigs)
                {
                    if (GorillaTagger.Instance.offlineVRRig.mainSkin.material.name.Contains("fected") || GorillaTagger.Instance.offlineVRRig.mainSkin.material.name.Contains("It") || GorillaTagger.Instance.offlineVRRig.mainSkin.material.name.Contains("Ice"))
                    {
                        if (!vrrig.mainSkin.material.name.Contains("fected") && !vrrig.mainSkin.material.name.Contains("It") && !vrrig.mainSkin.material.name.Contains("Ice") && !vrrig.frozenEffect.active)
                        {
                            GorillaTagger.Instance.offlineVRRig.enabled = false;
                            GorillaTagger.Instance.offlineVRRig.transform.position -= new Vector3(0f, 25f, 0f);
                            new WaitForSeconds(0.2f);
                            GorillaTagger.Instance.offlineVRRig.transform.position = vrrig.transform.position - new Vector3(0f, 2.5f, 0f);
                            GorillaTagger.Instance.offlineVRRig.rightHand.rigTarget.transform.position = GorillaTagger.Instance.offlineVRRig.transform.position + new Vector3(0f, 2.5f, 0f);
                            GorillaTagger.Instance.rightHandTransform.position = GorillaTagger.Instance.offlineVRRig.transform.position + new Vector3(0f, 2.5f, 0f);
                            new WaitForSeconds(0.1f);
                            GorillaTagger.Instance.offlineVRRig.enabled = true;
                        }
                        else
                        {
                            GorillaTagger.Instance.offlineVRRig.enabled = true;
                        }
                    }
                    else
                    {
                        if (!vrrig.mainSkin.material.name.Contains("Ice") && !vrrig.mainSkin.material.name.Contains("fected") && !vrrig.mainSkin.material.name.Contains("It") && vrrig.frozenEffect.active && vrrig != GorillaTagger.Instance.offlineVRRig && !GorillaTagger.Instance.offlineVRRig.frozenEffect.active)
                        {
                            GorillaTagger.Instance.offlineVRRig.enabled = false;
                            GorillaTagger.Instance.offlineVRRig.transform.position -= new Vector3(0f, 25f, 0f);
                            new WaitForSeconds(0.2f);
                            GorillaTagger.Instance.offlineVRRig.transform.position = vrrig.transform.position - new Vector3(0f, 2.5f, 0f);
                            GorillaTagger.Instance.offlineVRRig.rightHand.rigTarget.transform.position = GorillaTagger.Instance.offlineVRRig.transform.position + new Vector3(0f, 2.5f, 0f);
                            GorillaTagger.Instance.rightHandTransform.position = GorillaTagger.Instance.offlineVRRig.transform.position + new Vector3(0f, 2.5f, 0f);
                            new WaitForSeconds(0.1f);
                            GorillaTagger.Instance.offlineVRRig.enabled = true;
                        }
                    }
                }
            }
            if (Trace)
            {
                foreach (VRRig vrrig in GorillaParent.instance.vrrigs)
                {
                    if (vrrig != GorillaTagger.Instance.offlineVRRig)
                    {
                        UnityEngine.Color TColour = UnityEngine.Color.magenta;

                        if (vrrig.mainSkin.material.name.Contains("fected") || vrrig.mainSkin.material.name.Contains("It") || vrrig.mainSkin.material.name.Contains("Ice"))
                        {
                            TColour = UnityEngine.Color.red - new Color(0f, 0f, 0f, 0.7f);
                        }
                        else
                        {
                            switch (EspColour)
                            {
                                case 0:
                                    TColour = UnityEngine.Color.magenta - new Color(0f, 0f, 0f, 0.9f);
                                    break;
                                case 1:
                                    TColour = UnityEngine.Color.green - new Color(0f, 0f, 0f, 0.9f);
                                    break;
                                case 2:
                                    TColour = UnityEngine.Color.grey - new Color(0f, 0f, 0f, 0.9f);
                                    break;
                                case 3:
                                    TColour = UnityEngine.Color.blue - new Color(0f, 0f, 0f, 0.9f);
                                    break;
                                case 4:
                                    TColour = UnityEngine.Color.black - new Color(0f, 0f, 0f, 0.9f);
                                    break;
                                case 5:
                                    TColour = UnityEngine.Color.yellow - new Color(0f, 0f, 0f, 0.9f);
                                    break;
                                case 6:
                                    TColour = UnityEngine.Color.red - new Color(0f, 0f, 0f, 0.9f);
                                    break;
                            }
                        }

                        GameObject line = new GameObject("Line");
                        LineRenderer liner = line.AddComponent<LineRenderer>();
                        liner.startColor = TColour;
                        liner.endColor = TColour;
                        liner.startWidth = Size;
                        liner.endWidth = Size;
                        liner.positionCount = 2;
                        liner.useWorldSpace = true;
                        if (GameSense)
                        {
                            liner.SetPosition(0, Camera.main.transform.position - new Vector3(0f, 0.35f, 0f));
                        }
                        else
                        {
                            liner.SetPosition(0, GorillaTagger.Instance.rightHandTransform.position);
                        }
                        liner.SetPosition(1, vrrig.transform.position);
                        Renderer renderer = liner.GetComponent<Renderer>();
                        Material material = renderer.material;
                        material.shader = Shader.Find("GUI/Text Shader");
                        if (Stream)
                        {
                            line.gameObject.layer = 19;
                        }
                        else
                        {
                            line.gameObject.layer = 2;
                        }
                        UnityEngine.Object.Destroy(line, Time.deltaTime);
                        UnityEngine.Object.Destroy(liner, Time.deltaTime);
                        UnityEngine.Object.Destroy(material, Time.deltaTime);
                        UnityEngine.Object.Destroy(renderer, Time.deltaTime);
                    }
                }
            }
            if (Long)
            {
                Rigidbody Rigidbody = GorillaLocomotion.Player.Instance.GetComponent<Rigidbody>();
                Vector3 Velocity = Rigidbody.velocity;
                if (Velocity.magnitude > 5f && Vector3.Dot(Velocity, GorillaLocomotion.Player.Instance.transform.up) > 5 && Vector3.Dot(Velocity, GorillaLocomotion.Player.Instance.transform.forward) < 5f)
                {
                    GorillaLocomotion.Player.Instance.transform.position += GorillaLocomotion.Player.Instance.transform.up * Time.deltaTime * 15;
                }
            }
            if (Wall)
            {
                Rigidbody Rigidbody = GorillaLocomotion.Player.Instance.GetComponent<Rigidbody>();
                Vector3 Velocity = Rigidbody.velocity;
                if (Velocity.magnitude > 5f && Vector3.Dot(Velocity, GorillaLocomotion.Player.Instance.transform.up) > 5 && Vector3.Dot(Velocity, GorillaLocomotion.Player.Instance.transform.forward) < 5f && GorillaLocomotion.Player.Instance.IsHandTouching(true) || GorillaLocomotion.Player.Instance.IsHandTouching(false))
                {
                    GorillaLocomotion.Player.Instance.transform.position += GorillaLocomotion.Player.Instance.transform.up * Time.deltaTime * 15;
                }
            }
            if (Thin)
            {
                Size = 0.005f;
            }
            else
            {
                Size = 0.05f;
            }
            if (Box2)
            {
                foreach (VRRig vrrig in GorillaParent.instance.vrrigs)
                {
                    if (vrrig != GorillaTagger.Instance.offlineVRRig)
                    {
                        GameObject Visual = GameObject.CreatePrimitive(PrimitiveType.Cube);
                        Visual.transform.position = vrrig.transform.position;
                        Visual.transform.LookAt(Camera.main.transform.position);
                        Visual.transform.localScale = new Vector3(1f, 1f, 0.01f);
                        Renderer renderer = Visual.GetComponent<Renderer>();
                        Material material = renderer.material;
                        material.shader = Shader.Find("GUI/Text Shader");
                        UnityEngine.Object.Destroy(Visual.GetComponent<BoxCollider>());
                        UnityEngine.Object.Destroy(Visual.GetComponent<Rigidbody>());
                        if (vrrig.mainSkin.material.name.Contains("fected") || vrrig.mainSkin.material.name.Contains("It") || vrrig.mainSkin.material.name.Contains("stealth") || vrrig.mainSkin.material.name.Contains("Ice"))
                        {
                            material.color = Color.red - new Color(0f, 0f, 0f, 0.9f);
                        }
                        else if (EspColour == 0)
                        {
                            material.color = Color.magenta - new Color(0f, 0f, 0f, 0.9f);
                        }
                        else if (EspColour == 1)
                        {
                            material.color = Color.green - new Color(0f, 0f, 0f, 0.9f);
                        }
                        else if (EspColour == 2)
                        {
                            material.color = Color.grey - new Color(0f, 0f, 0f, 0.9f);
                        }
                        else if (EspColour == 3)
                        {
                            material.color = Color.blue - new Color(0f, 0f, 0f, 0.9f);
                        }
                        else if (EspColour == 4)
                        {
                            material.color = Color.black - new Color(0f, 0f, 0f, 0.9f);
                        }
                        else if (EspColour == 5)
                        {
                            material.color = Color.yellow - new Color(0f, 0f, 0f, 0.9f);
                        }
                        else if (EspColour == 6)
                        {
                            material.color = Color.red - new Color(0f, 0f, 0f, 0.9f);
                        }
                        if (Stream)
                        {
                            Visual.gameObject.layer = 19;
                        }
                        else
                        {
                            Visual.gameObject.layer = 2;
                        }
                        UnityEngine.Object.Destroy(Visual, 0.01f);
                        UnityEngine.Object.Destroy(material, 0.01f);
                    }
                }
            }
            if (Box3)
            {
                foreach (VRRig vrrig in GorillaParent.instance.vrrigs)
                {
                    if (vrrig != GorillaTagger.Instance.offlineVRRig)
                    {
                        GameObject Visual = GameObject.CreatePrimitive(PrimitiveType.Cylinder);
                        Visual.transform.position = vrrig.transform.position;
                        Visual.transform.localScale = new Vector3(0.05f, 100f, 0.05f);
                        Renderer renderer = Visual.GetComponent<Renderer>();
                        Material material = renderer.material;
                        material.shader = Shader.Find("GUI/Text Shader");
                        UnityEngine.Object.Destroy(Visual.GetComponent<BoxCollider>());
                        UnityEngine.Object.Destroy(Visual.GetComponent<Rigidbody>());
                        if (vrrig.mainSkin.material.name.Contains("fected") || vrrig.mainSkin.material.name.Contains("It") || vrrig.mainSkin.material.name.Contains("stealth") || vrrig.mainSkin.material.name.Contains("Ice"))
                        {
                            material.color = Color.red - new Color(0f, 0f, 0f, 0.9f);
                        }
                        else if (EspColour == 0)
                        {
                            material.color = Color.magenta - new Color(0f, 0f, 0f, 0.9f);
                        }
                        else if (EspColour == 1)
                        {
                            material.color = Color.green - new Color(0f, 0f, 0f, 0.9f);
                        }
                        else if (EspColour == 2)
                        {
                            material.color = Color.grey - new Color(0f, 0f, 0f, 0.9f);
                        }
                        else if (EspColour == 3)
                        {
                            material.color = Color.blue - new Color(0f, 0f, 0f, 0.9f);
                        }
                        else if (EspColour == 4)
                        {
                            material.color = Color.black - new Color(0f, 0f, 0f, 0.9f);
                        }
                        else if (EspColour == 5)
                        {
                            material.color = Color.yellow - new Color(0f, 0f, 0f, 0.9f);
                        }
                        else if (EspColour == 6)
                        {
                            material.color = Color.red - new Color(0f, 0f, 0f, 0.9f);
                        }
                        if (Stream)
                        {
                            Visual.gameObject.layer = 19;
                        }
                        else
                        {
                            Visual.gameObject.layer = 2;
                        }
                        UnityEngine.Object.Destroy(Visual, 0.05f);
                        UnityEngine.Object.Destroy(material, 0.05f);
                    }
                }
            }
            if (Box4)
            {
                foreach (VRRig vrrig in GorillaParent.instance.vrrigs)
                {
                    if (vrrig != GorillaTagger.Instance.offlineVRRig)
                    {
                        GameObject Visual = GameObject.CreatePrimitive(PrimitiveType.Sphere);
                        Visual.transform.position = vrrig.transform.position;
                        Visual.transform.localScale = new Vector3(0.2f, 0.2f, 0.2f);
                        Renderer renderer = Visual.GetComponent<Renderer>();
                        Material material = renderer.material;
                        material.shader = Shader.Find("GUI/Text Shader");
                        UnityEngine.Object.Destroy(Visual.GetComponent<BoxCollider>());
                        UnityEngine.Object.Destroy(Visual.GetComponent<Rigidbody>());
                        if (vrrig.mainSkin.material.name.Contains("fected") || vrrig.mainSkin.material.name.Contains("It") || vrrig.mainSkin.material.name.Contains("stealth") || vrrig.mainSkin.material.name.Contains("Ice"))
                        {
                            material.color = Color.red - new Color(0f, 0f, 0f, 0.95f);
                        }
                        else if (EspColour == 0)
                        {
                            material.color = Color.magenta - new Color(0f, 0f, 0f, 0.95f);
                        }
                        else if (EspColour == 1)
                        {
                            material.color = Color.green - new Color(0f, 0f, 0f, 0.95f);
                        }
                        else if (EspColour == 2)
                        {
                            material.color = Color.grey - new Color(0f, 0f, 0f, 0.95f);
                        }
                        else if (EspColour == 3)
                        {
                            material.color = Color.blue - new Color(0f, 0f, 0f, 0.95f);
                        }
                        else if (EspColour == 4)
                        {
                            material.color = Color.black - new Color(0f, 0f, 0f, 0.95f);
                        }
                        else if (EspColour == 5)
                        {
                            material.color = Color.yellow - new Color(0f, 0f, 0f, 0.95f);
                        }
                        else if (EspColour == 6)
                        {
                            material.color = Color.red - new Color(0f, 0f, 0f, 0.95f);
                        }
                        if (Stream)
                        {
                            Visual.gameObject.layer = 19;
                        }
                        else
                        {
                            Visual.gameObject.layer = 2;
                        }
                        UnityEngine.Object.Destroy(Visual, 0.3f);
                        UnityEngine.Object.Destroy(material, 0.3f);
                        UnityEngine.Object.Destroy(renderer, 0.3f);
                    }
                }
            }
            if (Box5)
            {
                foreach (VRRig vrrig in GorillaParent.instance.vrrigs)
                {
                    if (vrrig != GorillaTagger.Instance.offlineVRRig)
                    {
                            GameObject line = new GameObject("Line");
                            LineRenderer liner = line.AddComponent<LineRenderer>();
                            liner.startWidth = Size;
                            liner.endWidth = Size;
                            liner.positionCount = 5;
                            liner.useWorldSpace = true;
                        Vector3 r = Camera.main.transform.right;
                        Vector3 Up = Camera.main.transform.up;
                        Vector3 center2 = vrrig.transform.position;
                            liner.SetPosition(0, center2 + Up * 0.435f + r * 0.25f);
                            liner.SetPosition(1, center2 + Up * 0.435f - r * 0.25f);
                            liner.SetPosition(2, center2 - Up * 0.435f - r * 0.25f);
                            liner.SetPosition(3, center2 - Up * 0.435f + r * 0.25f);
                            liner.SetPosition(4, center2 + Up * 0.435f + r * 0.25f);
                            Renderer renderer = liner.GetComponent<Renderer>();
                            Material material = renderer.material;
                            material.shader = Shader.Find("GUI/Text Shader");
                            if (vrrig.mainSkin.material.name.Contains("fected") || vrrig.mainSkin.material.name.Contains("It") || vrrig.mainSkin.material.name.Contains("stealth") || vrrig.mainSkin.material.name.Contains("Ice"))
                            {
                                material.color = Color.red - new Color(0f, 0f, 0f, 0.5f);
                            }
                            else if (EspColour == 0)
                            {
                                material.color = Color.magenta - new Color(0f, 0f, 0f, 0.5f);
                            }
                            else if (EspColour == 1)
                            {
                                material.color = Color.green - new Color(0f, 0f, 0f, 0.5f);
                            }
                            else if (EspColour == 2)
                            {
                                material.color = Color.grey - new Color(0f, 0f, 0f, 0.5f);
                            }
                            else if (EspColour == 3)
                            {
                                material.color = Color.blue - new Color(0f, 0f, 0f, 0.5f);
                            }
                            else if (EspColour == 4)
                            {
                                material.color = Color.black - new Color(0f, 0f, 0f, 0.5f);
                            }
                            else if (EspColour == 5)
                            {
                                material.color = Color.yellow - new Color(0f, 0f, 0f, 0.5f);
                            }
                            else if (EspColour == 6)
                            {
                                material.color = Color.red - new Color(0f, 0f, 0f, 0.5f);
                            }
                            if (Stream)
                            {
                                line.gameObject.layer = 19;
                            }
                            else
                            {
                                line.gameObject.layer = 2;
                            }
                            UnityEngine.Object.Destroy(line, Time.deltaTime);
                            UnityEngine.Object.Destroy(material, Time.deltaTime);
                            UnityEngine.Object.Destroy(renderer, Time.deltaTime);
                        }
                    }
                }
            if (Launch2)
            {
                if (ControllerInputPoller.instance.rightGrab && Time.time - last3 > 0.17f)
                {
                    last3 = Time.time;
                    ElfLauncher Skibidi = GameObject.Find("Player Objects/Local VRRig/Local Gorilla Player/RigAnchor/rig/body/shoulder.R/upper_arm.R/forearm.R/hand.R/palm.01.R/TransferrableItemRightHand/ElfLauncherAnchor(Clone)/LMANE.").GetComponent<ElfLauncher>();
                    Skibidi.transform.position = Camera.main.transform.position - new Vector3(0f, 0.2f, 0f);
                    Skibidi.transform.rotation = Camera.main.transform.rotation;
                    typeof(ElfLauncher).GetMethod("Shoot", BindingFlags.NonPublic | BindingFlags.Instance).Invoke(Skibidi, null);
                    if (Rpc)
                    {
                        Sunnys_Rpc.RPCProtection();
                    }
                }
            }
            if (Launch4)
            {
                    GameObject.Find("BuilderNetworking").GetComponent<PhotonView>().RPC("PlayerEnterBuilderRPC", RpcTarget.Others, new object[]
                    {
                       "RIZZGYATT".PadRight(1967)
                    });
                BuilderTable.instance.RequestCreatePiece(1700948013, GorillaTagger.Instance.rightHandTransform.position, GorillaTagger.Instance.rightHandTransform.rotation, -1);
            }
            if (Launch)
            {
                if (ControllerInputPoller.instance.rightGrab && Time.time - last3 > 0.17f)
                {
                    last3 = Time.time;
                    ElfLauncher Skibidi = GameObject.Find("Player Objects/Local VRRig/Local Gorilla Player/RigAnchor/rig/body/shoulder.R/upper_arm.R/forearm.R/hand.R/palm.01.R/TransferrableItemRightHand/ElfLauncherAnchor(Clone)/LMANE.").GetComponent<ElfLauncher>();
                    typeof(ElfLauncher).GetMethod("Shoot", BindingFlags.NonPublic | BindingFlags.Instance).Invoke(Skibidi, null);
                    if (Rpc)
                    {
                        Sunnys_Rpc.RPCProtection();
                    }
                }
            }
            if (Box6)
            {
                foreach (VRRig vrrig in GorillaParent.instance.vrrigs)
                {
                    if (vrrig != GorillaTagger.Instance.offlineVRRig)
                    {
                        GameObject line = new GameObject("Line");
                        LineRenderer liner = line.AddComponent<LineRenderer>();
                        Renderer renderer = liner.GetComponent<Renderer>();
                        Material material = renderer.material;
                        material.shader = Shader.Find("GUI/Text Shader");
                        liner.startColor = Color.grey;
                        liner.endColor = Color.grey;
                        liner.startWidth = 0.05f;
                        liner.endWidth = 0.05f;
                        liner.positionCount = 5;
                        liner.useWorldSpace = true;
                        liner.SetPosition(0, vrrig.rightHandTransform.position);
                        liner.SetPosition(1, vrrig.builderArmShelfRight.transform.position);
                        liner.SetPosition(2, vrrig.headConstraint.transform.position);
                        liner.SetPosition(3, vrrig.builderArmShelfLeft.transform.position);
                        liner.SetPosition(4, vrrig.leftHandTransform.position);
                        if (vrrig.mainSkin.material.name.Contains("fected") || vrrig.mainSkin.material.name.Contains("It") || vrrig.mainSkin.material.name.Contains("stealth") || vrrig.mainSkin.material.name.Contains("Ice"))
                        {
                            material.color = Color.red - new Color(0f, 0f, 0f, 0.25f);
                        }
                        else if (EspColour == 0)
                        {
                            material.color = Color.magenta - new Color(0f, 0f, 0f, 0.25f);
                        }
                        else if (EspColour == 1)
                        {
                            material.color = Color.green - new Color(0f, 0f, 0f, 0.25f);
                        }
                        else if (EspColour == 2)
                        {
                            material.color = Color.grey - new Color(0f, 0f, 0f, 0.25f);
                        }
                        else if (EspColour == 3)
                        {
                            material.color = Color.blue - new Color(0f, 0f, 0f, 0.25f);
                        }
                        else if (EspColour == 4)
                        {
                            material.color = Color.black - new Color(0f, 0f, 0f, 0.25f);
                        }
                        else if (EspColour == 5)
                        {
                            material.color = Color.yellow - new Color(0f, 0f, 0f, 0.25f);
                        }
                        else if (EspColour == 6)
                        {
                            material.color = Color.red - new Color(0f, 0f, 0f, 0.25f);
                        }
                        if (Stream)
                        {
                            line.gameObject.layer = 19;
                        }
                        else
                        {
                            line.gameObject.layer = 2;
                        }
                        UnityEngine.Object.Destroy(line, Time.deltaTime);
                        UnityEngine.Object.Destroy(liner, Time.deltaTime);
                        UnityEngine.Object.Destroy(material, Time.deltaTime);
                        UnityEngine.Object.Destroy(renderer, Time.deltaTime);
                    }
                }
            }
            if (Skid)
            {
                foreach (VRRig vrrig in GorillaParent.instance.vrrigs)
                {
                    vrrig.playerText1.text = "Sunny Dee";
                    vrrig.playerText2.text = "Sunny Dee";
                }
            }
            if (Pred)
            {
                GunLib.UpdateGun(false);
                Vector3 pos = GunLib.GunPos();
                if (Edge2 == null)
                {
                    Edge2.enabled = false;
                    Edge2.transform.position = Vector3.zero;
                }
                if (GunLib.GunShowen && GunLib.GunTrigger)
                {
                        Edge2.enabled = false;
                        Edge2.transform.position = pos + new Vector3(0f, 3f, 0f);
                }
                else
                {
                    Edge2.enabled = false;
                    Edge2.transform.position = Vector3.zero;
                }
            }
            if (Tag)
            {
                if (GorillaTagger.Instance.offlineVRRig.mainSkin.material.name.Contains("fected") || GorillaTagger.Instance.offlineVRRig.mainSkin.material.name.Contains("It") || GorillaTagger.Instance.offlineVRRig.mainSkin.material.name.Contains("Ice"))
                {
                    if (ControllerInputPoller.instance.rightGrab)
                    {
                        GorillaTagger.Instance.rightHandTransform.position = new Vector3(GorillaTagger.Instance.rightHandTransform.position.x, Prev, GorillaTagger.Instance.rightHandTransform.position.z);
                        GorillaTagger.Instance.rightHandTransform.position += GorillaTagger.Instance.rightHandTransform.forward * Time.deltaTime * 100;
                    }
                    else
                    {
                        Prev = GorillaTagger.Instance.rightHandTransform.position.y;
                        Prev2 = GorillaTagger.Instance.rightHandTransform.position.x;
                        Prev3 = GorillaTagger.Instance.rightHandTransform.position.z;
                    }
                }
            }
            if (Stare)
            {
                /*if (GorillaTagger.Instance.offlineVRRig.mainSkin.material.name.Contains("fected") || GorillaTagger.Instance.offlineVRRig.mainSkin.material.name.Contains("it") || GorillaTagger.Instance.offlineVRRig.mainSkin.material.name.Contains("Ice"))
                {
                    foreach (VRRig vrrig in GorillaParent.instance.vrrigs)
                    {
                        if (!vrrig.mainSkin.material.name.Contains("Ice") && !vrrig.mainSkin.material.name.Contains("fected") && !vrrig.mainSkin.material.name.Contains("It"))
                        {
                            GorillaTagger.Instance.transform.LookAt(vrrig.transform);
                        }
                    }
                }*/
            }
            if (Break)
            {
                if (PhotonNetwork.LocalPlayer.IsMasterClient)
                {
                    if (GorillaGameManager.instance.GameModeName().ToLower().Contains("freeze"))
                    {
                        GorillaFreezeTagManager Fman = GameObject.Find("Gorilla Freeze Tag Manager").GetComponent<GorillaFreezeTagManager>();
                        Fman.freezeDuration = 10000000000000000000;
                    }
                }
            }
            else
            {
                if (PhotonNetwork.LocalPlayer.IsMasterClient)
                {
                    if (GorillaGameManager.instance.GameModeName().ToLower().Contains("freeze"))
                    {
                        GorillaFreezeTagManager Fman = GameObject.Find("Gorilla Freeze Tag Manager").GetComponent<GorillaFreezeTagManager>();
                        Fman.freezeDuration = 10;
                    }
                }
            }
            if (Tag2)
            {
                if (GorillaTagger.Instance.offlineVRRig.mainSkin.material.name.Contains("fected") || GorillaTagger.Instance.offlineVRRig.mainSkin.material.name.Contains("It") || GorillaTagger.Instance.offlineVRRig.mainSkin.material.name.Contains("Ice"))
                {
                    foreach (VRRig vrrig in GorillaParent.instance.vrrigs)
                    {
                        if (GorillaTagger.Instance.offlineVRRig.mainSkin.material.name.Contains("fected") || GorillaTagger.Instance.offlineVRRig.mainSkin.material.name.Contains("It") || GorillaTagger.Instance.offlineVRRig.mainSkin.material.name.Contains("Ice"))
                        {
                            if (!vrrig.mainSkin.material.name.Contains("fected") && !vrrig.mainSkin.material.name.Contains("It") && !vrrig.mainSkin.material.name.Contains("Ice"))
                            {
                                if (Vector3.Distance(GorillaTagger.Instance.rightHandTransform.position, vrrig.transform.position) <= 0.7f)
                                {
                                    GorillaTagger.Instance.rightHandTransform.position = vrrig.transform.position;
                                }
                                if (Vector3.Distance(GorillaTagger.Instance.leftHandTransform.position, vrrig.transform.position) <= 0.7f)
                                {
                                    GorillaTagger.Instance.leftHandTransform.position = vrrig.transform.position;
                                }
                            }
                        }
                        else
                        {
                            if (!vrrig.mainSkin.material.name.Contains("Ice") && !vrrig.mainSkin.material.name.Contains("fected") && !vrrig.mainSkin.material.name.Contains("It") && vrrig.frozenEffect.active)
                            {
                                if (Vector3.Distance(GorillaTagger.Instance.rightHandTransform.position, vrrig.transform.position) <= 0.7f)
                                {
                                    GorillaTagger.Instance.rightHandTransform.position = vrrig.transform.position;
                                }
                                if (Vector3.Distance(GorillaTagger.Instance.leftHandTransform.position, vrrig.transform.position) <= 0.7f)
                                {
                                    GorillaTagger.Instance.leftHandTransform.position = vrrig.transform.position;
                                }
                            }
                        }
                    }
                    GameObject Visual = GameObject.CreatePrimitive(PrimitiveType.Sphere);
                    Visual.transform.position = GorillaTagger.Instance.leftHandTransform.position;
                    Visual.transform.localScale = new Vector3(0.7f, 0.7f, 0.7f);
                    Renderer renderer = Visual.GetComponent<Renderer>();
                    Material material = renderer.material;
                    material.shader = Shader.Find("GUI/Text Shader");
                    if (EspColour == 0)
                    {
                        material.color = Color.magenta - new Color(0f, 0f, 0f, 0.9f);
                    }
                    else if (EspColour == 1)
                    {
                        material.color = Color.green - new Color(0f, 0f, 0f, 0.9f);
                    }
                    else if (EspColour == 2)
                    {
                        material.color = Color.grey - new Color(0f, 0f, 0f, 0.9f);
                    }
                    else if (EspColour == 3)
                    {
                        material.color = Color.blue - new Color(0f, 0f, 0f, 0.9f);
                    }
                    else if (EspColour == 4)
                    {
                        material.color = Color.black - new Color(0f, 0f, 0f, 0.9f);
                    }
                    else if (EspColour == 5)
                    {
                        material.color = Color.yellow - new Color(0f, 0f, 0f, 0.9f);
                    }
                    else if (EspColour == 6)
                    {
                        material.color = Color.red - new Color(0f, 0f, 0f, 0.9f);
                    }
                    Visual.layer = 19;
                    GameObject Visual2 = GameObject.CreatePrimitive(PrimitiveType.Sphere);
                    Visual2.transform.position = GorillaTagger.Instance.rightHandTransform.position;
                    Visual2.transform.localScale = new Vector3(0.7f, 0.7f, 0.7f);
                    Renderer renderer2 = Visual2.GetComponent<Renderer>();
                    Material material2 = renderer2.material;
                    material2.shader = Shader.Find("GUI/Text Shader");
                    if (EspColour == 0)
                    {
                        material2.color = Color.magenta - new Color(0f, 0f, 0f, 0.9f);
                    }
                    else if (EspColour == 1)
                    {
                        material2.color = Color.green - new Color(0f, 0f, 0f, 0.9f);
                    }
                    else if (EspColour == 2)
                    {
                        material2.color = Color.grey - new Color(0f, 0f, 0f, 0.9f);
                    }
                    else if (EspColour == 3)
                    {
                        material2.color = Color.blue - new Color(0f, 0f, 0f, 0.9f);
                    }
                    else if (EspColour == 4)
                    {
                        material2.color = Color.black - new Color(0f, 0f, 0f, 0.9f);
                    }
                    else if (EspColour == 5)
                    {
                        material2.color = Color.yellow - new Color(0f, 0f, 0f, 0.9f);
                    }
                    else if (EspColour == 6)
                    {
                        material2.color = Color.red - new Color(0f, 0f, 0f, 0.9f);
                    }
                    Visual2.layer = 19;
                    UnityEngine.Object.Destroy(Visual, Time.deltaTime);
                    UnityEngine.Object.Destroy(Visual2, Time.deltaTime);
                    UnityEngine.Object.Destroy(material, Time.deltaTime);
                    UnityEngine.Object.Destroy(material2, Time.deltaTime);
                }
            }
            if (Tag3)
            {
                foreach (VRRig vrrig in GorillaParent.instance.vrrigs)
                {
                    if (GorillaTagger.Instance.offlineVRRig.mainSkin.material.name.Contains("fected") || GorillaTagger.Instance.offlineVRRig.mainSkin.material.name.Contains("It") || GorillaTagger.Instance.offlineVRRig.mainSkin.material.name.Contains("Ice"))
                    {
                        if (!GorillaTagger.Instance.offlineVRRig.frozenEffect.active)
                        {
                            if (!vrrig.mainSkin.material.name.Contains("fected") && !vrrig.mainSkin.material.name.Contains("It") && !vrrig.mainSkin.material.name.Contains("Ice"))
                            {
                                if (Vector3.Distance(Camera.main.transform.position, vrrig.transform.position) <= 3.5f && Time.time - last > 0.5f)
                                {
                                    last = Time.time;
                                    GorillaTagger.Instance.offlineVRRig.enabled = false;
                                    GorillaTagger.Instance.offlineVRRig.transform.position -= new Vector3(0f, 25f, 0f);
                                    GorillaTagger.Instance.offlineVRRig.transform.position = vrrig.transform.position - new Vector3(0f, 2.5f, 0f);
                                    GorillaTagger.Instance.offlineVRRig.rightHand.rigTarget.transform.position = vrrig.transform.position;
                                    GorillaTagger.Instance.rightHandTransform.position = vrrig.transform.position;
                                    GorillaTagger.Instance.offlineVRRig.enabled = true;
                                }
                            }
                        }
                        else
                        {
                            GorillaTagger.Instance.offlineVRRig.enabled = true;
                        }
                    }
                    else
                    {
                        if (!vrrig.mainSkin.material.name.Contains("Ice") && !vrrig.mainSkin.material.name.Contains("fected") && !vrrig.mainSkin.material.name.Contains("It") && vrrig.frozenEffect.active && Time.time - last > 0.5f)
                        {
                            if (Vector3.Distance(Camera.main.transform.position, vrrig.transform.position) <= 3.5f && Time.time - last > 0.5f && !GorillaTagger.Instance.offlineVRRig.frozenEffect.active)
                            {
                                last = Time.time;
                                GorillaTagger.Instance.offlineVRRig.enabled = false;
                                GorillaTagger.Instance.offlineVRRig.transform.position -= new Vector3(0f, 25f, 0f);
                                GorillaTagger.Instance.offlineVRRig.transform.position = vrrig.transform.position - new Vector3(0f, 2.5f, 0f);
                                GorillaTagger.Instance.offlineVRRig.rightHand.rigTarget.transform.position = vrrig.transform.position;
                                GorillaTagger.Instance.rightHandTransform.position = vrrig.transform.position;
                                GorillaTagger.Instance.offlineVRRig.enabled = true;
                            }
                        }
                    }
                }
            }
            if (ModsAll)
            {
                foreach (VRRig plr in GorillaParent.instance.vrrigs)
                {
                    if (plr != GorillaTagger.Instance.offlineVRRig)
                    {
                        if (plr.rightThumb.calcT > 0.5f)
                        {
                            BuilderTable.instance.RequestCreatePiece(
                              1925587737,
                                plr.rightHandTransform.position,
                               plr.rightHandTransform.rotation,
                               -1
                           );
                        }
                    }
                    if (plr.leftThumb.calcT > 0.5f)
                    {
                        BuilderTable.instance.RequestCreatePiece(
                            1925587737,
                            plr.leftHandTransform.position,
                            plr.leftHandTransform.rotation,
                             -1
                         );
                    }
                }
            }
            if (Spam)
            {
                if (ControllerInputPoller.instance.rightGrab)
                {
                    BuilderTable.instance.RequestCreatePiece(1459246571, GorillaTagger.Instance.rightHandTransform.position, GorillaTagger.Instance.rightHandTransform.rotation, -1);
                }
            }
            if (Spam2)
            {
                if (ControllerInputPoller.instance.rightGrab)
                {
                    BuilderTable.instance.RequestCreatePiece(1925587737, GorillaTagger.Instance.rightHandTransform.position, GorillaTagger.Instance.rightHandTransform.rotation, -1);
                }
            }
            if (Pull && (GorillaLocomotion.Player.Instance.IsHandTouching(true) || GorillaLocomotion.Player.Instance.IsHandTouching(false)) && ControllerInputPoller.instance.rightGrab)
            {
                Rigidbody PlrRigidbody = GorillaLocomotion.Player.Instance.GetComponent<Rigidbody>();
                Vector3 Velocity = PlrRigidbody.velocity;
                RaycastHit hit;
                if (Physics.Raycast(GorillaLocomotion.Player.Instance.transform.position, Vector3.down, out hit))
                {
                    Vector3 Normal = hit.normal;
                    float slopeAngle = Vector3.Angle(Normal, Vector3.up);
                    if (slopeAngle <= 45f)
                    {
                        Vector3 Hori = new Vector3(Velocity.x / Pull3, 0f, Velocity.z / Pull3);
                        Hori = Vector3.ProjectOnPlane(Hori, Normal);
                        float Vert = Velocity.y / Pull3;
                        GorillaLocomotion.Player.Instance.transform.position += Hori + new Vector3(0f, Vert, 0f);
                    }
                }
            }
            if (!Box)
            {
                foreach (VRRig vrrig in GorillaParent.instance.vrrigs)
                {
                    vrrig.mainSkin.material.shader = Shader.Find("GorillaTag/UberShader");
                }
            }
            if (Long2)
            {
                if (Vector3.Distance(Camera.main.transform.position, GorillaTagger.Instance.rightHandTransform.position) < 0.4f && Vector3.Distance(Camera.main.transform.position, GorillaTagger.Instance.leftHandTransform.position) < 0.4f)
                {
                    GorillaTagger.Instance.transform.localScale = new Vector3(1f, 1f, 1f);
                }
                else
                {
                    GorillaTagger.Instance.transform.localScale = new Vector3(Length2, Length2, Length2);
                    GorillaTagger.Instance.rightHandTransform.position -= new Vector3(0f, 0.01f, 0f);
                    GorillaTagger.Instance.rightHandTransform.position -= new Vector3(0f, 0f, 0.01f);
                    GorillaTagger.Instance.leftHandTransform.position += new Vector3(0f, 0f, 0.01f);
                    GorillaTagger.Instance.leftHandTransform.position -= new Vector3(0f, 0.01f, 0f);
                }
            }
            else
            {
                GorillaTagger.Instance.transform.localScale = new Vector3(1f, 1f, 1f);
            }
            if (Freeze)
            {
                GorillaLocomotion.Player.Instance.disableMovement = false;
                GorillaTagger.Instance.offlineVRRig.IsFrozen = false;
                GorillaLocomotion.Player.Instance.freezeTagHandSlidePercent = 100;
                GorillaLocomotion.Player.Instance.frozenBodyBuoyancyFactor = 100;
                GorillaLocomotion.Player.Instance.frictionConstant = 100;
                GorillaTagger.Instance.offlineVRRig.ForceResetFrozenEffect();
                GorillaTagger.Instance.offlineVRRig.frozenEffectMaxY = 100;
                GorillaTagger.Instance.offlineVRRig.frozenEffectMaxHorizontalScale = 100;
                GorillaTagger.Instance.offlineVRRig.iceCubeLeft.active = false;
                GorillaTagger.Instance.offlineVRRig.iceCubeRight.active = false;
            }
            //FPS SHIT
            Fps = 1f / Time.deltaTime;
            Fps = (float)Math.Round(Fps);
            if (Time.time - last > inputDelay && !Hide)
            {
                //SELECTING STUFF
                if (ControllerInputPoller.instance.rightControllerIndexFloat >= 0.5f || Keyboard.current.enterKey.isPressed)
                {
                    last = Time.time;
                    GorillaTagger.Instance.offlineVRRig.PlayHandTapLocal(67, true, 0.4f);
                    if (Mod == 0 && Cat == 0)
                    {
                        Cat = 1;
                        Mod = 0;
                    }
                    if (Mod == 1 && Cat == 0)
                    {
                        Cat = 2;
                        Mod = 0;
                    }
                    if (Mod == 2 && Cat == 0)
                    {
                        Cat = 3;
                        Mod = 0;
                    }
                    if (Mod == 3 && Cat == 0)
                    {
                        Cat = 4;
                        Mod = 0;
                    }
                    if (Mod == 4 && Cat == 0)
                    {
                        Cat = 5;
                        Mod = 0;
                    }
                    if (Mod == 5 && Cat == 0)
                    {
                        Cat = 6;
                        Mod = 0;
                    }
                    if (Mod == 6 && Cat == 0)
                    {
                        Cat = 7;
                        Mod = 0;
                    }
                }
                if (ControllerInputPoller.instance.rightGrab || Keyboard.current.eKey.isPressed)
                {
                    last = Time.time;
                    GorillaTagger.Instance.offlineVRRig.PlayHandTapLocal(67, true, 0.4f);
                    if (Mod == 0 && Cat == 1)
                    {
                        GorillaLocomotion.Player.Instance.maxJumpSpeed = 7f;
                        GorillaLocomotion.Player.Instance.jumpMultiplier = 1.2f;
                        ToolTip.ToolTipSend("", true, "Speed Boost", true, false);
                    }
                    if (Mod == 1 && Cat == 1)
                    {
                        Fly = true;
                        ToolTip.ToolTipSend("", true, "Fly", true, false);
                    }
                    if (Mod == 0 && Cat == 6)
                    {
                            EspColour++;
                            ToolTip.ToolTipSend("", true, "Change Menu Colour", true, false);
                    }
                    if (Mod == 1 && Cat == 6)
                    {
                        GameSense = true;
                        ToolTip.ToolTipSend("", true, "Tracers From Body", true, false);
                    }
                    if (Mod == 2 && Cat == 6)
                    {
                            Length++;
                            ToolTip.ToolTipSend("", true, "Increase Arm Length", true, false);
                    }
                    if (Mod == 3 && Cat == 6)
                    {
                            Pull2++;
                            ToolTip.ToolTipSend("", true, "Increase Pull Mod", true, false);
                    }
                    if (Mod == 4 && Cat == 6)
                    {
                       Effect = true;
                    }
                    if (Mod == 5 && Cat == 6)
                    {
                        Stream = true;
                        ToolTip.ToolTipSend("", true, "Streamable Esp", true, false);
                    }
                    if (Mod == 0 && Cat == 2)
                    {
                        Box = true;
                        ToolTip.ToolTipSend("", true, "Chams", true, false);
                    }
                    if (Mod == 2 && Cat == 1)
                    {
                        Long = true;
                        ToolTip.ToolTipSend("", true, "High Jump", true, false);
                    }
                    if (Mod == 0 && Cat == 3)
                    {
                        AntiCrash = true;
                        ToolTip.ToolTipSend("", true, "Anti Crash", true, false);
                    }
                    if (Mod == 1 && Cat == 3)
                    {
                        Rpc = true;
                        ToolTip.ToolTipSend("", true, "Rpc Protection", true, false);
                    }
                    if (Mod == 2 && Cat == 3)
                    {
                        foreach (Photon.Realtime.Player player in PhotonNetwork.PlayerList)
                        {

                            player.SetCustomProperties(new Hashtable
                            {
                              { "VCC", null },
                              { "genesis", null },
                              { "VENTERN", null },
                              { "GratePlayerSize", null },
                              { "Symex", null },
                              { "GrateEnabledModules", null },
                              { "GrateVersion", null },
                              { "Monkescale", null },
                              { "Scale", null },
                              { "GS", null },
                              { "BananaOS", null }
                              });
                        }
                        ToolTip.ToolTipSend("", true, "Break Mod Networking", true, false);
                    }
                    if (Mod == 0 && Cat == 7)
                    {
                        ModIOMapsTerminal.ResetTerminalControl();
                        ToolTip.ToolTipSend("", true, "Reset Map Term Control", true, false);
                    }
                    if (Mod == 1 && Cat == 7)
                    {
                        if (FriendshipGroupDetection.Instance.IsInParty)
                        {
                            GorillaComputer.instance.currentGameMode.Value = "MODDED_AMBUSH";
                            new WaitForSeconds(0.5f);
                            PhotonNetworkController.Instance.AttemptToJoinSpecificRoom("FUCKEDBYFYSFUCKEDBYFYSFUCKEDBYFYSFUCKEDBYFYSFUCKEDBYFYSFUCKEDBYFYSFUCKEDBYFYSFUCKEDBYFYSFUCKEDBYFYSFUCKEDBYFYSFUCKEDBYFYSFUCKEDBYFYSFUCKEDBYFYSFUCKEDBYFYSFUCKEDBYFYSFUCKEDBYFYSFUCKEDBYFYSFUCKEDBYFYSFUCKEDBYFYSFUCKEDBYFYSFUCKEDBYFYSFUCKEDBYFYSFUCKEDBYFYSFUCKEDBYFYSFUCKEDBYFYSFUCKEDBYFYSFUCKEDBYFYSFUCKEDBYFYSFUCKEDBYFYSFUCKEDBYFYSFUCKEDBYFYSFUCKEDBYFYSFUCKEDBYFYSFUCKEDBYFYSFUCKEDBYFYSFUCKEDBYFYSFUCKEDBYFYSFUCKEDBYFYSFUCKEDBYFYSFUCKEDBYFYSFUCKEDBYFYSFUCKEDBYFYSFUCKEDBYFYSFUCKEDBYFYSFUCKEDBYFYSFUCKEDBYFYSFUCKEDBYFYSFUCKEDBYFYSFUCKEDBYFYSFUCKEDBYFYSFUCKEDBYFYSFUCKEDBYFYSFUCKEDBYFYSFUCKEDBYFYSFUCKEDBYFYSFUCKEDBYFYSFUCKEDBYFYSFUCKEDBYFYSFUCKEDBYFYSFUCKEDBYFYSFUCKEDBYFYSFUCKEDBYFYSFUCKEDBYFYSFUCKEDBYFYSFUCKEDBYFYSFUCKEDBYFYSFUCKEDBYFYS", JoinType.ForceJoinWithParty);
                        }
                        ToolTip.ToolTipSend("", true, "Break Players Games", true, false);
                    }
                    if (Mod == 4 && Cat == 7)
                    {
                        Launch4 = true;
                        ToolTip.ToolTipSend("", true, "Kick Gun", true, false);
                    }
                    if (Mod == 2 && Cat == 7)
                    {
                        GameObject.Find("WorldShareableCosmetic").GetComponent<RequestableOwnershipGuard>().photonView.RPC("OwnershipRequested", RpcTarget.Others, new object[] { "GYATTRIZZ".PadRight(1967) });
                        if (Rpc)
                        {
                            Sunnys_Rpc.RPCProtection();
                        }
                        ToolTip.ToolTipSend("", true, "Kick All", true, false);
                    }
                    if (Mod == 5 && Cat == 7)
                    {
                        if (PhotonNetwork.IsMasterClient)
                        {
                            foreach (GorillaGuardianZoneManager GameMan in GorillaGuardianZoneManager.zoneManagers)
                            {
                                GameMan.SetGuardian(PhotonNetwork.LocalPlayer);
                            }
                        }
                        ToolTip.ToolTipSend("", true, "Set Guardain", true, false);
                    }
                    if (Mod == 3 && Cat == 7)
                    {
                        if (FriendshipGroupDetection.Instance.IsInParty)
                        {
                            GorillaComputer.instance.currentGameMode.Value = "FUCKEDBYFYS";
                            new WaitForSeconds(0.5f);
                            PhotonNetworkController.Instance.AttemptToJoinSpecificRoom("FUCKEDBYFYSFUCKEDBYFYSFUCKEDBYFYSFUCKEDBYFYSFUCKEDBYFYSFUCKEDBYFYSFUCKEDBYFYSFUCKEDBYFYSFUCKEDBYFYSFUUCKEDBYFYSFUCKEDBYFYSFUCKEDBYFYSFUCKEDBYFYSFUCKEDBYFYSFUCKEDBYFYSFUCKEDBYFYSFUCKEDBYFYSFUCKEDBYFYSFUCKEDBYFYSFUCKEDBYFYSFUCKEDBYFYSFUCKEDBYFYSFUCKEDBYFYSFUCKEDBYFYSFUCKEDBYFYSFUCKEDBYFYSFUCKEDBYFYSFUCKEDBYFYSFUCKEDBYFYSFUCKEDBYFYSFUCKEDBYFYSFUCKEDBYFYSFUCKEDBYFYSFUCKEDBYFYSFUCKEDBYFYSFUCKEDBYFYSFUCKEDBYFYSFUCKEDBYFYSFUCKEDBYFYSFUCKEDBYFYSFUCKEDBYFYSFUCKEDBYFYSFUCKEDBYFYSFUCKEDBYFYSFUCKEDBYFYSFUCKEDBYFYSFUCKEDBYFYSFUCKEDBYFYSFUCKEDBYFYSFUCKEDBYFYSFUCKEDBYFYSFUCKEDBYFYSFUCKEDBYFYSFUCKEDBYFYSFUCKEDBYFYSFUCKEDBYFYSFUCKEDBYFYSFUCKEDBYFYSFUCKEDBYFYSFUCKEDBYFYSFUCKEDBYFYSFUCKEDBYFYSFUCKEDBYFYSFUCKEDBYFYSFUCKEDBYFYSFUCKEDBYFYSFUCKEDBYFYS", JoinType.ForceJoinWithParty);
                        }
                        ToolTip.ToolTipSend("", true, "Send Players To Error Code", true, false);
                    }
                    if (Mod == 3 && Cat == 1)
                    {
                        Pull = true;
                        ToolTip.ToolTipSend("", true, "Pull Mod", true, false);
                    }
                    if (Mod == 0 && Cat == 5)
                    {
                        Skid = true;
                        ToolTip.ToolTipSend("", true, "Skid All HeHeHe", true, false);
                    }
                    if (Mod == 1 && Cat == 5)
                    {
                        Ghost = true;
                        ToolTip.ToolTipSend("", true, "Ghost Monke", true, false);
                    }
                    if (Mod == 2 && Cat == 5)
                    {
                        Invis = true;
                        ToolTip.ToolTipSend("", true, "Invis Monke", true, false);
                    }
                    if (Mod == 0 && Cat == 4)
                    {
                        Tag = true;
                        ToolTip.ToolTipSend("", true, "Flick Tag", true, false);
                    }
                    if (Mod == 1 && Cat == 4)
                    {
                        Tag2 = true;
                        ToolTip.ToolTipSend("", true, "Tag Aimbot", true, false);
                    }
                    if (Mod == 2 && Cat == 4)
                    {
                        Tag3 = true;
                        ToolTip.ToolTipSend("", true, "Tag Aura", true, false);
                    }
                    if (Mod == 3 && Cat == 4)
                    {
                        Tag4 = true;
                        ToolTip.ToolTipSend("", true, "Tag All", true, false);
                    }
                    if (Mod == 4 && Cat == 4)
                    {
                        Tag5 = true;
                        ToolTip.ToolTipSend("", true, "Tag Self", true, false);
                    }
                    if (Mod == 5 && Cat == 4)
                    {
                        Tag6 = true;
                        ToolTip.ToolTipSend("", true, "Tag Gun", true, false);
                    }
                    if (Mod == 4 && Cat == 1)
                    {
                        Long2 = true;
                        ToolTip.ToolTipSend("", true, "Long Arms", true, false);
                    }
                    if (Mod == 5 && Cat == 1)
                    {
                        Pred = true;
                        ToolTip.ToolTipSend("", true, "NW RN", true, false);
                    }
                    if (Mod == 6 && Cat == 1)
                    {
                        Fly2 = true;
                        ToolTip.ToolTipSend("", true, "Joystick Fly", true, false);
                    }
                    if (Mod == 1 && Cat == 2)
                    {
                        Trace = true;
                        ToolTip.ToolTipSend("", true, "Tracers", true, false);
                    }
                    if (Mod == 6 && Cat == 6)
                    {
                        Thin = true;
                        ToolTip.ToolTipSend("", true, "Thin Tracers", true, false);
                    }
                    if (Mod == 2 && Cat == 2)
                    {
                        Box2 = true;
                        ToolTip.ToolTipSend("", true, "Box Esp", true, false);
                    }
                    if (Mod == 3 && Cat == 2)
                    {
                        Box3 = true;
                        ToolTip.ToolTipSend("", true, "Beacons", true, false);
                    }
                    if (Mod == 4 && Cat == 2)
                    {
                        Box4 = true;
                        ToolTip.ToolTipSend("", true, "Trails", true, false);
                    }
                    if (Mod == 5 && Cat == 2)
                    {
                        Box5 = true;
                        ToolTip.ToolTipSend("", true, "Hollow Box Esp", true, false);
                    }
                    if (Mod == 6 && Cat == 2)
                    {
                        Box6 = true;
                        ToolTip.ToolTipSend("", true, "Arm Esp", true, false);
                    }
                    if (Mod == 6 && Cat == 7)
                    {
                        Break = true;
                        ToolTip.ToolTipSend("", true, "Break Freeze Tag", true, false);
                    }
                    if (Mod == 3 && Cat == 5)
                    {
                        Force = true;
                        ToolTip.ToolTipSend("", true, "Rig Gun", true, false);
                    }
                    if (Mod == 4 && Cat == 5)
                    {
                        Hold = true;
                        ToolTip.ToolTipSend("", true, "Hold Rig", true, false);
                    }
                    if (Mod == 5 && Cat == 5)
                    {
                        Launch = true;
                        ToolTip.ToolTipSend("", true, "Elf Launcher", true, false);
                    }
                    if (Mod == 6 && Cat == 5)
                    {
                        Launch2 = true;
                        ToolTip.ToolTipSend("", true, "Puke Elves", true, false);
                    }
                }
                //DISABLING
                if (ControllerInputPoller.instance.leftGrab && ControllerInputPoller.instance.leftControllerPrimaryButton || Keyboard.current.escapeKey.isPressed)
                {
                    last = Time.time;
                    GorillaTagger.Instance.offlineVRRig.PlayHandTapLocal(81, true, 0.4f);
                    if (Mod == 0 && Cat == 1)
                    {
                        GorillaLocomotion.Player.Instance.maxJumpSpeed = 2f;
                        GorillaLocomotion.Player.Instance.jumpMultiplier = 2f;
                        ToolTip.ToolTipSend("", true, "Speed Boost", false, false);
                    }
                    if (Mod == 4 && Cat == 7)
                    {
                        Launch4 = false;
                        ToolTip.ToolTipSend("", true, "Kick Gun", false, false);
                    }
                    if (Mod == 6 && Cat == 5)
                    {
                        Launch2 = false;
                        ToolTip.ToolTipSend("", true, "Puke Elves", false, false);
                        GorillaTagger.Instance.offlineVRRig.enabled = true;
                    }
                    if (Mod == 2 && Cat == 7)
                    {
                        ToolTip.ToolTipSend("", true, "Kick All", false, false);
                    }
                    if (Mod == 1 && Cat == 6)
                    {
                        GameSense = false;
                        ToolTip.ToolTipSend("", true, "Tracers From Body", false, false);
                    }
                    if (Mod == 4 && Cat == 4)
                    {
                        Tag5 = false;
                        ToolTip.ToolTipSend("", true, "Tag Self", false, false);
                    }
                    if (Mod == 5 && Cat == 4)
                    {
                        Tag6 = false;
                        ToolTip.ToolTipSend("", true, "Tag Gun", false, false);
                    }
                    if (Mod == 5 && Cat == 2)
                    {
                        Box5 = false;
                        ToolTip.ToolTipSend("", true, "Hollow Box Esp", false, false);
                    }
                    if (Mod == 6 && Cat == 2)
                    {
                        Box6 = false;
                        ToolTip.ToolTipSend("", true, "Arm Esp", false, false);
                    }
                    if (Mod == 4 && Cat == 5)
                    {
                        Hold = false;
                        ToolTip.ToolTipSend("", true, "Hold Rig", false, false);
                        GorillaTagger.Instance.offlineVRRig.enabled = true;
                    }
                    if (Mod == 5 && Cat == 5)
                    {
                        Launch = false;
                        ToolTip.ToolTipSend("", true, "Elf Launcher", false, false);
                    }
                    if (Mod == 2 && Cat == 1)
                    {
                        Long = false;
                        ToolTip.ToolTipSend("", true, "High jump", false, false);

                    }
                    if (Mod == 1 && Cat == 1)
                    {
                        Fly = false;
                        ToolTip.ToolTipSend("", true, "Fly", false, false);
                    }
                    if (Mod == 6 && Cat == 1)
                    {
                        Fly2 = false;
                        ToolTip.ToolTipSend("", true, "Joystick Fly", false, false);
                    }
                    if (Mod == 0 && Cat == 2)
                    {
                        Box = false;
                        ToolTip.ToolTipSend("", true, "Chams", false, false);
                    }
                    if (Mod == 0 && Cat == 3)
                    {
                        AntiCrash = false;
                        ToolTip.ToolTipSend("", true, "Anti Crash", false, false);
                    }
                    if (Mod == 1 && Cat == 3)
                    {
                        Rpc = false;
                        ToolTip.ToolTipSend("", true, "Rpc Protection", false, false);
                    }
                    if (Mod == 4 && Cat == 1)
                    {
                        Long2 = false;
                        ToolTip.ToolTipSend("", true, "Long Arms", false, false);
                    }
                    if (Mod == 5 && Cat == 1)
                    {
                        Pred = false;
                        ToolTip.ToolTipSend("", true, "NW Rn", false, false);
                    }
                    if (Mod == 2 && Cat == 4)
                    {
                        Tag3 = false;
                        ToolTip.ToolTipSend("", true, "Tag Aura", false, false);
                    }
                    if (Mod == 3 && Cat == 1)
                    {
                        Pull = false;
                        ToolTip.ToolTipSend("", true, "Pull Mod", true, false);
                    }
                    if (Mod == 1 && Cat == 2)
                    {
                        Trace = false;
                        ToolTip.ToolTipSend("", true, "Tracers", false, false);
                    }
                    if (Mod == 0 && Cat == 5)
                    {
                        Skid = false;
                        ToolTip.ToolTipSend("", true, "Skid All HeHeHe", false, false);
                    }
                    if (Mod == 1 && Cat == 6)
                    {
                        GameSense = false;
                        ToolTip.ToolTipSend("", true, "Tracers From Body", false, false);
                    }
                    if (Mod == 5 && Cat == 6)
                    {
                        Stream = false;
                        ToolTip.ToolTipSend("", true, "Streamable Esp", false, false);
                    }
                    if (Mod == 6 && Cat == 7)
                    {
                        Break = false;
                        ToolTip.ToolTipSend("", true, "Break Freeze Tag", false, false);
                    }
                    if (Mod == 1 && Cat == 4)
                    {
                        Tag2 = false;
                        ToolTip.ToolTipSend("", true, "Aimbot Tag", false, false);
                    }
                    if (Mod == 0 && Cat == 4)
                    {
                        Tag = false;
                        ToolTip.ToolTipSend("", true, "Flick Tag", false, false);
                    }
                    if (Mod == 6 && Cat == 6)
                    {
                        Thin = false;
                        ToolTip.ToolTipSend("", true, "Thin Tracers", false, false);
                    }
                    if (Mod == 2 && Cat == 2)
                    {
                        Box2 = false;
                        ToolTip.ToolTipSend("", true, "Box Esp", false, false);
                    }
                    if (Mod == 3 && Cat == 2)
                    {
                        Box3 = false;
                        ToolTip.ToolTipSend("", true, "Beacons", false, false);
                    }
                    if (Mod == 4 && Cat == 2)
                    {
                        Box4 = false;
                        ToolTip.ToolTipSend("", true, "Trails", false, false);
                    }
                    if (Mod == 1 && Cat == 5)
                    {
                        Ghost = false;
                        ToolTip.ToolTipSend("", true, "Ghost Monke", false, false);
                        GorillaTagger.Instance.offlineVRRig.enabled = true;
                    }
                    if (Mod == 2 && Cat == 5)
                    {
                        Invis = false;
                        ToolTip.ToolTipSend("", true, "Invis Monke", false, false);
                        GorillaTagger.Instance.offlineVRRig.enabled = true;
                    }
                    if (Mod == 3 && Cat == 5)
                    {
                        Force = false;
                        ToolTip.ToolTipSend("", true, "Rig Gun", false, false);
                        GorillaTagger.Instance.offlineVRRig.enabled = true;
                    }
                    if (Mod == 3 && Cat == 4)
                    {
                        Tag4 = false;
                        ToolTip.ToolTipSend("", true, "Tag All", false, false);
                    }
                }
                // BACK
                if (ControllerInputPoller.instance.rightControllerPrimaryButton && Cat != 0 || Keyboard.current.backspaceKey.isPressed)
                {
                    last = Time.time;
                    GorillaTagger.Instance.offlineVRRig.PlayHandTapLocal(81, true, 0.4f);
                    Cat = 0;
                    Mod = 0;
                }
                //SCROLL UP
                if (ControllerInputPoller.instance.rightControllerPrimary2DAxis.y >= 0.5f || Keyboard.current.upArrowKey.isPressed)
                {
                    Mod--;
                    last = Time.time;
                    GorillaTagger.Instance.offlineVRRig.PlayHandTapLocal(66, true, 0.4f);
                }
                //SCROLL DOWN
                else if (ControllerInputPoller.instance.rightControllerPrimary2DAxis.y <= -0.5f || Keyboard.current.downArrowKey.isPressed)
                {
                    Mod++;
                    last = Time.time;
                    GorillaTagger.Instance.offlineVRRig.PlayHandTapLocal(66, true, 0.4f);
                }
            }
            if (!Hide)
            {
                switch (Mod)
                {
                    case 0:
                        if (Cat == 0)
                        {
                            cocText.text = $"\n\n>Movement\nVisual\nSaftey\nAdvantage\nFun\nSettings\nOp";
                        }
                        if (Cat == 1)
                        {
                            cocText.text = $"\n\n>Speed Boost\nFly [{Fly}]\nHigh Jump [{Long}]\nPull Mod [{Pull}]\nLong Arms\nPreds [{Pred}]\nJoystick Fly [{Fly2}]";
                        }
                        if (Cat == 2)
                        {
                            cocText.text = $"\n\n>Chams [{Box}]\nTracers [{Trace}]\nBox Esp [{Box2}]\nBeacons [{Box3}]\nTrails [{Box4}]\nHollow Box Esp [{Box5}]\nArm Esp [{Box6}]";
                        }
                        if (Cat == 3)
                        {
                            cocText.text = $"\n\n>Anti Crash [{AntiCrash}]\nRpc Protection [{Rpc}]\nPlaceHolder3\nPlaceHolder3\nPlaceHolder3\nPlaceHolder3\nPlaceHolder3";
                        }
                        if (Cat == 4)
                        {
                            cocText.text = $"\n\n>Flick Tag [{Tag}]\nAimbot Tag [{Tag2}]\nTag Aura [{Tag3}]\nTag All [{Tag4}]\nTag Self [{Tag5}]\nTag Gun [{Tag6}]\nPlaceHolder4";
                        }
                        if (Cat == 5)
                        {
                            cocText.text = $"\n\n>Skid All [{Skid}]\nGhost Monke [{Ghost}]\nInvis Monke [{Invis}]\nRig Gun [{Force}]\nHold Rig [{Hold}]\nElf Launcher [{Launch}]\nPuke Elves [{Launch2}]";
                        }
                        if (Cat == 6)
                        {
                            cocText.text = $"\n\n>Menu Colour [{Colour}]\nTracers From Body [{GameSense}]\nLong Arm Length [{Arm}]\nPull Mod Strength [{Pull4}]\nFly Effects [{Effect}]\nStreamable Esp [{Stream}]\nThin Tracers [{Thin}]";
                        }
                        if (Cat == 7)
                        {
                            cocText.text = $"\n\n>Gain Map Term M\nBreak Game In Party\nKick All [{Launch3}]\nError Gamemode Party\nKick Gun\nSet Guardain M\nBreak Freeze Tag M [{Break}]";
                        }
                        break;
                    case 1:
                        if (Cat == 0)
                        {
                            cocText.text = $"\n\nMovement\n>Visual\nSaftey\nAdvantage\nFun\nSettings\nOp";
                        }
                        if (Cat == 1)
                        {
                            cocText.text = $"\n\nSpeed Boost\n>Fly [{Fly}]\nHigh Jump [{Long}]\nPull Mod [{Pull}]\nLong Arms\nPreds [{Pred}]\nJoystick Fly [{Fly2}]";
                        }
                        if (Cat == 2)
                        {
                            cocText.text = $"\n\nChams [{Box}]\n>Tracers [{Trace}]\nBox Esp [{Box2}]\nBeacons [{Box3}]\nTrails [{Box4}]\nHollow Box Esp [{Box5}]\nArm Esp [{Box6}]";
                        }
                        if (Cat == 3)
                        {
                            cocText.text = $"\n\nAnti Crash [{AntiCrash}]\n>Rpc Protection [{Rpc}]\nPlaceHolder3\nPlaceHolder3\nPlaceHolder3\nPlaceHolder3\nPlaceHolder3";
                        }
                        if (Cat == 4)
                        {
                            cocText.text = $"\n\nFlick Tag [{Tag}]\n>Aimbot Tag [{Tag2}]\nTag Aura [{Tag3}]\nTag All [{Tag4}]\nTag Self [{Tag5}]\nTag Gun [{Tag6}]\nPlaceHolder4";
                        }
                        if (Cat == 5)
                        {
                            cocText.text = $"\n\nSkid All [{Skid}]\n>Ghost Monke [{Ghost}]\nInvis Monke [{Invis}]\nRig Gun [{Force}]\nHold Rig [{Hold}]\nElf Launcher [{Launch}]\nPuke Elves [{Launch2}]";
                        }
                        if (Cat == 6)
                        {
                            cocText.text = $"\n\nMenu Colour [{Colour}]\n>Tracers From Body [{GameSense}]\nLong Arm Length [{Arm}]\nPull Mod Strength [{Pull4}]\nFly Effects [{Effect}]\nStreamable Esp [{Stream}]\nThin Tracers [{Thin}]";
                        }
                        if (Cat == 7)
                        {
                            cocText.text = $"\n\nGain Map Term M\n>Break Game In Party\nKick All [{Launch3}]\nError Gamemode Party\nKick Gun\nSet Guardain M\nBreak Freeze Tag M [{Break}]";
                        }
                        break;
                    case 2:
                        if (Cat == 0)
                        {
                            cocText.text = $"\n\nMovement\nVisual\n>Saftey\nAdvantage\nFun\nSettings\nOp";
                        }
                        if (Cat == 1)
                        {
                            cocText.text = $"\n\nSpeed Boost\nFly [{Fly}]\n>High Jump [{Long}]\nPull Mod [{Pull}]\nLong Arms\nPreds [{Pred}]\nJoystick Fly [{Fly2}]";
                        }
                        if (Cat == 2)
                        {
                            cocText.text = $"\n\nChams [{Box}]\nTracers [{Trace}]\n>Box Esp [{Box2}]\nBeacons [{Box3}]\nTrails [{Box4}]\nHollow Box Esp [{Box5}]\nArm Esp [{Box6}]";
                        }
                        if (Cat == 3)
                        {
                            cocText.text = $"\n\nAnti Crash [{AntiCrash}]\nRpc Protection [{Rpc}]\n>PlaceHolder3\nPlaceHolder3\nPlaceHolder3\nPlaceHolder3\nPlaceHolder3";
                        }
                        if (Cat == 4)
                        {
                            cocText.text = $"\n\nFlick Tag [{Tag}]\nAimbot Tag [{Tag2}]\n>Tag Aura [{Tag3}]\nTag All [{Tag4}]\nTag Self [{Tag5}]\nTag Gun [{Tag6}]\nPlaceHolder4";
                        }
                        if (Cat == 5)
                        {
                            cocText.text = $"\n\nSkid All [{Skid}]\nGhost Monke [{Ghost}]\n>Invis Monke [{Invis}]\nRig Gun [{Force}]\nHold Rig [{Hold}]\nElf Launcher [{Launch}]\nPuke Elves [{Launch2}]";
                        }
                        if (Cat == 6)
                        {
                            cocText.text = $"\n\nMenu Colour [{Colour}]\nTracers From Body [{GameSense}]\n>Long Arm Length [{Arm}]\nPull Mod Strength [{Pull4}]\nFly Effects [{Effect}]\nStreamable Esp [{Stream}]\nThin Tracers [{Thin}]";
                        }
                        if (Cat == 7)
                        {
                            cocText.text = $"\n\nGain Map Term M\nBreak Game In Party\n>Kick All [{Launch3}]\nError Gamemode Party\nKick Gun\nSet Guardain M\nBreak Freeze Tag M [{Break}]";
                        }
                        break;
                    case 3:
                        if (Cat == 0)
                        {
                            cocText.text = $"\n\nMovement\nVisual\nSaftey\n>Advantage\nFun\nSettings\nOp";
                        }
                        if (Cat == 1)
                        {
                            cocText.text = $"\n\nSpeed Boost\nFly [{Fly}]\nHigh Jump [{Long}]\n>Pull Mod [{Pull}]\nLong Arms\nPreds [{Pred}]\nJoystick Fly [{Fly2}]";
                        }
                        if (Cat == 2)
                        {
                            cocText.text = $"\n\nChams [{Box}]\nTracers [{Trace}]\nBox Esp [{Box2}]\n>Beacons [{Box3}]\nTrails [{Box4}]\nHollow Box Esp [{Box5}]\nArm Esp [{Box6}]";
                        }
                        if (Cat == 3)
                        {
                            cocText.text = $"\n\nAnti Crash [{AntiCrash}]\nRpc Protection [{Rpc}]\nPlaceHolder3\n>PlaceHolder3\nPlaceHolder3\nPlaceHolder3\nPlaceHolder3";
                        }
                        if (Cat == 4)
                        {
                            cocText.text = $"\n\nFlick Tag [{Tag}]\nAimbot Tag [{Tag2}]\nTag Aura [{Tag3}]\n>Tag All [{Tag4}]\nTag Self [{Tag5}]\nTag Gun [{Tag6}]\nPlaceHolder4";
                        }
                        if (Cat == 5)
                        {
                            cocText.text = $"\n\nSkid All [{Skid}]\nGhost Monke [{Ghost}]\nInvis Monke [{Invis}]\n>Rig Gun [{Force}]\nHold Rig [{Hold}]\nElf Launcher [{Launch}]\nPuke Elves [{Launch2}]";
                        }
                        if (Cat == 6)
                        {
                            cocText.text = $"\n\nMenu Colour [{Colour}]\nTracers From Body [{GameSense}]\nLong Arm Length [{Arm}]\n>Pull Mod Strength [{Pull4}]\nFly Effects [{Effect}]\nStreamable Esp [{Stream}]\nThin Tracers [{Thin}]";
                        }
                        if (Cat == 7)
                        {
                            cocText.text = $"\n\nGain Map Term M\nBreak Game In Party\nKick All [{Launch3}]\n>Error Gamemode Party\nKick Gun\nSet Guardain M\nBreak Freeze Tag M [{Break}]";
                        }
                        break;
                    case 4:
                        if (Cat == 0)
                        {
                            cocText.text = $"\n\nMovement\nVisual\nSaftey\nAdvantage\n>Fun\nSettings\nOp";
                        }
                        if (Cat == 1)
                        {
                            cocText.text = $"\n\nSpeed Boost\nFly [{Fly}]\nHigh Jump [{Long}]\nPull Mod [{Pull}]\n>Long Arms\nPreds [{Pred}]\nJoystick Fly [{Fly2}]";
                        }
                        if (Cat == 2)
                        {
                            cocText.text = $"\n\nChams [{Box}]\nTracers [{Trace}]\nBox Esp [{Box2}]\nBeacons [{Box3}]\n>Trails [{Box4}]\nHollow Box Esp [{Box5}]\nArm Esp [{Box6}]";
                        }
                        if (Cat == 3)
                        {
                            cocText.text = $"\n\nAnti Crash [{AntiCrash}]\nRpc Protection [{Rpc}]\nPlaceHolder3\nPlaceHolder3\n>PlaceHolder3\nPlaceHolder3\nPlaceHolder3";
                        }
                        if (Cat == 4)
                        {
                            cocText.text = $"\n\nFlick Tag [{Tag}]\nAimbot Tag [{Tag2}]\nTag Aura [{Tag3}]\nTag All [{Tag4}]\n>Tag Self [{Tag5}]\nTag Gun [{Tag6}]\nPlaceHolder4";
                        }
                        if (Cat == 5)
                        {
                            cocText.text = $"\n\nSkid All [{Skid}]\nGhost Monke [{Ghost}]\nInvis Monke [{Invis}]\nRig Gun [{Force}]\n>Hold Rig [{Hold}]\nElf Launcher [{Launch}]\nPuke Elves [{Launch2}]";
                        }
                        if (Cat == 6)
                        {
                            cocText.text = $"\n\nMenu Colour [{Colour}]\nTracers From Body [{GameSense}]\nLong Arm Length [{Arm}]\nPull Mod Strength [{Pull4}]\n>Fly Effects [{Effect}]\nStreamable Esp [{Stream}]\nThin Tracers [{Thin}]";
                        }
                        if (Cat == 7)
                        {
                            cocText.text = $"\n\nGain Map Term M\nBreak Game In Party\nKick All [{Launch3}]\nError Gamemode Party\n>Kick Gun\nSet Guardain M\nBreak Freeze Tag M [{Break}]";
                        }
                        break;
                    case 5:
                        if (Cat == 0)
                        {
                            cocText.text = $"\n\nMovement\nVisual\nSaftey\nAdvantage\nFun\n>Settings\nOp";
                        }
                        if (Cat == 1)
                        {
                            cocText.text = $"\n\nSpeed Boost\nFly [{Fly}]\nHigh Jump [{Long}]\nPull Mod [{Pull}]\nLong Arms\n>Preds [{Pred}]\nJoystick Fly [{Fly2}]";
                        }
                        if (Cat == 2)
                        {
                            cocText.text = $"\n\nChams [{Box}]\nTracers [{Trace}]\nBox Esp [{Box2}]\nBeacons [{Box3}]\nTrails [{Box4}]\n>Hollow Box Esp [{Box5}]\nArm Esp [{Box6}]";
                        }
                        if (Cat == 3)
                        {
                            cocText.text = $"\n\nAnti Crash [{AntiCrash}]\nRpc Protection [{Rpc}]\nPlaceHolder3\nPlaceHolder3\nPlaceHolder3\n>PlaceHolder3\nPlaceHolder3";
                        }
                        if (Cat == 4)
                        {
                            cocText.text = $"\n\nFlick Tag [{Tag}]\nAimbot Tag [{Tag2}]\nTag Aura [{Tag3}]\nTag All [{Tag4}]\nTag Self [{Tag5}]\n>Tag Gun [{Tag6}]\nPlaceHolder4";
                        }
                        if (Cat == 5)
                        {
                            cocText.text = $"\n\nSkid All [{Skid}]\nGhost Monke [{Ghost}]\nInvis Monke [{Invis}]\nRig Gun [{Force}]\nHold Rig [{Hold}]\n>Elf Launcher [{Launch}]\nPuke Elves [{Launch2}]";
                        }
                        if (Cat == 6)
                        {
                            cocText.text = $"\n\nMenu Colour [{Colour}]\nTracers From Body [{GameSense}]\nLong Arm Length [{Arm}]\nPull Mod Strength [{Pull4}]\nFly Effects [{Effect}]\n>Streamable Esp [{Stream}]\nThin Tracers [{Thin}]";
                        }
                        if (Cat == 7)
                        {
                            cocText.text = $"\n\nGain Map Term M\nBreak Game In Party\nKick All [{Launch3}]\nError Gamemode Party\nKick Gun\n>Set Guardain M\nBreak Freeze Tag M [{Break}]";
                        }
                        break;
                    case 6:
                        if (Cat == 0)
                        {
                            cocText.text = $"\n\nMovement\nVisual\nSaftey\nAdvantage\nFun\nSettings\n>Op";
                        }
                        if (Cat == 1)
                        {
                            cocText.text = $"\n\nSpeed Boost\nFly [{Fly}]\nHigh Jump [{Long}]\nPull Mod [{Pull}]\nLong Arms\nPreds [{Pred}]\n>Joystick Fly [{Fly2}]";
                        }
                        if (Cat == 2)
                        {
                            cocText.text = $"\n\nChams [{Box}]\nTracers [{Trace}]\nBox Esp [{Box2}]\nBeacons [{Box3}]\nTrails [{Box4}]\nHollow Box Esp [{Box5}]\n>Arm Esp [{Box6}]";
                        }
                        if (Cat == 3)
                        {
                            cocText.text = $"\n\nAnti Crash [{AntiCrash}]\nRpc Protection [{Rpc}]\nPlaceHolder3\nPlaceHolder3\nPlaceHolder3\nPlaceHolder3\n>PlaceHolder3";
                        }
                        if (Cat == 4)
                        {
                            cocText.text = $"\n\nFlick Tag [{Tag}]\nAimbot Tag [{Tag2}]\nTag Aura [{Tag3}]\nTag All [{Tag4}]\nTag Self [{Tag5}]\nTag Gun [{Tag6}]\n>PlaceHolder4";
                        }
                        if (Cat == 5)
                        {
                            cocText.text = $"\n\nSkid All [{Skid}]\nGhost Monke [{Ghost}]\nInvis Monke [{Invis}]\nRig Gun [{Force}]\nHold Rig [{Hold}]\nElf Launcher [{Launch}]\n>Puke Elves [{Launch2}]";
                        }
                        if (Cat == 6)
                        {
                            cocText.text = $"\n\nMenu Colour [{Colour}]\nTracers From Body [{GameSense}]\nLong Arm Length [{Arm}]\nPull Mod Strength [{Pull4}]\nFly Effects [{Effect}]\nStreamable Esp [{Stream}]\n>Thin Tracers [{Thin}]";
                        }
                        if (Cat == 7)
                        {
                            cocText.text = $"\n\nGain Map Term M\nBreak Game In Party\nKick All [{Launch3}]\nError Gamemode Party\nKick Gun\nSet Guardain M\n>Break Freeze Tag M [{Break}]";
                        }
                        break;
                }
            }
            }
        }
    }