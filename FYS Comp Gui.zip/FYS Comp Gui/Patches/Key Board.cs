﻿using GorillaNetworking;
using Photon.Pun;
using ExitGames.Client.Photon;
using System;
using System.Collections.Generic;
using System.Text;
using TMPro;
using UnityEngine;
using UnityEngine.InputSystem;
using StupidTemplate.Patches;
using System.Reflection;

namespace FYS_Comp_Gui.Patches
{
    internal class Key_Board
    {
        public static int HorizontalInt = 0;
        public static int VertacalInt = 0;
        public static float last = 0;
        public static float TypeShit = 0;
        public static string Letter = "";
        public static string Mode = "";
        public static string Typed = "";
        public static void Start()
        {
            if (Time.time - last > 0.2f)
            {
                if (ControllerInputPoller.instance.rightControllerPrimary2DAxis.y >= 0.5f || Keyboard.current.upArrowKey.isPressed && Time.time - last > 0.2f)
                {
                    last = Time.time;
                    VertacalInt--;
                }
                if (ControllerInputPoller.instance.rightControllerPrimary2DAxis.y <= -0.5f || Keyboard.current.downArrowKey.isPressed && Time.time - last > 0.2f)
                {
                    last = Time.time;
                    VertacalInt++;
                }
                if (ControllerInputPoller.instance.rightControllerPrimary2DAxis.x >= 0.5f || Keyboard.current.rightArrowKey.isPressed && Time.time - last > 0.2f)
                {
                    last = Time.time;
                    HorizontalInt++;
                }
                if (ControllerInputPoller.instance.rightControllerPrimary2DAxis.x <= -0.5f || Keyboard.current.leftArrowKey.isPressed && Time.time - last > 0.2f)
                {
                    last = Time.time;
                    HorizontalInt--;
                }
                if (ControllerInputPoller.instance.rightGrab || Keyboard.current.eKey.isPressed && Time.time - last > 0.2f)
                {
                    last = Time.time;
                    TypeShit++;
                }
                if (VertacalInt > 3)
                {
                    VertacalInt = 0;
                }
                if (TypeShit > 2)
                {
                    TypeShit = 0;
                }
                if (VertacalInt < 0)
                {
                    VertacalInt = 3;
                }
                if (VertacalInt < 0)
                {
                    VertacalInt = 0;
                }
                if (VertacalInt == 0 && HorizontalInt > 10)
                {
                    HorizontalInt = 0;
                }
                if (VertacalInt == 1 && HorizontalInt > 9)
                {
                    HorizontalInt = 0;
                }
                if (VertacalInt == 2 && HorizontalInt > 8)
                {
                    HorizontalInt = 0;
                }
                if (VertacalInt == 3 && HorizontalInt > 7)
                {
                    HorizontalInt = 0;
                }
                if (VertacalInt == 0 && HorizontalInt < 0)
                {
                    HorizontalInt = 9;
                }
                if (VertacalInt == 1 && HorizontalInt < 0)
                {
                    HorizontalInt = 9;
                }
                if (VertacalInt == 2 && HorizontalInt < 0)
                {
                    HorizontalInt = 8;
                }
                if (VertacalInt == 3 && HorizontalInt < 0)
                {
                    HorizontalInt = 7;
                }
                if (TypeShit == 0)
                {
                    Mode = "Chat";
                }
                if (TypeShit == 1)
                {
                    Mode = "Join Room";
                }
                if (TypeShit == 2)
                {
                    Mode = "Set Name";
                }
                if (ControllerInputPoller.instance.rightControllerIndexFloat >= 0.5f || Keyboard.current.enterKey.isPressed && Time.time - last > 0.2f)
                {
                    last = Time.time;
                    if (Letter != "ENTER" && Letter != "CLEAR")
                    {
                        Typed += Letter;
                    }
                    if (Letter == "CLEAR")
                    {
                        Typed = "";
                    }
                    if (Letter == "ENTER")
                    {
                        if (TypeShit == 0)
                        {
                            var customProperties = new Hashtable { { "Message", Typed } };
                            PhotonNetwork.LocalPlayer.SetCustomProperties(customProperties);
                            Mode = "Chat";
                        }
                        if (TypeShit == 1)
                        {
                            PhotonNetworkController.Instance.AttemptToJoinSpecificRoom(Typed, JoinType.Solo);
                            Mode = "Join Room";
                        }
                        if (TypeShit == 2)
                        {
                            PhotonNetwork.LocalPlayer.NickName = Typed;
                            GorillaComputer.instance.currentName = Typed;
                            PlayerPrefs.SetString("playerName", Typed);
                            GorillaComputer.instance.savedName = Typed;
                            GorillaComputer.instance.offlineVRRigNametagText.text = Typed;
                            PlayerPrefs.Save();
                            Mode = "Set Name";
                        }
                    }
                }
            }
            GameObject text = new GameObject("KeyBoard");
            TextMeshPro tmp = text.AddComponent<TextMeshPro>();
            tmp.fontSize = 0.35f;
            tmp.alignment = TextAlignmentOptions.Center;
            text.transform.position = Camera.main.transform.position + Camera.main.transform.forward * 0.6f - Camera.main.transform.up * 0.3f;
            text.transform.SetParent(Camera.main.transform);
            text.transform.LookAt(Camera.main.transform);
            text.transform.Rotate(0, 180, 0);
            text.layer = 19;
            if (TypeShit == 0)
            {
                GameObject text3 = new GameObject("Chat");
                TextMeshPro tmp3 = text3.AddComponent<TextMeshPro>();
                tmp3.fontSize = 0.35f;
                tmp3.alignment = TextAlignmentOptions.Center;
                text3.transform.position = Camera.main.transform.position + Camera.main.transform.forward * 1 - Camera.main.transform.right * 0.4f;
                text3.transform.SetParent(Camera.main.transform);
                text3.transform.LookAt(Camera.main.transform);
                text3.transform.Rotate(0, 180, 0);
                text3.layer = 19;
                tmp3.text = "Chat:\n";
                foreach (Photon.Realtime.Player player in PhotonNetwork.PlayerList)
                {
                    if (player.CustomProperties.TryGetValue("Message", out object Msg))
                    {
                        string Message = Msg?.ToString();
                        string Name = player.NickName;
                        if (!tmp3.text.Contains(Message))
                        {
                            tmp3.text += Name + ": " + Message + "\n";
                        }
                    }
                }
                UnityEngine.Object.Destroy(text3, Time.deltaTime);
            }
            if (TypeShit == 1)
            {
                GameObject text3 = new GameObject("Chat");
                TextMeshPro tmp3 = text3.AddComponent<TextMeshPro>();
                tmp3.fontSize = 0.35f;
                tmp3.alignment = TextAlignmentOptions.Center;
                text3.transform.position = Camera.main.transform.position + Camera.main.transform.forward * 1 - Camera.main.transform.right * 0.4f;
                text3.transform.SetParent(Camera.main.transform);
                text3.transform.LookAt(Camera.main.transform);
                text3.transform.Rotate(0, 180, 0);
                text3.layer = 19;
                tmp3.text = "Room Join:\n" + Typed;
                UnityEngine.Object.Destroy(text3, Time.deltaTime);
            }
            if (TypeShit == 2)
            {
                GameObject text3 = new GameObject("Chat");
                TextMeshPro tmp3 = text3.AddComponent<TextMeshPro>();
                tmp3.fontSize = 0.35f;
                tmp3.alignment = TextAlignmentOptions.Center;
                text3.transform.position = Camera.main.transform.position + Camera.main.transform.forward * 1 - Camera.main.transform.right * 0.4f;
                text3.transform.SetParent(Camera.main.transform);
                text3.transform.LookAt(Camera.main.transform);
                text3.transform.Rotate(0, 180, 0);
                text3.layer = 19;
                tmp3.text = "Set Name:\n" + Typed;
                UnityEngine.Object.Destroy(text3, Time.deltaTime);
            }
            GameObject text2 = new GameObject("Typed");
            TextMeshPro tmp2 = text2.AddComponent<TextMeshPro>();
            tmp2.fontSize = 0.35f;
            tmp2.alignment = TextAlignmentOptions.Center;
            text2.transform.position = Camera.main.transform.position + Camera.main.transform.forward * 0.6f - Camera.main.transform.up * 0.1f;
            text2.transform.SetParent(Camera.main.transform);
            text2.transform.LookAt(Camera.main.transform);
            text2.transform.Rotate(0, 180, 0);
            text2.layer = 19;
            tmp2.text = Typed;
            if (HorizontalInt == 0 && VertacalInt == 0)
            {
                tmp.text = $"{Mode}\n[1] 2 3 4 5 6 7 8 9 0  CLEAR\nQ W E R T Y U I O P\nA S D F G H J K L\nZ X C V B N M   ENTER";
                Letter = "1";
            }
            if (HorizontalInt == 1 && VertacalInt == 0)
            {
                tmp.text = $"{Mode}\n1 [2] 3 4 5 6 7 8 9 0  CLEAR\nQ W E R T Y U I O P\nA S D F G H J K L\nZ X C V B N M   ENTER";
                Letter = "2";
            }
            if (HorizontalInt == 2 && VertacalInt == 0)
            {
                tmp.text = $"{Mode}\n1 2 [3] 4 5 6 7 8 9 0  CLEAR\nQ W E R T Y U I O P\nA S D F G H J K L\nZ X C V B N M   ENTER";
                Letter = "3";
            }
            if (HorizontalInt == 3 && VertacalInt == 0)
            {
                tmp.text = $"{Mode}\n1 2 3 [4] 5 6 7 8 9 0  CLEAR\nQ W E R T Y U I O P\nA S D F G H J K L\nZ X C V B N M   ENTER";
                Letter = "4";
            }
            if (HorizontalInt == 4 && VertacalInt == 0)
            {
                tmp.text = $"{Mode}\n1 2 3 4 [5] 6 7 8 9 0  CLEAR\nQ W E R T Y U I O P\nA S D F G H J K L\nZ X C V B N M   ENTER";
                Letter = "5";
            }
            if (HorizontalInt == 5 && VertacalInt == 0)
            {
                tmp.text = $"{Mode}\n1 2 3 4 5 [6] 7 8 9 0  CLEAR\nQ W E R T Y U I O P\nA S D F G H J K L\nZ X C V B N M   ENTER";
                Letter = "6";
            }
            if (HorizontalInt == 6 && VertacalInt == 0)
            {
                tmp.text = $"{Mode}\n1 2 3 4 5 6 [7] 8 9 0  CLEAR\nQ W E R T Y U I O P\nA S D F G H J K L\nZ X C V B N M   ENTER";
                Letter = "7";
            }
            if (HorizontalInt == 7 && VertacalInt == 0)
            {
                tmp.text = $"{Mode}\n1 2 3 4 5 6 7 [8] 9 0  CLEAR\nQ W E R T Y U I O P\nA S D F G H J K L\nZ X C V B N M   ENTER";
                Letter = "8";
            }
            if (HorizontalInt == 8 && VertacalInt == 0)
            {
                tmp.text = $"{Mode}\n1 2 3 4 5 6 7 8 [9] 0  CLEAR\nQ W E R T Y U I O P\nA S D F G H J K L\nZ X C V B N M   ENTER";
                Letter = "9";
            }
            if (HorizontalInt == 9 && VertacalInt == 0)
            {
                tmp.text = $"{Mode}\n1 2 3 4 5 6 7 8 9 [0]  CLEAR\nQ W E R T Y U I O P\nA S D F G H J K L\nZ X C V B N M   ENTER";
                Letter = "0";
            }
            if (HorizontalInt == 10 && VertacalInt == 0)
            {
                tmp.text = $"{Mode}\n1 2 3 4 5 6 7 8 9 0  [CLEAR]\nQ W E R T Y U I O P\nA S D F G H J K L\nZ X C V B N M   ENTER";
                Letter = "CLEAR";
            }
            if (HorizontalInt == 0 && VertacalInt == 1)
            {
                tmp.text = $"{Mode}\n1 2 3 4 5 6 7 8 9 0  CLEAR\n[Q] W E R T Y U I O P\nA S D F G H J K L\nZ X C V B N M   ENTER";
                Letter = "Q";
            }
            if (HorizontalInt == 1 && VertacalInt == 1)
            {
                tmp.text = $"{Mode}\n1 2 3 4 5 6 7 8 9 0  CLEAR\nQ [W] E R T Y U I O P\nA S D F G H J K L\nZ X C V B N M   ENTER";
                Letter = "W";
            }
            if (HorizontalInt == 2 && VertacalInt == 1)
            {
                tmp.text = $"{Mode}\n1 2 3 4 5 6 7 8 9 0  CLEAR\nQ W [E] R T Y U I O P\nA S D F G H J K L\nZ X C V B N M   ENTER";
                Letter = "E";
            }
            if (HorizontalInt == 3 && VertacalInt == 1)
            {
                tmp.text = $"{Mode}\n1 2 3 4 5 6 7 8 9 0  CLEAR\nQ W E [R] T Y U I O P\nA S D F G H J K L\nZ X C V B N M   ENTER";
                Letter = "R";
            }
            if (HorizontalInt == 4 && VertacalInt == 1)
            {
                tmp.text = $"{Mode}\n1 2 3 4 5 6 7 8 9 0  CLEAR\nQ W E R [T] Y U I O P\nA S D F G H J K L\nZ X C V B N M   ENTER";
                Letter = "T";
            }
            if (HorizontalInt == 5 && VertacalInt == 1)
            {
                tmp.text = $"{Mode}\n1 2 3 4 5 6 7 8 9 0  CLEAR\nQ W E R T [Y] U I O P\nA S D F G H J K L\nZ X C V B N M   ENTER";
                Letter = "Y";
            }
            if (HorizontalInt == 6 && VertacalInt == 1)
            {
                tmp.text = $"{Mode}\n1 2 3 4 5 6 7 8 9 0  CLEAR\nQ W E R T Y [U] I O P\nA S D F G H J K L\nZ X C V B N M   ENTER";
                Letter = "U";
            }
            if (HorizontalInt == 7 && VertacalInt == 1)
            {
                tmp.text = $"{Mode}\n1 2 3 4 5 6 7 8 9 0  CLEAR\nQ W E R T Y U [I] O P\nA S D F G H J K L\nZ X C V B N M   ENTER";
                Letter = "I";
            }
            if (HorizontalInt == 8 && VertacalInt == 1)
            {
                tmp.text = $"{Mode}\n1 2 3 4 5 6 7 8 9 0  CLEAR\nQ W E R T Y U I [O] P\nA S D F G H J K L\nZ X C V B N M   ENTER";
                Letter = "O";
            }
            if (HorizontalInt == 9 && VertacalInt == 1)
            {
                tmp.text = $"{Mode}\n1 2 3 4 5 6 7 8 9 0  CLEAR\nQ W E R T Y U I O [P]\nA S D F G H J K L\nZ X C V B N M   ENTER";
                Letter = "P";
            }
            if (HorizontalInt == 0 && VertacalInt == 2)
            {
                tmp.text = $"{Mode}\n1 2 3 4 5 6 7 8 9 0  CLEAR\nQ W E R T Y U I O P\n[A] S D F G H J K L\nZ X C V B N M   ENTER";
                Letter = "A";
            }
            if (HorizontalInt == 1 && VertacalInt == 2)
            {
                tmp.text = $"{Mode}\n1 2 3 4 5 6 7 8 9 0  CLEAR\nQ W E R T Y U I O P\nA [S] D F G H J K L\nZ X C V B N M   ENTER";
                Letter = "S";
            }
            if (HorizontalInt == 2 && VertacalInt == 2)
            {
                tmp.text = $"{Mode}\n1 2 3 4 5 6 7 8 9 0  CLEAR\nQ W E R T Y U I O P\nA S [D] F G H J K L\nZ X C V B N M   ENTER";
                Letter = "D";
            }
            if (HorizontalInt == 3 && VertacalInt == 2)
            {
                tmp.text = $"{Mode}\n1 2 3 4 5 6 7 8 9 0  CLEAR\nQ W E R T Y U I O P\nA S D [F] G H J K L\nZ X C V B N M   ENTER";
                Letter = "F";
            }
            if (HorizontalInt == 4 && VertacalInt == 2)
            {
                tmp.text = $"{Mode}\n1 2 3 4 5 6 7 8 9 0  CLEAR\nQ W E R T Y U I O P\nA S D F [G] H J K L\nZ X C V B N M   ENTER";
                Letter = "G";
            }
            if (HorizontalInt == 5 && VertacalInt == 2)
            {
                tmp.text = $"{Mode}\n1 2 3 4 5 6 7 8 9 0  CLEAR\nQ W E R T Y U I O P\nA S D F G [H] J K L\nZ X C V B N M   ENTER";
                Letter = "H";
            }
            if (HorizontalInt == 6 && VertacalInt == 2)
            {
                tmp.text = $"{Mode}\n1 2 3 4 5 6 7 8 9 0  CLEAR\nQ W E R T Y U I O P\nA S D F G H [J] K L\nZ X C V B N M   ENTER";
                Letter = "J";
            }
            if (HorizontalInt == 7 && VertacalInt == 2)
            {
                tmp.text = $"{Mode}\n1 2 3 4 5 6 7 8 9 0  CLEAR\nQ W E R T Y U I O P\nA S D F G H J [K] L\nZ X C V B N M   ENTER";
                Letter = "K";
            }
            if (HorizontalInt == 8 && VertacalInt == 2)
            {
                tmp.text = $"{Mode}\n1 2 3 4 5 6 7 8 9 0  CLEAR\nQ W E R T Y U I O P\nA S D F G H J K [L]\nZ X C V B N M   ENTER";
                Letter = "L";
            }
            if (HorizontalInt == 0 && VertacalInt == 3)
            {
                tmp.text = $"{Mode}\n1 2 3 4 5 6 7 8 9 0  CLEAR\nQ W E R T Y U I O P\nA S D F G H J K L\n[Z] X C V B N M   ENTER";
                Letter = "Z";
            }
            if (HorizontalInt == 1 && VertacalInt == 3)
            {
                tmp.text = $"{Mode}\n1 2 3 4 5 6 7 8 9 0  CLEAR\nQ W E R T Y U I O P\nA S D F G H J K L\nZ [X] C V B N M   ENTER";
                Letter = "X";
            }
            if (HorizontalInt == 2 && VertacalInt == 3)
            {
                tmp.text = $"{Mode}\n1 2 3 4 5 6 7 8 9 0  CLEAR\nQ W E R T Y U I O P\nA S D F G H J K L\nZ X [C] V B N M   ENTER";
                Letter = "C";
            }
            if (HorizontalInt == 3 && VertacalInt == 3)
            {
                tmp.text = $"{Mode}\n1 2 3 4 5 6 7 8 9 0  CLEAR\nQ W E R T Y U I O P\nA S D F G H J K L\nZ X C [V] B N M   ENTER";
                Letter = "V";
            }
            if (HorizontalInt == 4 && VertacalInt == 3)
            {
                tmp.text = $"{Mode}\n1 2 3 4 5 6 7 8 9 0  CLEAR\nQ W E R T Y U I O P\nA S D F G H J K L\nZ X C V [B] N M   ENTER";
                Letter = "B";
            }
            if (HorizontalInt == 5 && VertacalInt == 3)
            {
                tmp.text = $"{Mode}\n1 2 3 4 5 6 7 8 9 0  CLEAR\nQ W E R T Y U I O P\nA S D F G H J K L\nZ X C V B [N] M   ENTER";
                Letter = "N";
            }
            if (HorizontalInt == 6 && VertacalInt == 3)
            { 
                tmp.text = $"{Mode}\n1 2 3 4 5 6 7 8 9 0  CLEAR\nQ W E R T Y U I O P\nA S D F G H J K L\nZ X C V B N [M]   ENTER";
                Letter = "M";
            }
            if (HorizontalInt == 7 && VertacalInt == 3)
            {
                tmp.text = $"{Mode}\n1 2 3 4 5 6 7 8 9 0  CLEAR\nQ W E R T Y U I O P\nA S D F G H J K L\nZ X C V B N M   [ENTER]";
                Letter = "ENTER";
            }
            UnityEngine.Object.Destroy(text, Time.deltaTime);
            UnityEngine.Object.Destroy(text2, Time.deltaTime);
        }
    }
}
