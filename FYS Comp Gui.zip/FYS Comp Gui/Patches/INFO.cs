﻿using System;
using System.Net.Http;
using Newtonsoft.Json.Linq;
using System.Collections.Generic;
using System.Text;
using TMPro;
using UnityEngine;
using System.Threading.Tasks;

namespace FYS_Comp_Gui.Patches
{
    internal interface INFO
    {
        public static bool Buttons = false;
        public static bool Data = false;
        public static string id = "";
        private static float last3 = 0f;
        public static async void Display()
        {
            Ray ray = new Ray(Camera.main.transform.position, Camera.main.transform.forward);
            RaycastHit hit;
            if (Physics.Raycast(ray, out hit, Mathf.Infinity))
            {
                float closestDistance = float.MaxValue;
                VRRig closestVRRig = null;
                foreach (VRRig vrrig in GorillaParent.instance.vrrigs)
                {
                    float distance = Vector3.Distance(hit.point, vrrig.transform.position);
                    if (distance < closestDistance)
                    {
                        closestDistance = distance;
                        closestVRRig = vrrig;
                    }
                }
                if (closestVRRig != null && closestVRRig != GorillaTagger.Instance.offlineVRRig)
                {
                    GorillaSpeakerLoudness Voice = closestVRRig.GetComponent<GorillaSpeakerLoudness>();
                    float Size = Voice.Loudness * 5f;
                    GameObject line2 = new GameObject("Line");
                    LineRenderer liner2 = line2.AddComponent<LineRenderer>();
                    liner2.startColor = Color.green;
                    liner2.endColor = Color.green;
                    liner2.startWidth = 0.01f;
                    liner2.endWidth = 0.01f;
                    liner2.positionCount = 5;
                    liner2.useWorldSpace = true;
                    Vector3 r = Camera.main.transform.right;
                    Vector3 Up = Camera.main.transform.up;
                    Vector3 center = closestVRRig.headConstraint.transform.position + new Vector3(0f, 0.1f, 0f);
                    liner2.SetPosition(0, center + Up * 0.15f + r * 0.15f);
                    liner2.SetPosition(1, center + Up * 0.15f - r * 0.15f);
                    liner2.SetPosition(2, center - Up * 0.15f - r * 0.15f);
                    liner2.SetPosition(3, center - Up * 0.15f + r * 0.15f);
                    liner2.SetPosition(4, center + Up * 0.15f + r * 0.15f);
                    line2.layer = 19;
                    Renderer renderer2 = liner2.GetComponent<Renderer>();
                    Material material2 = renderer2.material;
                    material2.shader = Shader.Find("GUI/Text Shader");
                    GameObject text3 = new GameObject("Info");
                    TextMeshPro tmp3 = text3.AddComponent<TextMeshPro>();
                    tmp3.fontSize = 0.35f;
                    tmp3.color = Color.green;
                    tmp3.alignment = TextAlignmentOptions.Center;
                    text3.transform.position = closestVRRig.transform.position + closestVRRig.transform.right * 0.45f + closestVRRig.transform.up * 0.45f;
                    text3.transform.LookAt(Camera.main.transform);
                    text3.layer = 19;
                    text3.transform.Rotate(0, 180, 0);
                    tmp3.text = "Player Info:\n";
                    tmp3.text += "Name: " + closestVRRig.OwningNetPlayer.NickName + "\n";
                    tmp3.text += "Id: " + closestVRRig.OwningNetPlayer.UserId + "\n";
                    tmp3.text += "Actor Num: " + closestVRRig.OwningNetPlayer.ActorNumber + "\n";
                    tmp3.text += "Master Client: " + closestVRRig.OwningNetPlayer.IsMasterClient + "\n";
                    tmp3.text += "Steam: " + closestVRRig.concatStringOfCosmeticsAllowed.Contains("FIRST LOGIN") + "\n";
                    tmp3.text += "Colour: " + closestVRRig.playerColor + "\n";
                    GameObject text4 = new GameObject("Info");
                    TextMeshPro tmp4 = text4.AddComponent<TextMeshPro>();
                    tmp4.fontSize = 0.35f;
                    tmp4.color = Color.green;
                    tmp4.alignment = TextAlignmentOptions.Center;
                    text4.transform.position = closestVRRig.transform.position - closestVRRig.transform.right * 0.5f + closestVRRig.transform.up * 0.2f;
                    text4.transform.LookAt(Camera.main.transform);
                    text4.layer = 19;
                    text4.transform.Rotate(0, 180, 0);
                    tmp4.text = "Data Base:\n";
                    GameObject text = new GameObject("Gui");
                    TextMeshPro tmp = text.AddComponent<TextMeshPro>();
                    tmp.fontSize = 0.35f;
                    tmp.alignment = TextAlignmentOptions.Center;
                    text.transform.position = Camera.main.transform.position + Camera.main.transform.forward * 0.5f - Camera.main.transform.right * 0.5f - Camera.main.transform.up * 0.2f;
                    text.transform.SetParent(Camera.main.transform);
                    text.transform.LookAt(Camera.main.transform);
                    text.transform.Rotate(0, 180, 0);
                    text.layer = 19;
                    tmp.text = "";
                    tmp.color = Color.green;
                    GameObject text5 = new GameObject("Info");
                    TextMeshPro tmp5 = text5.AddComponent<TextMeshPro>();
                    tmp5.fontSize = 0.35f;
                    tmp5.color = Color.green;
                    tmp5.alignment = TextAlignmentOptions.Center;
                    text5.transform.position = closestVRRig.transform.position - closestVRRig.transform.right * 0.5f - closestVRRig.transform.up * 0.3f;
                    text5.transform.LookAt(Camera.main.transform);
                    text5.layer = 19;
                    text5.transform.Rotate(0, 180, 0);
                    tmp5.text = "";
                    if (closestVRRig.rightMiddle.calcT > 0.2f)
                    {
                        tmp5.text += $"Right Grip {closestVRRig.rightMiddle.calcT}\n";
                    }
                    if (closestVRRig.leftMiddle.calcT > 0.2f)
                    {
                        tmp5.text += $"Left Grip {closestVRRig.leftMiddle.calcT}\n";
                    }
                    if (closestVRRig.rightIndex.calcT > 0.2f)
                    {
                        tmp5.text += $"Right Trigger {closestVRRig.rightIndex.calcT}\n";
                    }
                    if (closestVRRig.leftIndex.calcT > 0.2f)
                    {
                        tmp5.text += $"Left Trigger {closestVRRig.leftIndex.calcT}\n";
                    }
                    if (closestVRRig.rightThumb.calcT > 0.2f)
                    {
                        tmp5.text += $"Right Thumb {closestVRRig.rightThumb.calcT}\n";
                    }
                    if (closestVRRig.leftThumb.calcT > 0.2f)
                    {
                        tmp5.text += $"Left Thumb {closestVRRig.leftThumb.calcT}\n";
                    }
                    if (closestVRRig.leftThumb.calcT > 0.2f || closestVRRig.rightThumb.calcT > 0.2f || closestVRRig.leftIndex.calcT > 0.2f || closestVRRig.rightIndex.calcT > 0.2f || closestVRRig.leftMiddle.calcT > 0.2f || closestVRRig.rightMiddle.calcT > 0.2f)
                    {
                        Buttons = true;
                    }
                    else
                    {
                        Buttons = false;
                    }
                    GameObject Voice2 = GameObject.CreatePrimitive(PrimitiveType.Cube);
                    Voice2.transform.position = closestVRRig.transform.position + closestVRRig.transform.right * 0.5f - closestVRRig.transform.up * 0.2f;
                    Voice2.transform.localScale = new Vector3(0.1f, Size, 0.2f);
                    Voice2.transform.LookAt(Camera.main.transform);
                    Voice2.layer = 19;
                    Voice2.transform.Rotate(0, 180, 0);
                    UnityEngine.Object.Destroy(Voice2.GetComponent<BoxCollider>());
                    UnityEngine.Object.Destroy(Voice2.GetComponent<Rigidbody>());
                    Renderer renderer3 = Voice2.GetComponent<Renderer>();
                    Material material3 = renderer3.material;
                    material3.shader = Shader.Find("GUI/Text Shader");
                    material3.color = Color.green;
                    GameObject line = new GameObject("Line");
                    LineRenderer liner = line.AddComponent<LineRenderer>();
                    liner.startColor = Color.green;
                    liner.endColor = Color.green;
                    liner.startWidth = 0.01f;
                    liner.endWidth = 0.01f;
                    liner.positionCount = 5;
                    liner.useWorldSpace = true;
                    liner.SetPosition(0, text3.transform.position);
                    liner.SetPosition(1, text3.transform.position + text3.transform.right * 0.3f);
                    liner.SetPosition(2, closestVRRig.headConstraint.transform.position + new Vector3(0f, 0.25f, 0f));
                    liner.SetPosition(3, text4.transform.position - text3.transform.right * 0.3f);
                    liner.SetPosition(4, text4.transform.position);
                    line.layer = 19;
                    Renderer renderer = liner.GetComponent<Renderer>();
                    Material material = renderer.material;
                    material.shader = Shader.Find("GUI/Text Shader");
                    if (Buttons)
                    {
                        GameObject line3 = new GameObject("Line");
                        LineRenderer liner3 = line3.AddComponent<LineRenderer>();
                        liner3.startColor = Color.green;
                        liner3.endColor = Color.green;
                        liner3.startWidth = 0.01f;
                        liner3.endWidth = 0.01f;
                        liner3.positionCount = 3;
                        liner3.useWorldSpace = true;
                        liner3.SetPosition(2, text5.transform.position);
                        liner3.SetPosition(1, text5.transform.position - text3.transform.right * 0.3f);
                        liner3.SetPosition(0, closestVRRig.headConstraint.transform.position + new Vector3(0f, 0.25f, 0f));
                        line3.layer = 19;
                        Renderer renderer4 = liner3.GetComponent<Renderer>();
                        Material material4 = renderer4.material;
                        material4.shader = Shader.Find("GUI/Text Shader");
                        UnityEngine.Object.Destroy(material4, Time.deltaTime);
                        UnityEngine.Object.Destroy(line3, Time.deltaTime);
                    }
                    UnityEngine.Object.Destroy(text3, Time.deltaTime);
                    UnityEngine.Object.Destroy(line, Time.deltaTime);
                    UnityEngine.Object.Destroy(material, Time.deltaTime);
                    UnityEngine.Object.Destroy(line2, Time.deltaTime);
                    UnityEngine.Object.Destroy(material2, Time.deltaTime);
                    UnityEngine.Object.Destroy(renderer2, Time.deltaTime);
                    UnityEngine.Object.Destroy(text4, Time.deltaTime);
                    UnityEngine.Object.Destroy(material2, Time.deltaTime);
                    UnityEngine.Object.Destroy(text5, Time.deltaTime);
                    UnityEngine.Object.Destroy(material3, Time.deltaTime);
                    UnityEngine.Object.Destroy(Voice2, Time.deltaTime);
                }
            }
        }
    }
}
