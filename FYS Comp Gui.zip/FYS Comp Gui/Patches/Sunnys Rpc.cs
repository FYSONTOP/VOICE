﻿using Photon.Pun;
using System;
using System.Collections.Generic;
using System.Text;

namespace FYS_Comp_Gui.Patches
{
    internal class Sunnys_Rpc
    {
        public static void RPCProtection()
        {
            try
            {
                GorillaNot.instance.rpcErrorMax = int.MaxValue;
                GorillaNot.instance.rpcCallLimit = int.MaxValue;
                GorillaNot.instance.logErrorMax = int.MaxValue;
                PhotonNetwork.MaxResendsBeforeDisconnect = int.MaxValue;
                PhotonNetwork.QuickResends = int.MaxValue;
                PhotonNetwork.OpCleanActorRpcBuffer(PhotonNetwork.LocalPlayer.ActorNumber);
                PhotonNetwork.SendAllOutgoingCommands();
                GorillaNot.instance.OnPlayerLeftRoom(PhotonNetwork.LocalPlayer);
            }
            catch { UnityEngine.Debug.Log("RPC protection failed, you fucking dumb ass why just join a lobbie"); }
        }
    }
}
