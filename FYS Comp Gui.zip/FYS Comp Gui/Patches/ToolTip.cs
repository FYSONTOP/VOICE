﻿using System;
using System.Collections.Generic;
using System.Text;
using TMPro;
using UnityEngine;

namespace StupidTemplate.Patches
{
    internal class ToolTip
    {
        public static float last = 0;
        public static void ToolTipSend(string thing, bool mod, string ToolTip, bool ED, bool Important)
        {
            if (Time.time - last > 1.5f)
            {
                last = Time.time;
                if (mod)
                {
                    GameObject text4 = new GameObject("Enabled");
                    TextMeshPro tmp4 = text4.AddComponent<TextMeshPro>();
                    tmp4.fontSize = 0.35f;
                    tmp4.alignment = TextAlignmentOptions.Center;
                    text4.transform.position = Camera.main.transform.position + Camera.main.transform.forward * 1 - Camera.main.transform.up * 0.4f;
                    text4.transform.SetParent(Camera.main.transform);
                    text4.transform.LookAt(Camera.main.transform);
                    text4.transform.Rotate(0, 180, 0);
                    text4.layer = 19;
                    if (Important)
                    {
                        GorillaTagger.Instance.offlineVRRig.PlayHandTapLocal(40, true, 0.4f);
                    }
                    if (ED)
                    {
                        tmp4.color = Color.green;
                        tmp4.text = "[Enable] " + ToolTip;
                        UnityEngine.Object.Destroy(text4, 1.5f);
                    }
                    if (!ED)
                    {
                        tmp4.color = Color.red;
                        tmp4.text = "[Disable] " + ToolTip;
                        UnityEngine.Object.Destroy(text4, 1.5f);
                    }
                }
                if (!mod)
                {
                    GameObject text4 = new GameObject("Enabled");
                    TextMeshPro tmp4 = text4.AddComponent<TextMeshPro>();
                    tmp4.fontSize = 0.35f;
                    tmp4.alignment = TextAlignmentOptions.Center;
                    text4.transform.position = Camera.main.transform.position + Camera.main.transform.forward * 1 - Camera.main.transform.up * 0.4f;
                    text4.transform.SetParent(Camera.main.transform);
                    text4.transform.LookAt(Camera.main.transform);
                    text4.transform.Rotate(0, 180, 0);
                    text4.layer = 19;
                    if (Important)
                    {
                        GorillaTagger.Instance.offlineVRRig.PlayHandTapLocal(40, true, 0.4f);
                    }
                    if (ED)
                    {
                        tmp4.color = Color.green;
                        tmp4.text = $"[{thing}] " + ToolTip;
                        UnityEngine.Object.Destroy(text4, 1.5f);
                    }
                    if (!ED)
                    {
                        tmp4.color = Color.red;
                        tmp4.text = $"[{thing}] " + ToolTip;
                        UnityEngine.Object.Destroy(text4, 1.5f);
                    }
                }
            }
        }
    }
}
