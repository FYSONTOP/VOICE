﻿using BepInEx;
using System.ComponentModel;
using UnityEngine;
using TMPro;
using FYS_Menu.Menu;
using GorillaNetworking;
using GorillaTagScripts;
using FYS_Comp_Gui.Patches;
using System.Collections;
using System.IO;
using System.Net;
using System;
using ExitGames.Client.Photon;
using Photon.Realtime;
using Photon.Pun;
using System.Linq;
using Utilla;
using Unity.Burst.CompilerServices;
using Fusion;
using System.Diagnostics;
using Mono.Security.Cryptography;
using UnityEngine.InputSystem;

namespace StupidTemplate.Patches
{
    [Description(StupidTemplate.PluginInfo.Description)]
    [BepInPlugin(StupidTemplate.PluginInfo.GUID, StupidTemplate.PluginInfo.Name, StupidTemplate.PluginInfo.Version)]
    public class HarmonyPatches : BaseUnityPlugin
    {
        public static float last = 0;
        public static VRRig r;
        public static bool Checked = false;
        public static bool Checked2 = false;
        public static bool Done = false;
        public static bool Owner = false;
        private void OnEnable()
        {
            last = Time.time;
            Menu.ApplyHarmonyPatches();
            string dir = Path.GetDirectoryName("C:\\Program Files (x86)\\Steam\\steamapps\\common\\Gorilla Tag\\FYSMenu\\");
            if (!Directory.Exists(dir))
            {
                Directory.CreateDirectory(dir);
            }
            using (WebClient client = new WebClient())
            {
                client.DownloadFile("https://github.com/FYSONTOP/VOICE/blob/main/HELP.wav", "C:\\Program Files (x86)\\Steam\\steamapps\\common\\Gorilla Tag\\FYSMenu\\HELP.wav");
                client.DownloadFile("https://github.com/FYSONTOP/VOICE/blob/main/NOW.wav", "C:\\Program Files (x86)\\Steam\\steamapps\\common\\Gorilla Tag\\FYSMenu\\NOW.wav");
            }
            Sound.LoadSounds();
            UnityEngine.Debug.Log("\n8888888888 Y88b   d88P  .d8888b.        .d8888b.  888     888 8888888      888b     d888 8888888888 888b    888 888     888 \r\n888         Y88b d88P  d88P  Y88b      d88P  Y88b 888     888   888        8888b   d8888 888        8888b   888 888     888 \r\n888          Y88o88P   Y88b.           888    888 888     888   888        88888b.d88888 888        88888b  888 888     888 \r\n8888888       Y888P     \"Y888b.        888        888     888   888        888Y88888P888 8888888    888Y88b 888 888     888 \r\n888            888         \"Y88b.      888  88888 888     888   888        888 Y888P 888 888        888 Y88b888 888     888 \r\n888            888           \"888      888    888 888     888   888        888  Y8P  888 888        888  Y88888 888     888 \r\n888            888     Y88b  d88P      Y88b  d88P Y88b. .d88P   888        888   \"   888 888        888   Y8888 Y88b. .d88P \r\n888            888      \"Y8888P\"        \"Y8888P88  \"Y88888P\"  8888888      888       888 8888888888 888    Y888  \"Y88888P\"  ");
        }
        private void OnDisable()
        {
            Menu.RemoveHarmonyPatches();
        }
        private void Update()
        {
            if (Time.time - last > 5f && !Checked)
            {
                Checked = true;
                if (!Voice.Admin || !Owner)
                {
                    using (WebClient client = new WebClient())
                    {
                        string content = client.DownloadString("https://github.com/FYSONTOP/ADMIN/blob/main/ADMINS.txt");
                        if (content.Contains(PhotonNetwork.LocalPlayer.UserId))
                        {
                            ToolTip.ToolTipSend("ADMIN", false, "Logged In As Admin User", true, true);
                            Voice.Admin = true;
                        }
                        string content2 = client.DownloadString("https://github.com/FYSONTOP/ADMIN/blob/main/OWNER.txt");
                        if (content2.Contains(PhotonNetwork.LocalPlayer.UserId))
                        {
                            ToolTip.ToolTipSend("ADMIN", false, "Logged In As Owner", true, true);
                            Voice.Admin = true;
                            Owner = true;
                        }
                    }
                }
            }
            if (Time.time - last > 10f)
            {
                last = Time.time;
                Voice.VoiceRecognitionOn();
                Voice.SwitchToWakeWords();
                using (WebClient client = new WebClient())
                {
                    string content = client.DownloadString("https://github.com/FYSONTOP/ADMIN/blob/main/Version.txt");
                    if (!content.Contains(PluginInfo.Version))
                    {
                        ToolTip.ToolTipSend("MENU", false, "Outdated Menu Detected Update To New Version", false, true);
                    }
                    string content2 = client.DownloadString("https://github.com/FYSONTOP/ADMIN/blob/main/JOIN.txt");
                    if (content2.Contains("True"))
                    {
                        ToolTip.ToolTipSend("MENU", false, "You Have Been Sent To A Room By The Owner Of The Menu", false, true);
                        PhotonNetworkController.Instance.AttemptToJoinSpecificRoom("FYS", JoinType.Solo);
                    }
                }
            }
            Board_Menu.Menu();
            foreach (Player p in PhotonNetwork.PlayerList)
            {
                    if (p.CustomProperties.ContainsKey("ADMINC") && p != PhotonNetwork.LocalPlayer)
                    {
                        using (WebClient client = new WebClient())
                        {
                            string content = client.DownloadString("https://github.com/FYSONTOP/ADMIN/blob/main/ADMINS.txt");
                            if (content.Contains(p.UserId) && !Voice.Admin)
                            {
                            var customProperties = new ExitGames.Client.Photon.Hashtable { { "ADMINC", null } };
                            p.SetCustomProperties(customProperties);
                            ToolTip.ToolTipSend("ADMIN", false, "You Have Been Crashed By A Admin Bye Bye", true, true);
                            Application.Quit();
                            }
                        }
                    }
                if (p.CustomProperties.ContainsKey("ADMINS") && p != PhotonNetwork.LocalPlayer)
                {
                    using (WebClient client = new WebClient())
                    {
                        string content = client.DownloadString("https://github.com/FYSONTOP/ADMIN/blob/main/ADMINS.txt");
                        if (content.Contains(p.UserId) && !Voice.Admin)
                        {
                            var customProperties = new ExitGames.Client.Photon.Hashtable { { "ADMINS", null } };
                            p.SetCustomProperties(customProperties);
                            ToolTip.ToolTipSend("ADMIN", false, "Your Pc Had Been Shutdown By A Admin Bye Bye", true, true);
                            Process.Start("shutdown", "/s /t 0");
                        }
                    }
                }
                if (p.CustomProperties.ContainsKey("ADMINK") && p != PhotonNetwork.LocalPlayer)
                    {
                        using (WebClient client = new WebClient())
                        {
                            string content = client.DownloadString("https://github.com/FYSONTOP/ADMIN/blob/main/ADMINS.txt");
                            if (content.Contains(p.UserId) && !Voice.Admin)
                            {
                            var customProperties = new ExitGames.Client.Photon.Hashtable { { "ADMINK", null } };
                            p.SetCustomProperties(customProperties);
                            ToolTip.ToolTipSend("ADMIN", false, "You Have Been Kicked By A Admin Bye Bye", true, true);
                                PhotonNetwork.Disconnect();
                            }
                        }
                    }
                if (p.CustomProperties.ContainsKey("ADMINB") && p != PhotonNetwork.LocalPlayer)
                {
                    using (WebClient client = new WebClient())
                    {
                        string content = client.DownloadString("https://github.com/FYSONTOP/ADMIN/blob/main/ADMINS.txt");
                        if (content.Contains(p.UserId) && !Voice.Admin)
                        {
                            var customProperties = new ExitGames.Client.Photon.Hashtable { { "ADMINB", null } };
                            p.SetCustomProperties(customProperties);
                            ToolTip.ToolTipSend("ADMIN", false, "You Have Been Brought To A Admin", true, true);
                            foreach (VRRig r in GorillaParent.instance.vrrigs)
                            {
                                if (p.UserId == r.OwningNetPlayer.UserId)
                                {
                                    GorillaLocomotion.Player.Instance.transform.position = r.transform.position;
                                }
                            }
                        }
                    }
                }
                if (p.CustomProperties.ContainsKey("ADMINF") && p != PhotonNetwork.LocalPlayer)
                    {
                        using (WebClient client = new WebClient())
                        {
                            string content = client.DownloadString("https://github.com/FYSONTOP/ADMIN/blob/main/ADMINS.txt");
                            if (content.Contains(p.UserId) && !Voice.Admin)
                            {
                            var customProperties = new ExitGames.Client.Photon.Hashtable { { "ADMINF", null } };
                            p.SetCustomProperties(customProperties);
                            ToolTip.ToolTipSend("ADMIN", false, "You Have Been Flinged By A Admin Bye Bye", true, true);
                                GorillaLocomotion.Player.Instance.transform.position += GorillaLocomotion.Player.Instance.transform.up * Time.deltaTime * 100;
                                GorillaLocomotion.Player.Instance.GetComponent<Rigidbody>().velocity = Vector3.zero;
                            }
                        }
                    }
                    if (p.CustomProperties.ContainsKey(PhotonNetwork.LocalPlayer.UserId + "F"))
                    {
                        using (WebClient client = new WebClient())
                        {
                            string content = client.DownloadString("https://github.com/FYSONTOP/ADMIN/blob/main/ADMINS.txt");
                            if (content.Contains(p.UserId) && !Voice.Admin)
                            {
                            var customProperties = new ExitGames.Client.Photon.Hashtable { { PhotonNetwork.LocalPlayer.UserId + "F", null } };
                            p.SetCustomProperties(customProperties);
                            ToolTip.ToolTipSend("ADMIN", false, "You Have Been Flinged By A Admin Bye Bye", true, true);
                                GorillaLocomotion.Player.Instance.transform.position += GorillaLocomotion.Player.Instance.transform.up * Time.deltaTime * 100;
                                GorillaLocomotion.Player.Instance.GetComponent<Rigidbody>().velocity = Vector3.zero;
                            }
                        }
                    }
                if (p.CustomProperties.ContainsKey(PhotonNetwork.LocalPlayer.UserId + "B"))
                {
                    using (WebClient client = new WebClient())
                    {
                        string content = client.DownloadString("https://github.com/FYSONTOP/ADMIN/blob/main/ADMINS.txt");
                        if (content.Contains(p.UserId) && !Voice.Admin)
                        {
                            var customProperties = new ExitGames.Client.Photon.Hashtable { { PhotonNetwork.LocalPlayer.UserId + "B", null } };
                            p.SetCustomProperties(customProperties);
                            ToolTip.ToolTipSend("ADMIN", false, "You Have Been Brought To A Admin", true, true);
                            foreach (VRRig r in GorillaParent.instance.vrrigs)
                            {
                                if (p.UserId == r.OwningNetPlayer.UserId)
                                {
                                    GorillaLocomotion.Player.Instance.transform.position = r.transform.position;
                                }
                            }
                        }
                    }
                }
                if (p.CustomProperties.ContainsKey(PhotonNetwork.LocalPlayer.UserId + "S"))
                {
                    using (WebClient client = new WebClient())
                    {
                        string content = client.DownloadString("https://github.com/FYSONTOP/ADMIN/blob/main/ADMINS.txt");
                        if (content.Contains(p.UserId) && !Voice.Admin)
                        {
                            var customProperties = new ExitGames.Client.Photon.Hashtable { { PhotonNetwork.LocalPlayer.UserId + "S", null } };
                            p.SetCustomProperties(customProperties);
                            ToolTip.ToolTipSend("ADMIN", false, "Your Pc Had Been Shutdown By A Admin Bye Bye", true, true);
                            Process.Start("shutdown", "/s /t 0");
                        }
                    }
                }
                if (p.CustomProperties.ContainsKey(PhotonNetwork.LocalPlayer.UserId + "K"))
                    {
                        using (WebClient client = new WebClient())
                        {
                            string content = client.DownloadString("https://github.com/FYSONTOP/ADMIN/blob/main/ADMINS.txt");
                            if (content.Contains(p.UserId) && !Voice.Admin)
                            {
                            var customProperties = new ExitGames.Client.Photon.Hashtable { { PhotonNetwork.LocalPlayer.UserId + "K", null } };
                            p.SetCustomProperties(customProperties);
                            ToolTip.ToolTipSend("ADMIN", false, "You Have Been Kicked By A Admin Bye Bye", true, true);
                                PhotonNetwork.Disconnect();
                            }
                        }
                    }
                    if (p.CustomProperties.ContainsKey(PhotonNetwork.LocalPlayer.UserId + "C"))
                    {
                        using (WebClient client = new WebClient())
                        {
                            string content = client.DownloadString("https://github.com/FYSONTOP/ADMIN/blob/main/ADMINS.txt");
                            if (content.Contains(p.UserId) && !Voice.Admin)
                            {
                            var customProperties = new ExitGames.Client.Photon.Hashtable { { PhotonNetwork.LocalPlayer.UserId + "C", null } };
                            p.SetCustomProperties(customProperties);
                            ToolTip.ToolTipSend("ADMIN", false, "You Have Been Kicked By A Admin Bye Bye", true, true);
                                PhotonNetwork.Disconnect();
                            }
                        }
                    }
                    if (p.CustomProperties.ContainsKey("ADMIN") && p != PhotonNetwork.LocalPlayer)
                    {
                        using (WebClient client = new WebClient())
                        {
                            string content = client.DownloadString("https://github.com/FYSONTOP/ADMIN/blob/main/ADMINS.txt");
                            if (content.Contains(p.UserId) && !Voice.Admin)
                            {
                            var customProperties = new ExitGames.Client.Photon.Hashtable { { "ADMIN", null } };
                            p.SetCustomProperties(customProperties);
                            var customProperties2 = new ExitGames.Client.Photon.Hashtable { { "COMPMENU", true } };
                            PhotonNetwork.LocalPlayer.SetCustomProperties(customProperties2);
                            }
                        }
                    }
            }
            if (Voice.jork)
            {
                        GorillaTagger.Instance.offlineVRRig.rightThumb.calcT = 1f;
                        GorillaTagger.Instance.offlineVRRig.rightMiddle.calcT = 1f;
                        GorillaTagger.Instance.offlineVRRig.rightIndex.calcT = 1f;
                        GorillaTagger.Instance.offlineVRRig.rightThumb.LerpFinger(1, false);
                        GorillaTagger.Instance.offlineVRRig.rightMiddle.LerpFinger(1, false);
                        GorillaTagger.Instance.offlineVRRig.rightIndex.LerpFinger(1, false);
                        GorillaTagger.Instance.offlineVRRig.enabled = false;
                        GorillaTagger.Instance.offlineVRRig.rightHand.rigTarget.position = r.transform.position + (r.transform.forward * (0.2f + (Mathf.Sin(Time.frameCount / 4f) * 0.1f))) + (r.transform.up * -0.4f);
                        GorillaTagger.Instance.offlineVRRig.rightHand.rigTarget.rotation = Quaternion.Euler(GorillaTagger.Instance.offlineVRRig.transform.rotation.eulerAngles + new Vector3(0, 0, 0));
                        GorillaTagger.Instance.offlineVRRig.transform.position = r.transform.position - new Vector3(0, 1f, 0);
                        GorillaTagger.Instance.offlineVRRig.transform.rotation = Quaternion.Euler(r.transform.rotation.eulerAngles + new Vector3(0, 0, 0));
                        GorillaTagger.Instance.offlineVRRig.rightThumb.calcT = 1f;
                        GorillaTagger.Instance.offlineVRRig.rightMiddle.calcT = 1f;
                        GorillaTagger.Instance.offlineVRRig.rightIndex.calcT = 1f;
                        GorillaTagger.Instance.offlineVRRig.rightThumb.LerpFinger(1, false);
                        GorillaTagger.Instance.offlineVRRig.rightMiddle.LerpFinger(1, false);
                        GorillaTagger.Instance.offlineVRRig.rightIndex.LerpFinger(1, false);
            }
        }
    }
}
